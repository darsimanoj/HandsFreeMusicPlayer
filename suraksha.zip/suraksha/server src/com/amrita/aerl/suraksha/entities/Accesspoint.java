package com.amrita.aerl.suraksha.entities;

import java.sql.Timestamp;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;


import javax.persistence.Table;


@Entity
@Table(name = "access_point_details")
public class Accesspoint {
	
	
	
	private int id = 0; 
	private String accesspoint = null; 
	private String mac_address = null; 
	private double x   = 0;
	private double y   = 0;
	/**
	 * @return the id
	 */
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "id", unique = true , nullable = false)	
	public  int getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(int sp) {
		this.id = sp;
	}

	@Column(name = "accesspoint")
	public String getaccesspoint() {
		return accesspoint;
	}
	/**
	 * @param contactPersonName the contactPersonName to set
	 */
	public void setaccesspoint(String i) {
		this.accesspoint = i;
	}
	/**
	 * @return the contactPersonName
	 */
	@Column(name = "mac_address")
	public String getmac() {
		return mac_address;
	}
	/**
	 * @param contactPersonName the contactPersonName to set
	 */
	public void setmac(String i) {
		this.mac_address = i;
	}
	
	
	@Column(name = "loc_x_coordinate")
	public double getx() {
		return x;
	}
	/**
	 * @param contactPersonName the contactPersonName to set
	 */
	public void setx(double i) {
		this.x = i;
	}
	/**
	 * @return the contactPersonName
	 */
	@Column(name = "loc_y_coordinate")
	public double gety() {
		return y;
	}
	/**
	 * @param contactPersonName the contactPersonName to set
	 */
	public void sety(double i) {
		this.y = i;
	}
	
	
	

}
