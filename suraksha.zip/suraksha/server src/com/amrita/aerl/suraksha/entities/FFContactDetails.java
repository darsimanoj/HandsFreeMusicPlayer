package com.amrita.aerl.suraksha.entities;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;


import javax.persistence.Table;


@Entity
@Table(name = "ff_contact_details")
public class FFContactDetails {
	
	private int id = 0; 
	private int userId; 
	private String contactPersonName = null;
	private String contactPersonNumber = null;
	private String appUserYN = null;
	private int activeYN = 0;
	private Timestamp createdDateTime = null;  
	private Timestamp modifiedDateTime = null;
	
	/**
	 * @return the id
	 */
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "id", unique = true , nullable = false)	
	public int getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	
	public void setId(int id) {
		this.id = id;
	}
	/**
	 * @return the userId
	 */
	
	
	@Column(name ="user_id")
	public int getUserId() {
		return userId;
	}
	/**
	 * @param i the userId to set
	 */
	public void setUserId(int i) {
		this.userId =  i;
	}
	/**
	 * @return the contactPersonName
	 */
	@Column(name = "contact_person_name")
	public String getContactPersonName() {
		return contactPersonName;
	}
	/**
	 * @param contactPersonName the contactPersonName to set
	 */
	public void setContactPersonName(String contactPersonName) {
		this.contactPersonName = contactPersonName;
	}
	/**
	 * @return the contactPersonNumber
	 */
	@Column(name = "contact_person_number")
	public String getContactPersonNumber() {
		return contactPersonNumber;
	}
	/**
	 * @param contactPersonNumber the contactPersonNumber to set
	 */
	public void setContactPersonNumber(String contactPersonNumber) {
		this.contactPersonNumber = contactPersonNumber;
	}
	/**
	 * @return the appUserYN
	 */
	@Column(name = "app_user_yn")
	public String getAppUserYN() {
		return appUserYN;
	}
	/**
	 * @param appUserYN the appUserYN to set
	 */
	public void setAppUserYN(String appUserYN) {
		this.appUserYN = appUserYN;
	}
	
	/**
	 * @return the activeYN
	 */
	@Column(name = "active_yn")
	public int getActiveYN() {
		return activeYN;
	}
	/**
	 * @param activeYN the activeYN to set
	 */
	public void setActiveYN(int activeYN) {
		this.activeYN = activeYN;
	}
	
	
	/**
	 * @return the createdDateTime
	 */
	@Column(name = "created_date_time")
	public Timestamp getCreatedDateTime() {
		return createdDateTime;
	}
	/**
	 * @param createdDateTime the createdDateTime to set
	 */
	public void setCreatedDateTime(Timestamp createdDateTime) {
		this.createdDateTime = createdDateTime;
	}
	/**
	 * @return the modifiedDateTime
	 */
	@Column(name = "modified_date_time")
	public Timestamp getModifiedDateTime() {
		return modifiedDateTime;
	}
	/**
	 * @param modifiedDateTime the modifiedDateTime to set
	 */
	public void setModifiedDateTime(Timestamp modifiedDateTime) {
		this.modifiedDateTime = modifiedDateTime;
	}
	

}
