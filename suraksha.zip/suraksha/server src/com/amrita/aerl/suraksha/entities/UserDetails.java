package com.amrita.aerl.suraksha.entities;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "user_details")
public class UserDetails {
	
	private int id = 0; 
	private String userMobileNumber = null;
	private String firstName = null;
	private String lastName = null; 
	private String gender = null;
	private String dob = null;
	private String emailId = null;
	private String address = null;
	private String city = null;
	private String state = null;
	private String country = null;
	private String occupation = null;
	private String officeAddress = null;
	private String officeNumber = null;
	private int activeYN = 0;
	private Timestamp createdDateTime = null;  
	private Timestamp modifiedDateTime = null;
	private String lastLocation = null;
	private float latitude = (float) 0.0;
	private float longitude = (float) 0.0;
	
	
	
	/**
	 * @return the id
	 */
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "id" , unique = true, nullable = false)
	public int getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}
	/**
	 * @return the userMobileNumber
	 */
	@Column(name="user_mobile_number")
	public String getUserMobileNumber() {
		return userMobileNumber;
	}
	/**
	 * @param phnnumber the userMobileNumber to set
	 */
	public void setUserMobileNumber(String phnnumber) {
		this.userMobileNumber = phnnumber;
	}
	/**
	 * @return the firstName
	 */
	@Column(name="first_name")
	public String getFirstName() {
		return firstName;
	}
	/**
	 * @param firstName the firstName to set
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	/**
	 * @return the lastName
	 */
	@Column(name="last_name")
	public String getLastName() {
		return lastName;
	}
	/**
	 * @param lastName the lastName to set
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	/**
	 * @return the gender
	 */
	@Column(name="gender")
	public String getGender() {
		return gender;
	}
	/**
	 * @param gender the gender to set
	 */
	public void setGender(String gender) {
		this.gender = gender;
	}
	/**
	 * @return the dob
	 */
	@Column(name="date_of_birth")
	public String getDob() {
		return dob;
	}
	/**
	 * @param dob the dob to set
	 */
	public void setDob(String dob) {
		this.dob = dob;
	}
	/**
	 * @return the emailId
	 */
	@Column(name="email_id")
	public String getEmailId() {
		return emailId;
	}
	/**
	 * @param emailId, the Email ID to be set
	 */
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	/**
	 * @return the address
	 */
	@Column(name="address")
	public String getAddress() {
		return address;
	}
	/**
	 * @param address the address to set
	 */
	public void setAddress(String address) {
		this.address = address;
	}
	/**
	 * @return the city
	 */
	@Column(name="city")
	public String getCity() {
		return city;
	}
	/**
	 * @param city the city to set
	 */
	public void setCity(String city) {
		this.city = city;
	}
	/**
	 * @return the state
	 */
	@Column(name="state")
	public String getState() {
		return state;
	}
	/**
	 * @param state the state to set
	 */
	public void setState(String state) {
		this.state = state;
	}/**
	 * @return the country
	 */
	@Column(name="country")
	public String getCountry() {
		return country;
	}
	/**
	 * @param country the country to be set
	 */
	public void setCountry(String country) {
		this.country = country;
	}
	/**
	 * @return the occupation
	 */
	@Column(name="occupation")
	public String getOccupation() {
		return occupation;
	}
	/**
	 * @param occupation the occupation to set
	 */
	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}
	/**
	 * @return the officeAddress
	 */
	@Column(name="office_adress")
	public String getOfficeAddress() {
		return officeAddress;
	}
	/**
	 * @param officeAddress the officeAddress to set
	 */
	public void setOfficeAddress(String officeAddress) {
		this.officeAddress = officeAddress;
	}
	/**
	 * @return the officeNumber
	 */
	@Column(name="office_number")
	public String getOfficeNumber() {
		return officeNumber;
	}
	/**
	 * @param officeNumber the officeNumber to set
	 */
	public void setOfficeNumber(String officeNumber) {
		this.officeNumber = officeNumber;
	}
	/**
	 * @return the activeYN
	 */
	@Column(name="active_yn")
	public int getActiveYN() {
		return activeYN;
	}
	/**
	 * @param activeYN the activeYN to set
	 */
	public void setActiveYN(int activeYN) {
		this.activeYN = activeYN;
	}
	/**
	 * @return the createdDateTime
	 */
	@Column(name="created_date_time")
	public Timestamp getCreatedDateTime() {
		return createdDateTime;
	}
	/**
	 * @param createdDateTime the createdDateTime to set
	 */
	public void setCreatedDateTime(Timestamp createdDateTime) {
		this.createdDateTime = createdDateTime;
	}
	/**
	 * @return the modifiedDateTime
	 */
	@Column(name="modified_date_time")
	public Timestamp getModifiedDateTime() {
		return modifiedDateTime;
	}
	/**
	 * @param modifiedDateTime the modifiedDateTime to set
	 */
	public void setModifiedDateTime(Timestamp modifiedDateTime) {
		this.modifiedDateTime = modifiedDateTime;
	}
	/**
	 * @return the lastLocation
	 */
	@Column(name="last_location")
	public String getLastLocation() {
		return lastLocation;
	}
	/**
	 * @param lastName the lastName to set
	 */
	public void setLastLocation(String lastLocation) {
		this.lastLocation = lastLocation;
	}
	
	/**
	 * @return the lastLocation
	 */
	@Column(name="latitude")
	public float getLatitude() {
		return latitude;
	}
	/**
	 * @param lastName the lastName to set
	 */
	public void setLatitude(float latitude) {
		this.latitude = latitude;
	}

	@Column(name="longitude")
	public float getLongitude() {
		return longitude;
	}
	/**
	 * @param lastName the lastName to set
	 */
	public void setLongitude(float longitude) {
		this.longitude = longitude;
	}
}
