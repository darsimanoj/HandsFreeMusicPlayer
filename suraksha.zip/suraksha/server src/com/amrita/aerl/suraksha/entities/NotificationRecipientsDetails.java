package com.amrita.aerl.suraksha.entities;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "notification_recipients_details")
public class NotificationRecipientsDetails 
{
	
	private int id = 0;
	private int senderId;
	private int receiverId;
	private int notificationId = 0;
	private String viewedStatus = null; 	
	private int activeYN = 0;
	private Timestamp createdDateTime = null;  
	private Timestamp modifiedDateTime = null;
	
	
	
	/**
	 * @return the id
	 */
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "id", unique = true , nullable = false)	
	public int getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}
	/**
	 * @return the senderId
	 */
	
	@Column(name = "sender_user_id")
	public int getSenderId() {
		return senderId;
	}
	/**
	 * @param senderId the senderId to set
	 */
	public void setSenderId(int senderId) {
		this.senderId = senderId;
	}
	/**
	 * @return the receiverId
	 */
	@Column(name = "receiver_user_id")
	public int getReceiverId() {
		return receiverId;
	}
	/**
	 * @param receiverId the receiverId to set
	 */
	public void setReceiverId(int receiverId) {
		this.receiverId = receiverId;
	}
	/**
	 * @return the notificationId
	 */
	@Column(name = "notification_id")
	public int getNotificationId() {
		return notificationId;
	}
	/**
	 * @param notificationId the notificationI to set
	 */
	public void setNotificationId(int notificationId) {
		this.notificationId = notificationId;
	}
	/**
	 * @return the viewedStatus
	 */
	@Column(name = "viewed_status")
	public String getViewedStatus() {
		return viewedStatus;
	}
	/**
	 * @param viewedStatus the viewedStatus to set
	 */
	public void setViewedStatus(String viewedStatus) {
		this.viewedStatus = viewedStatus;
	}
		
	/**
	 * @return the activeYN
	 */
	@Column(name = "active_yn")
	public int getActiveYN() {
		return activeYN;
	}
	/**
	 * @param activeYN the activeYN to set
	 */
	public void setActiveYN(int activeYN) {
		this.activeYN = activeYN;
	}	
	/**
	 * @return the createdDateTime
	 */
	@Column(name = "created_date_time")
	public Timestamp getCreatedDateTime() {
		return createdDateTime;
	}
	/**
	 * @param createdDateTime the createdDateTime to set
	 */
	public void setCreatedDateTime(Timestamp createdDateTime) {
		this.createdDateTime = createdDateTime;
	}
	/**
	 * @return the modifiedDateTime
	 */
	@Column(name = "modified_date_time")
	public Timestamp getModifiedDateTime() {
		return modifiedDateTime;
	}
	/**
	 * @param modifiedDateTime the modifiedDateTime to set
	 */
	public void setModifiedDateTime(Timestamp modifiedDateTime) {
		this.modifiedDateTime = modifiedDateTime;
	}}
