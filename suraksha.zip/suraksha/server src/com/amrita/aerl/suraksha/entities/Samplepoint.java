package com.amrita.aerl.suraksha.entities;

import java.sql.Timestamp;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;


import javax.persistence.Table;


@Entity
@Table(name = "sample_Point_details")
public class Samplepoint {
	
	
	
	private int sample_point = 0; 
	private String fingerprint = null; 
	private double x   = 0;
	private double y   = 0;
	/**
	 * @return the id
	 */
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "Sample_point", unique = true , nullable = false)	
	public  int getSp() {
		return sample_point;
	}
	/**
	 * @param id the id to set
	 */
	public void setSp(int sp) {
		this.sample_point = sp;
	}

	@Column(name = "fingerprint")
	public String getfingerprint() {
		return fingerprint;
	}
	/**
	 * @param contactPersonName the contactPersonName to set
	 */
	public void setfingerprint(String i) {
		this.fingerprint = i;
	}
	/**
	 * @return the contactPersonName
	 */
	@Column(name = "x")
	public double getx() {
		return x;
	}
	/**
	 * @param contactPersonName the contactPersonName to set
	 */
	public void setx(double i) {
		this.x = i;
	}
	/**
	 * @return the contactPersonName
	 */
	@Column(name = "y")
	public double gety() {
		return y;
	}
	/**
	 * @param contactPersonName the contactPersonName to set
	 */
	public void sety(double i) {
		this.y = i;
	}
	
	
	

}
