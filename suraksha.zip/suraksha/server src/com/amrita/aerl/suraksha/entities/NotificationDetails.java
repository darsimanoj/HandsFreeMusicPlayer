package com.amrita.aerl.suraksha.entities;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "notification_details")
public class NotificationDetails 
{
	
	private int id = 0;
	private int senderId;
	private String userLocation = null;
	private String locationAddress = null;
	private int activeYN = 0;
	private Timestamp createdDateTime = null;  
	private Timestamp modifiedDateTime = null;
	
	
	
	/**
	 * @return the id
	 */
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "id", unique = true , nullable = false)	
	public int getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}
	/**
	 * @return the senderId
	 */
	
	@Column(name = "sender_user_id")
	public int getSenderId() {
		return senderId;
	}
	/**
	 * @param senderId the senderId to set
	 */
	public void setSenderId(int senderId) {
		this.senderId = senderId;
	}
	/**
	 * @return the userLocation
	 */
	@Column(name = "user_location")
	public String getUserLocation() {
		return userLocation;
	}
	/**
	 * @param userLocation the userLocation to set
	 */
	public void setUserLocation(String userLocation) {
		this.userLocation = userLocation;
	}
	
	
	/**
	 * @return the locationAddress
	 */
	@Column(name = "location_address")
	public String getLocationAddress() {
		return locationAddress;
	}
	/**
	 * @param locationAddress the locationAddress to set
	 */
	public void setLocationAddress(String locationAddress) {
		this.locationAddress = locationAddress;
	}
		
	/**
	 * @return the activeYN
	 */
	@Column(name = "active_yn")
	public int getActiveYN() {
		return activeYN;
	}
	/**
	 * @param activeYN the activeYN to set
	 */
	public void setActiveYN(int activeYN) {
		this.activeYN = activeYN;
	}
	
	
	/**
	 * @return the createdDateTime
	 */
	@Column(name = "created_date_time")
	public Timestamp getCreatedDateTime() {
		return createdDateTime;
	}
	/**
	 * @param createdDateTime the createdDateTime to set
	 */
	public void setCreatedDateTime(Timestamp createdDateTime) {
		this.createdDateTime = createdDateTime;
	}
	/**
	 * @return the modifiedDateTime
	 */
	@Column(name = "modified_date_time")
	public Timestamp getModifiedDateTime() {
		return modifiedDateTime;
	}
	/**
	 * @param modifiedDateTime the modifiedDateTime to set
	 */
	public void setModifiedDateTime(Timestamp modifiedDateTime) {
		this.modifiedDateTime = modifiedDateTime;
	}}
