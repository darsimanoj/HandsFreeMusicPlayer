package com.amrita.aerl.suraksha.entities;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;


import javax.persistence.Table;

@Entity
@Table(name = "otp_details")
public class OTPDetails {
	
	private int id = 0;
	private int userId; 
	private int OTP = 0;
	private int status = 0;
	private int activeYN = 0;
	private Timestamp createdDateTime = null;  
	private Timestamp modifiedDateTime = null;
	
	/**
	 * @return the id
	 */
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="id" , unique = true, nullable = false)
	public int getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}
	/**
	 * @return the userId
	 */
	
	@Column(name = "user_id")
	public int getUserId() {
		return userId;
	}
	/**
	 * @param userId the userId to set
	 */
	public void setUserId(int userId) {
		this.userId = userId;
	}
	/**
	 * @return the oTP
	 */
	@Column(name = "otp")
	public int getOTP() {
		return OTP;
	}
	/**
	 * @param oTP the oTP to set
	 */
	public void setOTP(int oTP) {
		OTP = oTP;
	}
	/**
	 * @return the status
	 */
	@Column(name = "status")
	public int getStatus() {
		return status;
	}
	/**
	 * @param status the status to set
	 */
	public void setStatus(int status) {
		this.status = status;
	}
	/**
	 * @return the activeYN
	 */
	@Column(name="active_yn")
	public int getActiveYN() {
		return activeYN;
	}
	/**
	 * @param activeYN the activeYN to set
	 */
	public void setActiveYN(int activeYN) {
		this.activeYN = activeYN;
	}
	/**
	 * @return the createdDateTime
	 */
	@Column(name="created_date_time")
	public Timestamp getCreatedDateTime() {
		return createdDateTime;
	}
	/**
	 * @param createdDateTime the createdDateTime to set
	 */
	public void setCreatedDateTime(Timestamp createdDateTime) {
		this.createdDateTime = createdDateTime;
	}
	/**
	 * @return the modifiedDateTime
	 */
	@Column(name="modified_date_time")
	public Timestamp getModifiedDateTime() {
		return modifiedDateTime;
	}
	/**
	 * @param modifiedDateTime the modifiedDateTime to set
	 */
	public void setModifiedDateTime(Timestamp modifiedDateTime) {
		this.modifiedDateTime = modifiedDateTime;
	}
	
}
