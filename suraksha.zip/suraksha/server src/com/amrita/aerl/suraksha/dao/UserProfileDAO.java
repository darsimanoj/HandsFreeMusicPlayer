/**
 * 
 */
package com.amrita.aerl.suraksha.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;

import com.amrita.aerl.suraksha.entities.FFContactDetails;
import com.amrita.aerl.suraksha.entities.UserDetails;
import com.amrita.aerl.suraksha.utils.HibernateUtils;
import com.amrita.aerl.suraksha.utils.TimeStampUtils;

/**
 * @author rvinoth
 *
 */
public class UserProfileDAO {
	
	public static List<UserDetails> usrDetails = null;
	public static List<FFContactDetails> contactDetails= null;
	
	
	
	public static void userProfileEdit(String usrNum,String firstName,String lastName,String gender,String dob,String emailId,String address,String city,String state,String country,String occupation,String officeAddress,String officeNum)
	{
		
		Session session = null;
		
		try {
			
				
				if(isAvailable(usrNum))
				{
					session = HibernateUtils.getHibernateConnection();
					session.beginTransaction();
					UserDetails userProfile = new UserDetails();
					userProfile.setId(usrDetails.get(0).getId());
					userProfile.setUserMobileNumber(usrDetails.get(0).getUserMobileNumber());
					userProfile.setFirstName(firstName);
					userProfile.setLastName(lastName);
					userProfile.setGender(gender);
					userProfile.setDob(dob);
					userProfile.setEmailId(emailId);
					userProfile.setAddress(address);
					userProfile.setCity(city);
					userProfile.setState(state);
					userProfile.setCountry(country);
					userProfile.setOccupation(occupation);
					userProfile.setOfficeAddress(officeAddress);
					userProfile.setOfficeNumber(officeNum);
					userProfile.setActiveYN(1);
					userProfile.setCreatedDateTime(usrDetails.get(0).getCreatedDateTime());
					userProfile.setModifiedDateTime(TimeStampUtils.getCurrentTimestamp());	
					//userProfile.setLastLocation(loc);
					session.update(userProfile);		
					session.getTransaction().commit();
					System.out.println("********User Profile Updated*********");
					
				}
				else
				{
					session = HibernateUtils.getHibernateConnection();
					session.beginTransaction();
					UserDetails userProfile = new UserDetails();
					userProfile.setUserMobileNumber(usrNum);
					userProfile.setFirstName(firstName);
					userProfile.setLastName(lastName);
					userProfile.setGender(gender);
					userProfile.setDob(dob);
					userProfile.setEmailId(emailId);
					userProfile.setAddress(address);
					userProfile.setCity(city);
					userProfile.setState(state);
					userProfile.setCountry(country);
					userProfile.setOccupation(occupation);
					userProfile.setOfficeAddress(officeAddress);
					userProfile.setOfficeNumber(officeNum);
					userProfile.setActiveYN(1);
					userProfile.setCreatedDateTime(TimeStampUtils.getCurrentTimestamp());
					userProfile.setModifiedDateTime(TimeStampUtils.getCurrentTimestamp());			
					session.save(userProfile);		
					session.getTransaction().commit();
					System.out.println("********User Profile Inserted*********");
					if(isBuddyExists(usrNum)){
						updateContactList();
					}
				}
						
			}
		catch(HibernateException he){
			he.printStackTrace();
			
		}finally{
			HibernateUtils.closeConnection(session);
		}		
		
	}
	
	
	private static List<UserDetails> getUsrId(String usrNumber)
	{
		Session session = null;
		List<UserDetails> usrDetails = null;
		Query hqlQuery;
		
		try{
			session = HibernateUtils.getHibernateConnection();	
			
			hqlQuery = session.createQuery(" FROM UserDetails UD " +
					" WHERE UD.activeYN = :activeYES " +
					" AND UD.userMobileNumber = :cid ")
					.setString("cid", usrNumber)
					.setInteger("activeYES", 1);
			usrDetails = hqlQuery.list();
			
			
		}
			catch(HibernateException he)
			{
				he.printStackTrace();				
				
			}
			finally
			{
				HibernateUtils.closeConnection(session);
			}	
		return usrDetails;
		
	}
	
	public static boolean isAvailable(String usrNumber)
	{
		Session session = null;			
		Query hqlQuery;
		try{
			session = HibernateUtils.getHibernateConnection();	
			
			hqlQuery = session.createQuery(" FROM UserDetails UD " +
					" WHERE UD.activeYN = :activeYES " +
					" AND UD.userMobileNumber = :cid ")
					.setString("cid", usrNumber)
					.setInteger("activeYES", 1);
			usrDetails = hqlQuery.list();
			}
			catch(HibernateException he)
			{
				he.printStackTrace();				
				
			}
			finally
			{
				HibernateUtils.closeConnection(session);
			}
		
		if(usrDetails.size()!=0)
		{
			return true;
		}
		else
		{
			return false;
		}	
		
	}
	
	public static ArrayList fetchProfileDetails(String usrNum)
	{
		
		ArrayList<String> allDetails = new ArrayList<String>();
		List<UserDetails>profileDetails = null;
		Session session = null;
		Query hqlQuery;		
		try 
		{
			session = HibernateUtils.getHibernateConnection();	
			
			hqlQuery = session.createQuery(" FROM UserDetails UD " +
					" WHERE UD.activeYN = :activeYES " +
					" AND UD.userMobileNumber = :cid ")
					.setString("cid", usrNum)
					.setInteger("activeYES", 1);
			profileDetails = hqlQuery.list();
			
			if(profileDetails.size()!=0)
			{
				for(int i=0; i<profileDetails.size(); i++)
				{
					String data = new String();
					data = profileDetails.get(i).getFirstName()+','+profileDetails.get(i).getLastName()+','+profileDetails.get(i).getGender()+','+profileDetails.get(i).getDob()+','+profileDetails.get(i).getEmailId()+','+profileDetails.get(i).getAddress()+','+profileDetails.get(i).getCity()+','+profileDetails.get(i).getState()+','+profileDetails.get(i).getCountry()+','+profileDetails.get(i).getOccupation()+','+profileDetails.get(i).getOfficeAddress()+','+profileDetails.get(i).getOfficeNumber()+','+profileDetails.get(i).getUserMobileNumber();
					allDetails.add(data);
					
				}
			}
			else
			{
				System.out.println("*****************No Data Found*********" );
			}
			
			
		}
		catch(HibernateException he){
			he.printStackTrace();
			
		}finally{
			HibernateUtils.closeConnection(session);
		}
		
		return allDetails;
		
		
	}
	
	private static boolean isBuddyExists(String buddyNumber)
	{
		Session session = null;
		Query hqlQuery;
		
		try{
			session = HibernateUtils.getHibernateConnection();	
			
			hqlQuery  = session.createQuery("select ff from FFContactDetails ff " +
					"where ff.contactPersonNumber = :buddyNum and ff.appUserYN = :appUser ");
			hqlQuery.setString("buddyNum", buddyNumber);
			hqlQuery.setString("appUser", "N");
			
			contactDetails = hqlQuery.list();
			if(!contactDetails.isEmpty())
			{
				return true;
			}
			else 
			{
				return false;
			}
		}
		catch(HibernateException he)
		{
			he.printStackTrace();
			return true;
			
		}
		finally
		{
			HibernateUtils.closeConnection(session);
		}
	}
	
	private static void updateContactList(){
		Session session = null;
		try{
			session = HibernateUtils.getHibernateConnection();
			session.beginTransaction();	
			FFContactDetails buddyDetails = (FFContactDetails)(contactDetails.get(0));
			buddyDetails.setAppUserYN("Y");
			buddyDetails.setModifiedDateTime(TimeStampUtils.getCurrentTimestamp());	
			session.update(buddyDetails);
			session.getTransaction().commit();
			System.out.println("********Contact list updated*********");
		}
		catch(HibernateException he)
		{
			he.printStackTrace();
		}
		finally
		{
			HibernateUtils.closeConnection(session);
		}
	}


	public static String addinglocation(String usrNum, String loc) {
		// TODO Auto-generated method stub
		
			String result=null;
			Session session = null;
			
			try {
				
					
					if(isAvailable(usrNum))
					{
						session = HibernateUtils.getHibernateConnection();
						session.beginTransaction();
						UserDetails userProfile = new UserDetails();
						userProfile.setId(usrDetails.get(0).getId());
						userProfile.setUserMobileNumber(usrDetails.get(0).getUserMobileNumber());	
						userProfile.setFirstName(usrDetails.get(0).getFirstName());
						userProfile.setLastName(usrDetails.get(0).getLastName());
						userProfile.setGender(usrDetails.get(0).getGender());
						userProfile.setDob(usrDetails.get(0).getDob());
						userProfile.setEmailId(usrDetails.get(0).getEmailId());
						userProfile.setAddress(usrDetails.get(0).getAddress());
						userProfile.setCity(usrDetails.get(0).getCity());
						userProfile.setState(usrDetails.get(0).getState());
						userProfile.setCountry(usrDetails.get(0).getCountry());
						userProfile.setOccupation(usrDetails.get(0).getOccupation());
						userProfile.setOfficeAddress(usrDetails.get(0).getOfficeAddress());
						userProfile.setOfficeNumber(usrDetails.get(0).getOfficeNumber());
						userProfile.setActiveYN(1);
						userProfile.setCreatedDateTime(usrDetails.get(0).getCreatedDateTime());
						userProfile.setModifiedDateTime(TimeStampUtils.getCurrentTimestamp());	
						userProfile.setLastLocation(loc);
						userProfile.setLatitude(usrDetails.get(0).getLatitude());
						userProfile.setLongitude(usrDetails.get(0).getLongitude());
						session.update(userProfile);		
						session.getTransaction().commit();
						System.out.println("********User location Updated*********");
						result = "Added";
						return result;
					}
					else
					{
						
					}
							
				}
			catch(HibernateException he){
				he.printStackTrace();
				
			}finally{
				HibernateUtils.closeConnection(session);
			}
			result="error";
			return result;		
			
			
		
	}


	public static String addinglatitude(String usrNum, float lat) {
		// TODO Auto-generated method stub
		
			String result=null;
			Session session = null;
			
			try {
				
					
					if(isAvailable(usrNum))
					{
						session = HibernateUtils.getHibernateConnection();
						session.beginTransaction();
						UserDetails userProfile = new UserDetails();
						userProfile.setId(usrDetails.get(0).getId());
						userProfile.setUserMobileNumber(usrDetails.get(0).getUserMobileNumber());	
						userProfile.setFirstName(usrDetails.get(0).getFirstName());
						userProfile.setLastName(usrDetails.get(0).getLastName());
						userProfile.setGender(usrDetails.get(0).getGender());
						userProfile.setDob(usrDetails.get(0).getDob());
						userProfile.setEmailId(usrDetails.get(0).getEmailId());
						userProfile.setAddress(usrDetails.get(0).getAddress());
						userProfile.setCity(usrDetails.get(0).getCity());
						userProfile.setState(usrDetails.get(0).getState());
						userProfile.setCountry(usrDetails.get(0).getCountry());
						userProfile.setOccupation(usrDetails.get(0).getOccupation());
						userProfile.setOfficeAddress(usrDetails.get(0).getOfficeAddress());
						userProfile.setOfficeNumber(usrDetails.get(0).getOfficeNumber());
						userProfile.setActiveYN(1);
						userProfile.setCreatedDateTime(usrDetails.get(0).getCreatedDateTime());
						userProfile.setModifiedDateTime(TimeStampUtils.getCurrentTimestamp());	
						userProfile.setLastLocation(usrDetails.get(0).getLastLocation());
						userProfile.setLatitude(lat);
						userProfile.setLongitude(usrDetails.get(0).getLongitude());
						session.update(userProfile);		
						session.getTransaction().commit();
						System.out.println("********User latitude Updated*********");
						result = "Added";
						return result;
					}
					else
					{
						
					}
							
				}
			catch(HibernateException he){
				he.printStackTrace();
				
			}finally{
				HibernateUtils.closeConnection(session);
			}
			result="error";
			return result;		
			
			
		
	}
	
	public static String addinglongitude(String usrNum, float longi) {
		// TODO Auto-generated method stub
		
			String result=null;
			Session session = null;
			
			try {
				
					
					if(isAvailable(usrNum))
					{
						session = HibernateUtils.getHibernateConnection();
						session.beginTransaction();
						UserDetails userProfile = new UserDetails();
						userProfile.setId(usrDetails.get(0).getId());
						userProfile.setUserMobileNumber(usrDetails.get(0).getUserMobileNumber());	
						userProfile.setFirstName(usrDetails.get(0).getFirstName());
						userProfile.setLastName(usrDetails.get(0).getLastName());
						userProfile.setGender(usrDetails.get(0).getGender());
						userProfile.setDob(usrDetails.get(0).getDob());
						userProfile.setEmailId(usrDetails.get(0).getEmailId());
						userProfile.setAddress(usrDetails.get(0).getAddress());
						userProfile.setCity(usrDetails.get(0).getCity());
						userProfile.setState(usrDetails.get(0).getState());
						userProfile.setCountry(usrDetails.get(0).getCountry());
						userProfile.setOccupation(usrDetails.get(0).getOccupation());
						userProfile.setOfficeAddress(usrDetails.get(0).getOfficeAddress());
						userProfile.setOfficeNumber(usrDetails.get(0).getOfficeNumber());
						userProfile.setActiveYN(1);
						userProfile.setCreatedDateTime(usrDetails.get(0).getCreatedDateTime());
						userProfile.setModifiedDateTime(TimeStampUtils.getCurrentTimestamp());	
						userProfile.setLastLocation(usrDetails.get(0).getLastLocation());
						userProfile.setLatitude(usrDetails.get(0).getLatitude());
						userProfile.setLongitude(longi);
						session.update(userProfile);		
						session.getTransaction().commit();
						System.out.println("********User longitude Updated*********");
						result = "Added";
						return result;
					}
					else
					{
						
					}
							
				}
			catch(HibernateException he){
				he.printStackTrace();
				
			}finally{
				HibernateUtils.closeConnection(session);
			}
			result="error";
			return result;		
			
			
		
	}	
	
	
	public static String getting_loc(String usrNum) {
		// TODO Auto-generated method stub
		
			String result=null;
			Session session = null;
			
			try {
				
					
					if(isAvailable(usrNum))
					{
						session = HibernateUtils.getHibernateConnection();
						session.beginTransaction();
						String data=new String();
						data=usrDetails.get(0).getLatitude()+":"+usrDetails.get(0).getLongitude();
						return data ;
					}
					else
					{
						
					}
							
				}
			catch(HibernateException he){
				he.printStackTrace();
				
			}finally{
				HibernateUtils.closeConnection(session);
			}
			result="error";
			return result;		
			
			
		
	}	

}
