/**
 * 
 */
package com.amrita.aerl.suraksha.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;


import com.amrita.aerl.suraksha.entities.Accesspoint;
import com.amrita.aerl.suraksha.utils.HibernateUtils;

/**
 * @author rvinoth
 *
 */
public class AccesspointDAO {
	
	
	
	
	
	public static String AccesspointAdd(String accesspoint,String mac_address ,double x,double y)
	{
		String result= "failed";
		Session session = null;
		
		try {
			
				
				
					session = HibernateUtils.getHibernateConnection();
					session.beginTransaction();
					Accesspoint fp = new Accesspoint();
					
					
					fp.setaccesspoint(accesspoint);
					fp.setmac(mac_address);
					fp.setx(x);
					fp.sety(y);
					//userProfile.setLastLocation(loc);
					//System.out.println(session.save(fp).getClass().getName());	
					session.save(fp);	
					session.getTransaction().commit();
					System.out.println("********fingerprint sample Updated*********");
					
				
					 result = "Done";	
			}
		catch(HibernateException he){
			he.printStackTrace();
			
		}finally{
			HibernateUtils.closeConnection(session);
		}		
		return result;
	}
	
	
	private static List<Accesspoint> getaccesspoints()
	{
		Session session = null;
		List<Accesspoint> pf = null;
		Query hqlQuery;
		
		try{
			session = HibernateUtils.getHibernateConnection();	
			
			hqlQuery = session.createQuery(" FROM access_point_details");
			pf = hqlQuery.list();
			
			
		}
			catch(HibernateException he)
			{
				he.printStackTrace();				
				
			}
			finally
			{
				HibernateUtils.closeConnection(session);
			}	
		return pf;
		
	}


	
	
	
	
	
	
	
	

}
