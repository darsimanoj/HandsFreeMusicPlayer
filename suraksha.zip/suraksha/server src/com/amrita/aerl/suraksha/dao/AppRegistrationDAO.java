package com.amrita.aerl.suraksha.dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;

import com.amrita.aerl.suraksha.entities.UserDetails;
import com.amrita.aerl.suraksha.utils.HibernateUtils;
import com.amrita.aerl.suraksha.utils.TimeStampUtils;


public class AppRegistrationDAO {
	
	
//	public static String testFN()
//	  {
//	    Session session = null;
//	    try
//	    {
//	      System.out.println("*****************TesT fn in DAO is invoked*********");
//	      session = HibernateUtils.getHibernateConnection();
//	      session.beginTransaction();
//	      UserDetails user = new UserDetails();
//	      user.setUserMobileNumber("9037579273");
//	      user.setUserName("Vinoth");
//	      user.setActiveYN("Y");
//	      session.save(user);
//	      session.getTransaction().commit();
//	      
//	      String result = "sux";
//	      return result;
//	    }
//	    catch (HibernateException he)
//	    {
//	      String str1;
//	      he.printStackTrace();
//	      String result = "error";
//	      return result;
//	    }
//	    finally
//	    {
//	      HibernateUtils.closeConnection(session);
//	    }
//	  }
	
	
	
	
	
	private static String result = null;
	
	public static String appRegistration(String usrPhoneNumber)
	{
		
		Session session = null;
		
		try {
			
			if (isAvailable(usrPhoneNumber))
			{
				System.out.println("*****************inside isavailable*********");
				result = "Already Available";
				return result;
			}
			else
			{
				System.out.println("********User Registration*********");
				session = HibernateUtils.getHibernateConnection();
				session.beginTransaction();
				UserDetails user = new UserDetails();
				user.setUserMobileNumber(usrPhoneNumber);
				user.setActiveYN(1);
				user.setCreatedDateTime(TimeStampUtils.getCurrentTimestamp());
				user.setModifiedDateTime(TimeStampUtils.getCurrentTimestamp());		
				user.setLastLocation(null);
				session.save(user);
				session.getTransaction().commit();
				result = "done";
				return result;
			}			
			
			
		}catch(HibernateException he){
			he.printStackTrace();
			result = "error";
			return result;
		}finally{
			HibernateUtils.closeConnection(session);
		}		
		
	}
	
	
	private static boolean isAvailable(String usrNumber)
	{
		Session session = null;
		List<UserDetails> usrDetails = null;
		Query hqlQuery;
		
		try{
			session = HibernateUtils.getHibernateConnection();	
			
			hqlQuery = session.createQuery(" FROM UserDetails UD " +
					" WHERE UD.activeYN = :activeYES " +
					" AND UD.userMobileNumber = :cid ")
					.setString("cid", usrNumber)
					.setInteger("activeYES", 1);
			usrDetails = hqlQuery.list();
			
			if(!usrDetails.isEmpty())
			{
				return true;
			}
			else 
			{
				return false;
			}
		}
			catch(HibernateException he)
			{
				he.printStackTrace();
				return true;
				
			}
			finally
			{
				HibernateUtils.closeConnection(session);
			}	
		
	}

}
