/**
 * 
 */
package com.amrita.aerl.suraksha.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;


import org.json.JSONException;
import org.json.JSONObject;

import com.amrita.aerl.suraksha.entities.Samplepoint;
import com.amrita.aerl.suraksha.utils.HibernateUtils;

/**
 * @author rvinoth
 *
 */
public class SamplepointDAO {
	
	
	
	
	
	public static String SamplepointAdd(String fingerprint ,double x,double y)
	{
		String result= "failed";
		Session session = null;
		
		try {
			
				
				
					session = HibernateUtils.getHibernateConnection();
					session.beginTransaction();
					Samplepoint fp = new Samplepoint();
					
					
					fp.setfingerprint(fingerprint);
					
					fp.setx(x);
					fp.sety(y);
					//userProfile.setLastLocation(loc);
					//System.out.println(session.save(fp).getClass().getName());	
					session.save(fp);	
					session.getTransaction().commit();
					System.out.println("********fingerprint sample Updated*********");
					
				
					 result = "Done";	
			}
		catch(HibernateException he){
			he.printStackTrace();
			
		}finally{
			HibernateUtils.closeConnection(session);
		}		
		return result;
	}
	
	
	public static List<String> getFingerprint()
	{
		Session session = null;
		List<String> pf = null;
		Query hqlQuery;
		
		try{
			session = HibernateUtils.getHibernateConnection();	
			
			hqlQuery = session.createQuery("select fingerprint FROM Samplepoint");
			pf = hqlQuery.list();
			
			
		}
			catch(HibernateException he)
			{
				he.printStackTrace();				
				
			}
			finally
			{
				HibernateUtils.closeConnection(session);
			}	
		return pf;
		
	}
	public static String getPosition(int u)
	{
		Session session = null;
		List<Double> pf1 = null;
		List<Double> pf2 = null;
		Query hqlQuery;
		String s =null;
		try{
			session = HibernateUtils.getHibernateConnection();	
			
			hqlQuery = session.createQuery("select x FROM Samplepoint WHERE sample_point = :cid ")
					.setInteger("cid", u);
			pf1 = hqlQuery.list();
			hqlQuery = session.createQuery("select y FROM Samplepoint WHERE sample_point = :cid ")
					.setInteger("cid", u);
			pf2 = hqlQuery.list();
			
			s = pf1.get(0)+","+pf2.get(0);
		}
			catch(HibernateException he)
			{
				he.printStackTrace();				
				
			}
			finally
			{
				HibernateUtils.closeConnection(session);
				
			}	
		
		return s;
		
	}

	public static String Fingerprint_online(String s) {
		
System.out.println("***************** Estimating *********");
		  
		
		String result = " ";
				
					try {
						double f=0,g=0,h=0,f1=0,g1=0,h1=0,exp1=0,exp2=0,exp3=0;
						JSONObject  jo = new JSONObject(s);
						List<String> map = new ArrayList<String>();
						Iterator iter = jo.keys();
						 while(iter.hasNext()){
						   String key = (String)iter.next();
						   
						   map.add(key);
						 }
						f =  jo.getDouble(map.get(0));
						   g =  jo.getDouble(map.get(1));
						   h =  jo.getDouble(map.get(2));
						   result=" "+f+" "+g+" "+h+" ";
							 
							// SamplepointDAO t=new SamplepointDAO();
							 List<String> Sp;
							 double sum=0;
							 Sp=  getFingerprint();
							 int i=0,k=0;
							 double min=1000;
							 for(i=0;i<Sp.size();i++){
							 JSONObject j;
							
								j = new JSONObject(Sp.get(i));
								if(j.has(map.get(0)) && j.has(map.get(1)) && j.has(map.get(2))){
								f1 =  j.getDouble(map.get(0)); 
								  g1 =  j.getDouble(map.get(1));
								  h1 =  j.getDouble(map.get(2));
								  
								  exp1 =  (double) Math.pow(f-f1, 2);
								  exp2 = (double) Math.pow(g-g1, 2);
								  exp3 = (double) Math.pow(h-h1, 2);
								 
								  sum = exp1 + exp2 + exp3;
								 sum= (double) Math.sqrt(sum);
								 System.out.println("Sum \n"+sum);
								 if(sum < min){
									min = sum; 
									k=i+1;
								 }
								 /*if (array[i] < firstmin) 
							        { 
							            thirdmin = secmin; 
							            secmin = firstmin; 
							            firstmin = array[i]; 
							        } 
							  
							         Check if current element is less than 
							        secmin then update second and third 
							        else if (array[i] < secmin) 
							        { 
							            thirdmin = secmin; 
							            secmin = array[i]; 
							        } 
							  
							         Check if current element is less than 
							        then update third 
							        else if (array[i] < thirdmin) 
							            thirdmin = array[i]; 
								 
								*/
								}
								else{
									
								}
								
							  
							 }
							 System.out.println( "location is near "+k +"th sample point") ;
								result = getPosition(k);
								System.out.println( getPosition(k)) ;
					} catch (JSONException e1) {
						
						e1.printStackTrace();
						result=" failed";
					}
						
				
				 
			
		
		 
		  
		 
		  return result;
	}
	public static String Fingerprint_on_K4(String s) {
		
		System.out.println("***************** Estimating *********");
				  
				
				String result = " ";
						
							try {
								double f=0,g=0,h=0,f1=0,g1=0,h1=0,exp1=0,exp2=0,exp3=0;
								JSONObject  jo = new JSONObject(s);
								List<String> map = new ArrayList<String>();
								Iterator iter = jo.keys();
								 while(iter.hasNext()){
								   String key = (String)iter.next();
								   
								   map.add(key);
								 }
								f =  jo.getDouble(map.get(0));
								   g =  jo.getDouble(map.get(1));
								   h =  jo.getDouble(map.get(2));
								   result=" "+f+" "+g+" "+h+" ";
									 
									// SamplepointDAO t=new SamplepointDAO();
									 List<String> Sp;
									 double sum=0,firstmin=1000,secmin=1000,thirdmin=1000,fourthmin=1000;
									 Sp=  getFingerprint();
									 int i=0,k1=0,k2=0,k3=0,k4=0;
									// double min=1000;
									 for(i=0;i<Sp.size();i++){
									 JSONObject j;
									
										j = new JSONObject(Sp.get(i));
										if(j.has(map.get(0)) && j.has(map.get(1)) && j.has(map.get(2))){
										f1 =  j.getDouble(map.get(0)); 
										  g1 =  j.getDouble(map.get(1));
										  h1 =  j.getDouble(map.get(2));
										  
										  exp1 =  (double) Math.pow(f-f1, 2);
										  exp2 = (double) Math.pow(g-g1, 2);
										  exp3 = (double) Math.pow(h-h1, 2);
										 
										  sum = exp1 + exp2 + exp3;
										 sum= (double) Math.sqrt(sum);
										 System.out.println("Sum \n"+sum);
										 if (sum < firstmin) 
									        { 
												fourthmin = thirdmin; 
												k4 = k3;
									            thirdmin = secmin; 
									            k3=k2;
									            secmin = firstmin; 
									            k2=k1;
									            firstmin = sum; 
									            k1=i+1;
									        } 
									  
									         
									        else if (sum < secmin) 
									        { 
												fourthmin = thirdmin;
												k4 = k3;
									            thirdmin = secmin; 
									            k3=k2;
									            secmin = sum; 
									            k2=i+1;
									        } 
									  
									         
									        else if (sum < thirdmin) {
												fourthmin=thirdmin;
												k4 = k3;
									            thirdmin = sum; 
									            k3=i+1;
												}
												
											else if (sum < fourthmin){
												fourthmin = sum;
												k4=i+1;
												}
										 
										}
										
										
									  
									 }
									 System.out.println( "location is near "+k1+" "+k2+" "+k3+" "+k4 +"th sample point") ;
										result = avg(getPosition(k1), getPosition(k2), getPosition(k3), getPosition(k4));
										//System.out.println( getPosition(k)) ;
							} catch (JSONException e1) {
								
								e1.printStackTrace();
								result=" failed";
							}
			
				  return result;
			}


	private static String avg(String position, String position2,
			String position3, String position4) {
		
		String[] latlong = position.split(",");
        double latitude = Double.parseDouble(latlong[0]);
       double longitude = Double.parseDouble(latlong[1]);
       
       String[] latlong2 = position2.split(",");
       double latitude2 = Double.parseDouble(latlong2[0]);
      double longitude2 = Double.parseDouble(latlong2[1]);
      
      String[] latlong3 = position3.split(",");
      double latitude3 = Double.parseDouble(latlong3[0]);
     double longitude3 = Double.parseDouble(latlong3[1]);
     
     String[] latlong4 = position4.split(",");
     double latitude4 = Double.parseDouble(latlong4[0]);
    double longitude4 = Double.parseDouble(latlong4[1]);
    
    double avg1 = (latitude + latitude2 +latitude3 +latitude4)/4 ;
    double avg2 = (longitude + longitude2 +longitude3 +longitude4)/4;
    
    String s = avg1+","+avg2;
       
		return s;
	}
	  


	
	
	
	
	
	
	
	

}
