package com.amrita.aerl.suraksha.dao;

import java.sql.Timestamp;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;

import com.amrita.aerl.suraksha.entities.FFContactDetails;
import com.amrita.aerl.suraksha.entities.NotificationDetails;
import com.amrita.aerl.suraksha.entities.NotificationRecipientsDetails;
import com.amrita.aerl.suraksha.entities.UserDetails;
import com.amrita.aerl.suraksha.gcm.server.SendAllMessagesServlet;
import com.amrita.aerl.suraksha.helper.SurakshaHelper;
import com.amrita.aerl.suraksha.utils.HibernateUtils;
import com.amrita.aerl.suraksha.utils.TimeStampUtils;

public class NotificationDAO 
{
private static int result = 0;
	
	public static int addingEventLoc(String usrNum, String usrLocation,String usrAdress)
	{
		
		Session session = null;
		String createdDateTime = null;
		
		try {
			
			List<UserDetails> usrDetails = getUsrId(usrNum);			
			System.out.println("*****************UsrID*********" + usrDetails.get(0).getId() );			
			session = HibernateUtils.getHibernateConnection();
			session.beginTransaction();
			NotificationDetails notificationDetails = new NotificationDetails();
			notificationDetails.setSenderId(usrDetails.get(0).getId());
			notificationDetails.setUserLocation(usrLocation);
			notificationDetails.setLocationAddress(usrAdress);
			notificationDetails.setActiveYN(1);
			createdDateTime = TimeStampUtils.getCurrentTimestamp().toString();
			notificationDetails.setCreatedDateTime(Timestamp.valueOf(createdDateTime));
			notificationDetails.setModifiedDateTime(TimeStampUtils.getCurrentTimestamp());			
			session.save(notificationDetails);
			session.getTransaction().commit();
			int notificationId = getNotificationId(usrDetails.get(0).getId(),usrLocation,usrAdress,createdDateTime);
			getReceiverIds(usrDetails.get(0).getId(),notificationId);
			return notificationId;
		}catch(HibernateException he){
			he.printStackTrace();
			result = 0;
			return result;
		}finally{
			HibernateUtils.closeConnection(session);
		}		
		
	}
	
	private static List<UserDetails> getUsrId(String usrNumber)
	{
		Session session = null;
		List<UserDetails> usrDetails = null;
		Query hqlQuery;
		
		try{
			session = HibernateUtils.getHibernateConnection();	
			
			hqlQuery = session.createQuery(" FROM UserDetails UD " +
					" WHERE UD.activeYN = :activeYES " +
					" AND UD.userMobileNumber = :cid ")
					.setString("cid", usrNumber)
					.setInteger("activeYES", 1);
			usrDetails = hqlQuery.list();
			
			
		}
			catch(HibernateException he)
			{
				he.printStackTrace();				
				
			}
			finally
			{
				HibernateUtils.closeConnection(session);
			}	
		return usrDetails;
		
	}
	
	
	private static void setNotificationRecipients( int senderID , int receiverID, int notificationId )	
	{
		Session session = null;
		
		try {
			session = HibernateUtils.getHibernateConnection();
			session.beginTransaction();	
			NotificationRecipientsDetails notificationRecipientsDetails = new NotificationRecipientsDetails();
			notificationRecipientsDetails.setSenderId(senderID);
			notificationRecipientsDetails.setReceiverId(receiverID);
			notificationRecipientsDetails.setNotificationId(notificationId);
			notificationRecipientsDetails.setViewedStatus("S");
			notificationRecipientsDetails.setActiveYN(1);
			notificationRecipientsDetails.setCreatedDateTime(TimeStampUtils.getCurrentTimestamp());
			notificationRecipientsDetails.setModifiedDateTime(TimeStampUtils.getCurrentTimestamp());			
			session.save(notificationRecipientsDetails);
			session.getTransaction().commit();	
			gcmSendNotification(receiverID);
					
		}catch(HibernateException he){
			he.printStackTrace();
			
		}finally{
			HibernateUtils.closeConnection(session);
		}		
	}
	
	private static void getReceiverIds(int usrID, int notificationId)
	{
		
		Session session = null;
		List<UserDetails> usrDetails = null;
		List<FFContactDetails> buddyDetails = null;
		Query hqlQuery, hqlQuery1, hqlQuery2;
		
		try{
			session = HibernateUtils.getHibernateConnection();	
			
			hqlQuery = session.createQuery(" FROM FFContactDetails FD " +
					" WHERE FD.activeYN = :activeYES " +
					" AND FD.userId = :cid ")
					.setInteger("cid", usrID)
					.setInteger("activeYES", 1);
			buddyDetails = hqlQuery.list();
			System.out.println("response : "+buddyDetails.size());
			
			if (buddyDetails.size() == 0 || buddyDetails.isEmpty() )
			{
				System.out.println("response : "+buddyDetails.size()+"Zerooooooo Value");
			}
			
			else
			{
				for (int i = 0; i < buddyDetails.size(); i++) 
				{
					try
					{
						String usrNumber = buddyDetails.get(i).getContactPersonNumber(); 
						System.out.println("response : "+buddyDetails.get(i).getContactPersonNumber()+"Buddy");
						hqlQuery1 = session.createQuery(" FROM UserDetails UD " +
								" WHERE UD.activeYN = :activeYES " +
								" AND UD.userMobileNumber = :cid ")
								.setString("cid", usrNumber)
								.setInteger("activeYES", 1);
						usrDetails = hqlQuery1.list();
						
						if (usrDetails.size() == 0 || usrDetails.isEmpty() )
						{
							System.out.println("Receiver is not a Suraksha user");							
						}
						else
						{
							setNotificationRecipients(usrID, usrDetails.get(0).getId(),notificationId);
						}
					}
					catch(HibernateException he)
					{
						he.printStackTrace();
					}
					
				}
			}		
			
		}
			catch(HibernateException he)
			{
				he.printStackTrace();
				
			}
			finally
			{
				HibernateUtils.closeConnection(session);
			}	
		
	}
	
	
	private static int  getNotificationId(int usrID, String usrLocations, String usrAdd, String dateTime)
	{
		Session session = null;
		List<NotificationDetails> notificationDetails = null;
		Query hqlQuery;
		
		try{
			session = HibernateUtils.getHibernateConnection();	
			
			hqlQuery = session.createQuery(" FROM NotificationDetails ND " +
					" WHERE ND.activeYN = :activeYES " +
					" AND ND.userLocation = :usLoc " +
					" AND ND.locationAddress = :usAdd " +
					" AND ND.createdDateTime = :dateTim " +
					" AND ND.senderId = :cid ")
					.setInteger("cid", usrID)
					.setString("usLoc", usrLocations)
					.setString("usAdd", usrAdd)
					.setString("dateTim", dateTime)
					.setInteger("activeYES", 1);
			notificationDetails = hqlQuery.list();
			
			
		}
			catch(HibernateException he)
			{
				he.printStackTrace();				
				
			}
			finally
			{
				HibernateUtils.closeConnection(session);
			}	
		return notificationDetails.get(0).getId();
		
		
	}
	
	
	public static void gcmSendNotification(int receiver)
	{
		List<String> devices = SurakshaHelper.fetchRegIds(receiver);
	    if (devices.isEmpty()) {
	    	System.out.println("*****************No device Registered*********");
	    } else {
	    	System.out.println("*****************"+devices.size()+"Devices Registered*********");
	    	try {
				SendAllMessagesServlet.main(receiver);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    }
	}
	
	
}
