/**
 * 
 */
package com.amrita.aerl.suraksha.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;




import com.amrita.aerl.suraksha.entities.GCMRegId;
import com.amrita.aerl.suraksha.entities.UserDetails;
import com.amrita.aerl.suraksha.utils.HibernateUtils;
import com.amrita.aerl.suraksha.utils.TimeStampUtils;

/**
 * @author rvinoth
 *
 */
public class GCMserverDAO {
	
	private static String result = null;
	public static List<GCMRegId> gcmDetails = null;
	public static String addingRegId(String usrNum,String regId)
	{
		Session session = null;
		List<UserDetails> usrDetails = getUsrId(usrNum);
		System.out.println("*****************UsrID*********" + usrDetails.get(0).getId() );
		
		if (isAvailable(usrDetails.get(0).getId()))
		{
			System.out.println("*****************Already Available*********" + usrDetails.get(0).getId() );
			for(int i=0; i<gcmDetails.size();i++)
			{
				session = HibernateUtils.getHibernateConnection();
				session.beginTransaction();
				GCMRegId regDetails = new GCMRegId();
				regDetails.setId(gcmDetails.get(i).getId());
				regDetails.setUserId(gcmDetails.get(i).getUserId());
				regDetails.setRegId(gcmDetails.get(i).getRegId());
				regDetails.setActiveYN(0);				
				regDetails.setCreatedDateTime(gcmDetails.get(i).getCreatedDateTime());
				regDetails.setModifiedDateTime(TimeStampUtils.getCurrentTimestamp());			
				session.update(regDetails);		
				session.getTransaction().commit();
			}		
			
		}		
		try {
			System.out.println("*****************adding in GCM Reg id*********");								
			session = HibernateUtils.getHibernateConnection();
			session.beginTransaction();			
			GCMRegId regDetails = new GCMRegId();
			regDetails.setUserId(usrDetails.get(0).getId());
			regDetails.setRegId(regId);			
			regDetails.setActiveYN(1);
			regDetails.setCreatedDateTime(TimeStampUtils.getCurrentTimestamp());
			regDetails.setModifiedDateTime(TimeStampUtils.getCurrentTimestamp());			
			session.save(regDetails);		
			session.getTransaction().commit();				
			result = "Added";
			return result;
		}		
			
		catch(HibernateException he){
			he.printStackTrace();
			result = "error";
			return result;
		}finally{
			HibernateUtils.closeConnection(session);
		}
	
	
	}
	
	private static List<UserDetails> getUsrId(String usrNumber)
	{
		Session session = null;
		List<UserDetails> usrDetails = null;
		Query hqlQuery;
		
		try{
			session = HibernateUtils.getHibernateConnection();	
			
			hqlQuery = session.createQuery(" FROM UserDetails UD " +
					" WHERE UD.activeYN = :activeYES " +
					" AND UD.userMobileNumber = :cid ")
					.setString("cid", usrNumber)
					.setInteger("activeYES", 1);
			usrDetails = hqlQuery.list();
			
			
		}
			catch(HibernateException he)
			{
				he.printStackTrace();				
				
			}
			finally
			{
				HibernateUtils.closeConnection(session);
			}	
		return usrDetails;
		
	}
	
	
	public static ArrayList<String> getUsrRegId(int usrId)
	{
		Session session = null;
		List<GCMRegId> usrGCMDetails = null;
		Query hqlQuery;
		
		ArrayList<String> regIds = new ArrayList<String>();
		
		try{
			session = HibernateUtils.getHibernateConnection();	
			
			hqlQuery = session.createQuery(" FROM GCMRegId UD " +
					" WHERE UD.activeYN = :activeYES " +
					" AND UD.userId = :cid ")
					.setInteger("cid", usrId)
					.setInteger("activeYES", 1);
			usrGCMDetails = hqlQuery.list();
			
			for (int i=0 ; i< usrGCMDetails.size(); i++)
			{
				regIds.add(usrGCMDetails.get(i).getRegId().toString());
			}
			
			
		}
			catch(HibernateException he)
			{
				he.printStackTrace();				
				
			}
			finally
			{
				HibernateUtils.closeConnection(session);
			}		
		return regIds;
		
	}
	
	
	private static boolean isAvailable(int usrid)
	{
		Session session = null;		
		Query hqlQuery;
		
		try{
			session = HibernateUtils.getHibernateConnection();	
			
			hqlQuery = session.createQuery(" FROM GCMRegId UD " +
					" WHERE UD.activeYN = :activeYES " +
					" AND UD.userId = :cid ")
					.setInteger("cid", usrid)
					.setInteger("activeYES", 1);
			gcmDetails = hqlQuery.list();
			
			if(!gcmDetails.isEmpty())
			{
				return true;
			}
			else 
			{
				return false;
			}
		}
			catch(HibernateException he)
			{
				he.printStackTrace();
				return true;
				
			}
			finally
			{
				HibernateUtils.closeConnection(session);
			}	
		
	}
	
	

}
