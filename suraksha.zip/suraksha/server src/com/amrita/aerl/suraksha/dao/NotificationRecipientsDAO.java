package com.amrita.aerl.suraksha.dao;

import java.lang.reflect.Array;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;

import com.amrita.aerl.suraksha.entities.MediaFileDetails;
import com.amrita.aerl.suraksha.entities.NotificationDetails;
import com.amrita.aerl.suraksha.entities.NotificationRecipientsDetails;
import com.amrita.aerl.suraksha.entities.UserDetails;
import com.amrita.aerl.suraksha.utils.HibernateUtils;
import com.amrita.aerl.suraksha.utils.TimeStampUtils;




public class NotificationRecipientsDAO 
{
	
	private static String result = null;
	
	public static String checkNotification(String usrNum)
	{
		
		Session session = null;
		Query hqlQuery;		
		List<NotificationRecipientsDetails> notificationRecipients = null;
		try {
			System.out.println("********NotificationRecipientsDetails Table insert*********");
			List<UserDetails> usrDetails = getUsrId(usrNum);			
			System.out.println("*****************UsrID*********" + usrDetails.get(0).getId() );			
			session = HibernateUtils.getHibernateConnection();
			hqlQuery = session.createQuery(" FROM NotificationRecipientsDetails NR " +
					" WHERE NR.activeYN = :activeYES " +
					" AND NR.viewedStatus = :viewedStatus " +
					" AND NR.receiverId = :cid ")
					.setInteger("cid", usrDetails.get(0).getId())
					.setString("viewedStatus", "S")
					.setInteger("activeYES", 1);
			notificationRecipients = hqlQuery.list();	
			
			if (notificationRecipients.size()==0)
			{
				result = "N";
				return result;
			}
			else
			{
				result = "Y";
				return result;
			}
			
		}catch(HibernateException he){
			he.printStackTrace();
			result = "Error";
			return result;
		}finally{
			HibernateUtils.closeConnection(session);
		}		
	}
	
	private static List<UserDetails> getUsrId(String usrNumber)
	{
		Session session = null;
		List<UserDetails> usrDetails = null;
		Query hqlQuery;
		
		try{
			session = HibernateUtils.getHibernateConnection();	
			
			hqlQuery = session.createQuery(" FROM UserDetails UD " +
					" WHERE UD.activeYN = :activeYES " +
					" AND UD.userMobileNumber = :cid ")
					.setString("cid", usrNumber)
					.setInteger("activeYES", 1);
			usrDetails = hqlQuery.list();
		}
		catch(HibernateException he)
		{
			he.printStackTrace();
		}
		finally
		{
			HibernateUtils.closeConnection(session);
		}	
		return usrDetails;
	}
	
	public static ArrayList getLatestNotifications(String usrNumber)
	{
		ArrayList details = new ArrayList();
		ArrayList imagedetails = new ArrayList();
		ArrayList videodetails = new ArrayList();
		ArrayList resultData = new ArrayList();
		Session session = null;
		Query hqlQuery,hqlQuery1,hqlQuery2,hqlQuery3,hqlQuery4;	
		List<NotificationRecipientsDetails> notificationRecipientsDetails = null;
		List<NotificationDetails> notificationDetails = null;
		List<MediaFileDetails> medDetails = null;
		List<UserDetails> senderDetails = null;
		List<NotificationRecipientsDetails> notifyRecipients= null;
		
		try {
			List<UserDetails> usrDetails = getUsrId(usrNumber);			
			System.out.println("*****************UsrID*********" + usrDetails.get(0).getId() );			
			session = HibernateUtils.getHibernateConnection();
			hqlQuery = session.createQuery(" FROM NotificationRecipientsDetails NRD " +
					" WHERE NRD.activeYN = :activeYES " +
					" AND NRD.viewedStatus = :viewedStatus " +
					" AND NRD.receiverId = :cid ")
					.setInteger("cid", usrDetails.get(0).getId())
					.setString("viewedStatus", "S")
					.setInteger("activeYES", 1);
			notificationRecipientsDetails = hqlQuery.list();
					
			if (notificationRecipientsDetails.size()==0)
			{
				System.out.println("*****************No New Notification*********" );
				details.add("No New Notification");
			}
			else
			{
				hqlQuery1 = session.createQuery(" FROM NotificationDetails ND " +
						" WHERE ND.activeYN = :activeYES " +
						" AND ND.id = :cid ")
						.setInteger("cid", notificationRecipientsDetails.get(0).getNotificationId())								
						.setInteger("activeYES", 1);
				notificationDetails = hqlQuery1.list();
				//Notification id,user location,location address and Notification created date time
				details.add(notificationRecipientsDetails.get(0).getNotificationId());
				details.add(notificationDetails.get(0).getUserLocation());
				details.add(notificationDetails.get(0).getLocationAddress());
				details.add(notificationDetails.get(0).getCreatedDateTime());
				
				hqlQuery3 = session.createQuery(" FROM UserDetails UD " +
						" WHERE UD.activeYN = :activeYES " 	+
						" AND UD.id = :cid ")
						.setInteger("cid", notificationRecipientsDetails.get(0).getSenderId())								
						.setInteger("activeYES", 1);
				senderDetails = hqlQuery3.list();
				//Sender name and mobile number
				details.add(getUsrName(senderDetails.get(0).getId()));
				details.add(senderDetails.get(0).getUserMobileNumber());
				
				hqlQuery2 = session.createQuery(" FROM MediaFileDetails MD " +
						" WHERE MD.activeYN = :activeYES " +
						" AND MD.notificationId = :cid ")
						.setInteger("cid", notificationRecipientsDetails.get(0).getNotificationId())								
						.setInteger("activeYES", 1);
				medDetails = hqlQuery2.list();
				for (int i=0; i<medDetails.size(); i++)
				{
					if(medDetails.get(i).getNotificationType().equals("Image"))
					{
						String data= new String();
						data = medDetails.get(i).getFileName();
						imagedetails.add(data);
					}
					else
					{
						String data= new String();
						data = medDetails.get(i).getFileName();
						videodetails.add(data);
					}
				}
				
				hqlQuery4 = session.createQuery(" FROM NotificationRecipientsDetails NRD " +
						" WHERE NRD.activeYN = :activeYES " +
						" AND NRD.senderId = :cid " +
						" AND NRD.notificationId = :notifyId ")
						.setInteger("cid", senderDetails.get(0).getId())
						.setInteger("notifyId",notificationRecipientsDetails.get(0).getNotificationId() )
						.setInteger("activeYES", 1);
				notifyRecipients = hqlQuery4.list();
				for(int j=0; j<notifyRecipients.size(); j++)
				{
					details.add(getUsrName(notifyRecipients.get(j).getReceiverId()));
				}
				
				for(int i=0; i<notificationRecipientsDetails.size(); i++)
				{
					updateNotificationRecipients(notificationRecipientsDetails.get(i).getId(), notificationRecipientsDetails.get(i).getSenderId(),notificationRecipientsDetails.get(i).getReceiverId(),notificationRecipientsDetails.get(i).getNotificationId(), notificationRecipientsDetails.get(i).getCreatedDateTime());
				}
				resultData.add(details);
				if(imagedetails.size() == 0)
				{
					String data= "No image notification";
					imagedetails.add(data);
				}
				resultData.add(imagedetails);
				if(videodetails.size() == 0)
				{
					String data=  "No video notification";
					videodetails.add(data);
				}
				resultData.add(videodetails);
			}
			
		}catch(HibernateException he){
			he.printStackTrace();
			
		}finally{
			HibernateUtils.closeConnection(session);
		}
		return resultData;
	}
	
	public static void updateNotificationRecipients(int id, int SendId, int RecId, int notificationId, Timestamp createdDateTime)
	{
		Session session = null;
		try{
			session = HibernateUtils.getHibernateConnection();
			session.beginTransaction();
			NotificationRecipientsDetails notificationRecipients = new NotificationRecipientsDetails();
			notificationRecipients.setId(id);
			notificationRecipients.setViewedStatus("R");
			notificationRecipients.setSenderId(SendId);
			notificationRecipients.setReceiverId(RecId);
			notificationRecipients.setNotificationId(notificationId);
			notificationRecipients.setActiveYN(1);
			notificationRecipients.setCreatedDateTime(createdDateTime);
			notificationRecipients.setModifiedDateTime(TimeStampUtils.getCurrentTimestamp());
			session.update(notificationRecipients);
			session.getTransaction().commit();
			System.out.println("Updated.....");
		}
		catch (HibernateException he) {
			he.printStackTrace();
		}
		finally{
			HibernateUtils.closeConnection(session);
			
		}
	}
	
	
	public static ArrayList<String> fetchNotifyDetails(String usrNum)
	{
		ArrayList<String> allDetails = new ArrayList<String>();
		Session session = null;
		Query hqlQuery;		
		List<NotificationRecipientsDetails> notificationRecipients = null;		
		try {
			List<UserDetails> usrDetails = getUsrId(usrNum);
			System.out.println("*****************UsrID*********" + usrDetails.get(0).getId() );			
			session = HibernateUtils.getHibernateConnection();
			hqlQuery = session.createQuery(" FROM NotificationRecipientsDetails NR " +
					" WHERE NR.activeYN = :activeYES " +
					" AND NR.receiverId = :cid ")
					.setInteger("cid", usrDetails.get(0).getId())
					.setInteger("activeYES", 1);
			notificationRecipients = hqlQuery.list();
			
			if (notificationRecipients.size()==0)
			{
				System.out.println("*****************No Notification*********" );
			}
			else
			{	
				for(int i=0; i<notificationRecipients.size(); i++)
				{
					String data = new String();
					data = getUsrName(notificationRecipients.get(i).getSenderId())+','+ getUsrName(notificationRecipients.get(i).getReceiverId())+','+getDetails(notificationRecipients.get(i).getNotificationId());
					allDetails.add(data);
				}
			}
			
		}catch(HibernateException he){
			he.printStackTrace();
			
			}finally{
			HibernateUtils.closeConnection(session);
		}
		
		System.out.println("*****************Notification details:" + allDetails );
		return allDetails;
	}
	
	
	private static String getUsrName(int id)
	{
		Session session = null;
		List<UserDetails> userDetails=null;
		Query hqlQuery;
		
		try{
			session = HibernateUtils.getHibernateConnection();	
			
			hqlQuery = session.createQuery(" FROM UserDetails UD " +
					" WHERE UD.activeYN = :activeYES " +
					" AND UD.id = :cid ")
					.setInteger("cid", id)
					.setInteger("activeYES", 1);
			userDetails = hqlQuery.list();
		}
		catch(HibernateException he)
		{
			he.printStackTrace();
		}
		finally
		{
			HibernateUtils.closeConnection(session);
		}	
		return userDetails.get(0).getFirstName()+" "+userDetails.get(0).getLastName();
	}
	
	private static String getDetails(int notificationId)
	{
		String data=new String();
		Session session = null;
		Query hqlQuery1,hqlQuery2;
		List<NotificationDetails> notificationDetails = null;
		List<MediaFileDetails> medDetails = null;
		
		try{
			session = HibernateUtils.getHibernateConnection();
			
			hqlQuery1 = session.createQuery(" FROM NotificationDetails ND " +
					" WHERE ND.activeYN = :activeYES " +
					" AND ND.id = :cid ")
					.setInteger("cid", notificationId)
					.setInteger("activeYES", 1);
			notificationDetails = hqlQuery1.list();
			
			hqlQuery2 = session.createQuery(" FROM MediaFileDetails MD " +
					" WHERE MD.activeYN = :activeYES " +
					" AND MD.notificationId = :cid ")
					.setInteger("cid", notificationId)
					.setInteger("activeYES", 1);
			medDetails = hqlQuery2.list();
			
			if(medDetails.size() > 0){
				data=notificationDetails.get(0).getUserLocation()+","+medDetails.get(0).getFileName();
			}
			else
			{
				data=notificationDetails.get(0).getUserLocation();
			}
		}
		catch(HibernateException he)
		{
			he.printStackTrace();
		}
		finally
		{
			HibernateUtils.closeConnection(session);
		}
		return data; 
	}
	
	public static ArrayList getNotificationViewedStatus(String usrNumber,int notificationID)
	{
		ArrayList details = new ArrayList();
		Session session= null;
		Query hqlQuery;
		List<NotificationRecipientsDetails> notifyRecipients=null;
		try
		{
			List<UserDetails> usrDetails = getUsrId(usrNumber);	
			System.out.println("*****************UsrID*********" + usrDetails.get(0).getId() );	
			session = HibernateUtils.getHibernateConnection();
			hqlQuery = session.createQuery(" FROM NotificationRecipientsDetails NRD " +
					" WHERE NRD.activeYN = :activeYES " +
					" AND NRD.notificationId = :notifyID " +
					" AND NRD.senderId = :cid ")
					.setInteger("cid", usrDetails.get(0).getId())
					.setInteger("notifyID", notificationID)
					.setInteger("activeYES", 1);
					notifyRecipients = hqlQuery.list();
			if(notifyRecipients.size() > 0){
				for(int i=0; i<notifyRecipients.size(); i++)
				{
					details.add(getUsrName(notifyRecipients.get(i).getReceiverId()));
					details.add(notifyRecipients.get(i).getCreatedDateTime());
					details.add(notifyRecipients.get(i).getViewedStatus());
				}
			}
			else{
				details.add("No one received notification");
			}
		}
		catch(HibernateException he)
		{
			he.printStackTrace();
		}
		finally
		{
			
			HibernateUtils.closeConnection(session);
		}
		return details;
	}

}
