package com.amrita.aerl.suraksha.dao;

import java.sql.Timestamp;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;







import com.amrita.aerl.suraksha.entities.FFContactDetails;
import com.amrita.aerl.suraksha.entities.MediaFileDetails;
import com.amrita.aerl.suraksha.entities.NotificationRecipientsDetails;
import com.amrita.aerl.suraksha.entities.UserDetails;
import com.amrita.aerl.suraksha.utils.HibernateUtils;
import com.amrita.aerl.suraksha.utils.TimeStampUtils;

public class MediaFileDAO {
	
private static String result = null;
private static List<NotificationRecipientsDetails> notificationrecipientsDetails = null;
public static List<MediaFileDetails> mediaFileDetails = null;
	
	public static String addingMediaFile(String usrNum,int notificationId,String notificationType, String fileName,String filePath, String fileType)
	{
		
		Session session = null;
		String createdDateTime = null;
		
		try {
			System.out.println("*****************Adding Media Files*********");
			List<UserDetails> usrDetails = getUsrId(usrNum);			
			System.out.println("*****************UsrID*********" + usrDetails.get(0).getId() );	
			if(isMediaFileExists(notificationId,fileName))
			{
				result = "Media file already exists";
				System.out.println("response : "+ result);
				return result;
			}
			else
			{
				session = HibernateUtils.getHibernateConnection();
				session.beginTransaction();
				MediaFileDetails mediaDetails = new MediaFileDetails();
				mediaDetails.setUserId(usrDetails.get(0).getId());
				mediaDetails.setNotificationId(notificationId);
				mediaDetails.setNotificationType(notificationType);
				mediaDetails.setFileName(fileName);
				mediaDetails.setFilePath(filePath);
				mediaDetails.setFileType(fileType);
				mediaDetails.setActiveYN(1);
				createdDateTime = TimeStampUtils.getCurrentTimestamp().toString();
				mediaDetails.setCreatedDateTime(Timestamp.valueOf(createdDateTime));
				mediaDetails.setCreatedDateTime(TimeStampUtils.getCurrentTimestamp());
				mediaDetails.setModifiedDateTime(TimeStampUtils.getCurrentTimestamp());			
				session.save(mediaDetails);		
				session.getTransaction().commit();	
				int evntId = getEventId(usrDetails.get(0).getId(),fileName,fileType,createdDateTime);
				if(mapNotificationSent(notificationId)){
					getReceiverIds(usrDetails.get(0).getId(),evntId);
				}
				result = "Media file added";
				System.out.println("response : "+ result);
				return result;
			}
		}catch(HibernateException he){
			he.printStackTrace();
			result = "error";
			return result;
		}finally{
			HibernateUtils.closeConnection(session);
		}
	}
	
	private static boolean isMediaFileExists(int notificationId,String fileName)
	{
		Session session  = null;
		Query hqlQuery;
		
		try
		{
			session = HibernateUtils.getHibernateConnection();
			hqlQuery  = session.createQuery("select md from MediaFileDetails md " +
					"where md.notificationId=:notificationID and md.fileName = :fileName ");
			hqlQuery.setInteger("notificationID", notificationId);
			hqlQuery.setString("fileName", fileName);
			mediaFileDetails = hqlQuery.list();
			
			if(!mediaFileDetails.isEmpty())
			{
				return true;
			}
			else 
			{
				return false;
			}
		}
		catch(HibernateException he)
		{
			he.printStackTrace();
			return true;
			
		}
		finally
		{
			HibernateUtils.closeConnection(session);
		}
	}
	
	private static boolean mapNotificationSent(int notificationId)
	{
		Session session = null;
		Query hqlQuery;
		
		try
		{
			session = HibernateUtils.getHibernateConnection();
			hqlQuery  = session.createQuery("select nd from NotificationRecipientsDetails nd " +
					"where nd.notificationId =:notificationID and nd.activeYN = :activeYES ");
			hqlQuery.setInteger("notificationID", notificationId);
			hqlQuery.setInteger("activeYES", 1);
			notificationrecipientsDetails = hqlQuery.list();
			
			for(int i=0; i<notificationrecipientsDetails.size(); i++ )
			{
				if(notificationrecipientsDetails.get(i).getViewedStatus().equals("S"))
				{
					return true;
				}
				else
				{
					updateViewedStatus();
					return true;
				}
			}
		}
		catch (HibernateException he) {
			he.printStackTrace();
			return true;
		}
		finally{
			HibernateUtils.closeConnection(session);
			
		}
		return true;
	}
	
	private static void updateViewedStatus()
	{
		Session session = null;
		try{
			for(int i=0; i<notificationrecipientsDetails.size(); i++ )
			{
				session = HibernateUtils.getHibernateConnection();
				session.beginTransaction();
				NotificationRecipientsDetails notifyDetails = (NotificationRecipientsDetails)(notificationrecipientsDetails.get(i));
				notifyDetails.setViewedStatus("S");
				notifyDetails.setModifiedDateTime(TimeStampUtils.getCurrentTimestamp());
				session.update(notifyDetails);
				session.getTransaction().commit();
				System.out.println("Updated.....");
			}
		}
		catch (HibernateException he) {
			he.printStackTrace();
		}
		finally{
			HibernateUtils.closeConnection(session);
			
		}
	}
	
	
	private static List<UserDetails> getUsrId(String usrNumber)
	{
		Session session = null;
		List<UserDetails> usrDetails = null;
		Query hqlQuery;
		
		try{
			session = HibernateUtils.getHibernateConnection();	
			
			hqlQuery = session.createQuery(" FROM UserDetails UD " +
					" WHERE UD.activeYN = :activeYES " +
					" AND UD.userMobileNumber = :cid ")
					.setString("cid", usrNumber)
					.setInteger("activeYES", 1);
			usrDetails = hqlQuery.list();
			
			
		}
			catch(HibernateException he)
			{
				he.printStackTrace();				
				
			}
			finally
			{
				HibernateUtils.closeConnection(session);
			}	
		return usrDetails;
		
	}
	
	
	private static void getReceiverIds(int usrID, int evntId)
	{
		
		Session session = null;
		List<UserDetails> usrDetails = null;
		List<FFContactDetails> buddyDetails = null;
		Query hqlQuery, hqlQuery1;
		
		try{
			session = HibernateUtils.getHibernateConnection();	
			
			hqlQuery = session.createQuery(" FROM FFContactDetails FD " +
					" WHERE FD.activeYN = :activeYES " +
					" AND FD.userId = :cid ")
					.setInteger("cid", usrID)
					.setInteger("activeYES", 1);
			buddyDetails = hqlQuery.list();
			System.out.println("response : "+buddyDetails.size());
			
			if (buddyDetails.size() == 0 || buddyDetails.isEmpty() )
			{
				System.out.println("response : "+buddyDetails.size()+"Zerooooooo Value");
			}
			
			else
			{
				for (int i = 0; i < buddyDetails.size(); i++) 
				{
					try
					{
						String usrNumber = buddyDetails.get(i).getContactPersonNumber(); 
						System.out.println("response : "+buddyDetails.get(i).getContactPersonNumber()+"Buddy");
						hqlQuery1 = session.createQuery(" FROM UserDetails UD " +
								" WHERE UD.activeYN = :activeYES " +
								" AND UD.userMobileNumber = :cid ")
								.setString("cid", usrNumber)
								.setInteger("activeYES", 1);
						usrDetails = hqlQuery1.list();
						
						if (usrDetails.size() == 0 || usrDetails.isEmpty() )
						{
							System.out.println("Receiver is not a Suraksha user");
						}
						else
						{
							setNotificationRecipients(usrID, usrDetails.get(0).getId(),evntId);
						}
					}
					catch(HibernateException he)
					{
						he.printStackTrace();
					}
					
				}
			}		
			
		}
			catch(HibernateException he)
			{
				he.printStackTrace();				
				
			}
			finally
			{
				HibernateUtils.closeConnection(session);
			}	
		
	}
	
	private static void setNotificationRecipients( int senderID , int receiverID , int notificationId )	
	{
		Session session = null;
		
		try {	
			session = HibernateUtils.getHibernateConnection();
			session.beginTransaction();
			NotificationRecipientsDetails notificationRecipientsDetails = new NotificationRecipientsDetails();
			notificationRecipientsDetails.setSenderId(senderID);
			notificationRecipientsDetails.setReceiverId(receiverID);
			notificationRecipientsDetails.setNotificationId(notificationId);
			notificationRecipientsDetails.setViewedStatus("S");
			notificationRecipientsDetails.setActiveYN(1);
			notificationRecipientsDetails.setCreatedDateTime(TimeStampUtils.getCurrentTimestamp());
			notificationRecipientsDetails.setModifiedDateTime(TimeStampUtils.getCurrentTimestamp());			
			session.save(notificationRecipientsDetails);
			session.getTransaction().commit();	
			NotificationDAO.gcmSendNotification(receiverID);
		}catch(HibernateException he){
			he.printStackTrace();
			
		}finally{
			HibernateUtils.closeConnection(session);
		}		
	}
	
	
	private static int  getEventId(int usrID, String fileName, String fileType, String dateTime)
	{
		Session session = null;
		List<MediaFileDetails> evntDetails = null;
		Query hqlQuery;
		
		try{
			session = HibernateUtils.getHibernateConnection();	
			
			hqlQuery = session.createQuery(" FROM MediaFileDetails MD " +
					" WHERE MD.activeYN = :activeYES " +
					" AND MD.fileName = :fname " +
					" AND MD.fileType = :ftype " +
					" AND MD.createdDateTime = :dateTim " +
					" AND MD.userId = :cid ")
					.setInteger("cid", usrID)
					.setString("fname", fileName)
					.setString("ftype", fileType)
					.setString("dateTim", dateTime)
					.setInteger("activeYES", 1);
			evntDetails = hqlQuery.list();
			
			
		}
			catch(HibernateException he)
			{
				he.printStackTrace();				
				
			}
			finally
			{
				HibernateUtils.closeConnection(session);
			}	
		return evntDetails.get(0).getId();
		
		
	}

}
