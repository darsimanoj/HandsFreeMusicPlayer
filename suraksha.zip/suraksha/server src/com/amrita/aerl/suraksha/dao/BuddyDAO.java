package com.amrita.aerl.suraksha.dao;


import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;

import com.amrita.aerl.suraksha.entities.FFContactDetails;
import com.amrita.aerl.suraksha.entities.UserDetails;
import com.amrita.aerl.suraksha.utils.HibernateUtils;
import com.amrita.aerl.suraksha.utils.TimeStampUtils;


public class BuddyDAO {
	
	
private static String result = null;
public static List<FFContactDetails> contactDetails= null;
	
	public static String addingBuddy(String usrNum,String buddyName,String buddyNum)
	{
		
		Session session = null;
		List<UserDetails> usrDetails = getUsrId(usrNum);
		System.out.println("*****************UsrID*********" + usrDetails.get(0).getId() );
		int userId=usrDetails.get(0).getId();
		try
		{
			if(isBuddyExists(userId,buddyNum)){
				session = HibernateUtils.getHibernateConnection();
				session.beginTransaction();	
				FFContactDetails buddyDetails = (FFContactDetails)(contactDetails.get(0));
				if(isAvailable(buddyNum))
				{
					buddyDetails.setAppUserYN("Y");
				}
				else
				{
					buddyDetails.setAppUserYN("N");
				}
				buddyDetails.setActiveYN(1);
				buddyDetails.setCreatedDateTime(TimeStampUtils.getCurrentTimestamp());
				buddyDetails.setModifiedDateTime(TimeStampUtils.getCurrentTimestamp());	
				session.update(buddyDetails);
				session.getTransaction().commit();
				if(isAvailable(buddyNum))
				{
					result = "Updated Buddy is a Suraksha app user";
				}
				else{
					result = "Updated Buddy is not a Suraksha app user";
				}
				return result;
			}
			else
			{
				session = HibernateUtils.getHibernateConnection();
				session.beginTransaction();	
				FFContactDetails buddyDetails = new FFContactDetails();
				buddyDetails.setUserId(userId);
				buddyDetails.setContactPersonName(buddyName);
				buddyDetails.setContactPersonNumber(buddyNum);
				if(isAvailable(buddyNum))
				{
					buddyDetails.setAppUserYN("Y");
				}
				else
				{
					buddyDetails.setAppUserYN("N");
				}
				buddyDetails.setActiveYN(1);
				buddyDetails.setCreatedDateTime(TimeStampUtils.getCurrentTimestamp());
				buddyDetails.setModifiedDateTime(TimeStampUtils.getCurrentTimestamp());			
				session.save(buddyDetails);	
				session.getTransaction().commit();
				if(isAvailable(buddyNum))
				{
					result="Added Buddy is a Suraksha App user";
				}
				else
				{
					result="Added Buddy is not a Suraksha App user";
				}
				return result;
			}
		}
		catch(HibernateException he){
			he.printStackTrace();
			result = "error";
			return result;
		}finally{
			HibernateUtils.closeConnection(session);
		}		
		
	}
	
	public static String deleteBuddy(String usrNum,String buddyNum)
	{
		
		Session session = null;
		
		try {
			List<UserDetails> usrDetails = getUsrId(usrNum);			
			System.out.println("********Deleting Buddy of user: *********"+ usrDetails.get(0).getId() );			
			session = HibernateUtils.getHibernateConnection();
			session.beginTransaction();			
			
			Query hqlQuery  = session.createQuery("select ff from FFContactDetails ff " +
					"where ff.userId=:user_Id and ff.contactPersonNumber = :buddyNum " +
					"and ff.activeYN = :activeYES");
			
			hqlQuery.setInteger("user_Id", usrDetails.get(0).getId());
			hqlQuery.setString("buddyNum", buddyNum);
			hqlQuery.setInteger("activeYES", 1);
			
			List temp = hqlQuery.list();
			
			if(temp.size() == 1)
			{
				FFContactDetails buddyDetails;
				buddyDetails = (FFContactDetails)(temp.get(0));
				
				buddyDetails.setActiveYN(0);
				buddyDetails.setModifiedDateTime(TimeStampUtils.getCurrentTimestamp());	
				session.update(buddyDetails);
				session.getTransaction().commit();
				
				System.out.println("********Deleted Buddy*********");
				result = "Deleted";
			}
			else if(temp.size() == 0)
			{
				System.out.println("Warning :: No Buddy found for deletion or Buddy already deleted");
				result = "NoBuddyFound";
			}
			else if(temp.size() > 1)
			{
				System.out.println("Warning :: More than one buddy found for deletion with same input");
				result = "DuplicateBuddiesFound";
			}
			
			return result;
		
			
		}catch(HibernateException he){
			he.printStackTrace();
			result = "error";
			return result;
		}finally{
			HibernateUtils.closeConnection(session);
		}		
		
	}
	
	
	private static List<UserDetails> getUsrId(String usrNumber)
	{
		Session session = null;
		List<UserDetails> usrDetails = null;
		Query hqlQuery;
		
		try{
			session = HibernateUtils.getHibernateConnection();	
			
			hqlQuery = session.createQuery(" FROM UserDetails UD " +
					" WHERE UD.activeYN = :activeYES " +
					" AND UD.userMobileNumber = :cid ")
					.setString("cid", usrNumber)
					.setInteger("activeYES", 1);
			usrDetails = hqlQuery.list();
			
			
		}
			catch(HibernateException he)
			{
				he.printStackTrace();				
				
			}
			finally
			{
				HibernateUtils.closeConnection(session);
			}	
		return usrDetails;
		
	}
	
	
	private static boolean isAvailable(String usrNumber)
	{
		Session session = null;
		List<UserDetails> usrDetails = null;
		Query hqlQuery;
		
		try{
			session = HibernateUtils.getHibernateConnection();	
			
			hqlQuery = session.createQuery(" FROM UserDetails UD " +
					" WHERE UD.activeYN = :activeYES " +
					" AND UD.userMobileNumber LIKE :cid ")
					.setString("cid", "%"+usrNumber+"%")
					.setInteger("activeYES", 1);
			usrDetails = hqlQuery.list();			
			if(!usrDetails.isEmpty())
			{
				System.out.println(usrDetails.get(0).getUserMobileNumber());
				return true;
			}
			else 
			{
				
				return false;
			}
		}
			catch(HibernateException he)
			{
				he.printStackTrace();
				return true;
				
			}
			finally
			{
				HibernateUtils.closeConnection(session);
			}	
		
	}
	
	private static boolean isBuddyExists(int usrId,String buddyNumber)
	{
		Session session = null;
		Query hqlQuery;
		
		try{
			session = HibernateUtils.getHibernateConnection();	
			
			hqlQuery  = session.createQuery("select ff from FFContactDetails ff " +
					"where ff.userId=:user_Id and ff.contactPersonNumber = :buddyNum ");
			hqlQuery.setInteger("user_Id", usrId);
			hqlQuery.setString("buddyNum", buddyNumber);
			
			contactDetails = hqlQuery.list();
			if(!contactDetails.isEmpty())
			{
				return true;
			}
			else 
			{
				return false;
			}
		}
		catch(HibernateException he)
		{
			he.printStackTrace();
			return true;
			
		}
		finally
		{
			HibernateUtils.closeConnection(session);
		}
	}
	
	public static ArrayList<String> getFriendsList(String usrNum)
	{		
		ArrayList<String> friendsList = new ArrayList<String>();
		List<FFContactDetails>contactDetails = null;
		Session session = null;
		Query hqlQuery;		
		try 
		{
			session = HibernateUtils.getHibernateConnection();
			
			List<UserDetails> usrDetails = getUsrId(usrNum);
			int id = usrDetails.get(0).getId();
			
			hqlQuery = session.createQuery(" select ff from FFContactDetails ff " +
					"where ff.userId=:user_Id and ff.activeYN = :activeYES")
					.setInteger("user_Id", id)
					.setInteger("activeYES", 1);
			contactDetails = hqlQuery.list();
			
			if(contactDetails.size()!=0)
			{
				for(int i=0; i<contactDetails.size(); i++)
				{
					String data = new String();
					
					data = " " + contactDetails.get(i).getId()+','+contactDetails.get(i).getContactPersonName()+','+contactDetails.get(i).getContactPersonNumber()+','+contactDetails.get(i).getAppUserYN()+','+contactDetails.get(i).getCreatedDateTime()+','+contactDetails.get(i).getModifiedDateTime();
					friendsList.add(data);					
				}
			}
			else
			{
				System.out.println("*****************No Data Found*********" );
			}			
			
		}
		catch(HibernateException he){
			he.printStackTrace();
			
		}finally{
			HibernateUtils.closeConnection(session);
		}
		
		return friendsList;		
	}
}
