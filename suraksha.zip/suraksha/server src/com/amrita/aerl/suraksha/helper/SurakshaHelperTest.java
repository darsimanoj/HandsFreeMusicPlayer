package com.amrita.aerl.suraksha.helper;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.Ignore;
import org.junit.Test;

import com.amrita.aerl.suraksha.dao.BuddyDAO;
import com.amrita.aerl.suraksha.dao.UserProfileDAO;


public class SurakshaHelperTest {
	
	@Test
	public void testfp() throws Exception
	{
		String fingerprint="{\"7e:46:85:c0:7b:97\":-65,\"8c:be:be:3b:52:b3\":-40,\"88:79:7e:3f:d1:94\":-31}";
		String r="Ap1";
		String mac="Ap1:ed:12:13";
		double x=-33.98922348022461;
		double y=151.0124053955078;
		/*String s[] = {"sample=1=2","sample=1=2","sample=1=2"};*/
		
		System.out.println("***************** About to create a sample point *********");
		//SurakshaHelper.Fingerprint_offline(fingerprint,x,y);
	   String result2 = SurakshaHelper.Fingerprint_on(fingerprint);
		//String result1 = SurakshaHelper.accesspoint_add(r,mac,x,y);
		System.out.println("sample created: "+result2);
	}
	
	@Ignore
	public void testregisterUser() throws Exception
	{
		String usrNum = "8008238173";
		
		System.out.println("*****************About to create a new User *********");
		String result = SurakshaHelper.registerUser(usrNum);
		System.out.println("user created: "+result);
	}
	
	@Ignore
	public void testgetLatestNotifications() throws Exception
	{
		String usrNum = "8893721751";
		
		System.out.println("*****************About to get latest Location and media Notifications *********");
	 	ArrayList result = SurakshaHelper.getLatestNotifications(usrNum);
	}
	
	@Ignore
	public void testgetNotificationViewedStatus() throws Exception
	{
		String usrNum="9633639343";
		int notificationId=31;
		ArrayList result=SurakshaHelper.getNotificationViewedStatus(usrNum, notificationId);
		System.out.println("*****************About to get Notification viewed status : " + result);
	}
	
	@Ignore
	public void testDeleteBuddy() throws Exception
	{
		String usrNum = "8896523478";
		String buddyNum = "9493500251";
		
		System.out.println("*****************About to delete user *********");
	 	String result = SurakshaHelper.deleteBuddy(usrNum,buddyNum);
		System.out.println("*****************Deleted user:*********\n"+result);
	}

	/**
	 * Test get institute admin users.
	 *
	 * @throws Exception
	 */
	@Ignore
	public void testFetchProfileDetails() throws Exception{
		String usrNum = "61";

		System.out.println("*****************Getting Profile Data *********");
		List profile = SurakshaHelper.fetchProfileDetails(usrNum);
		System.out.println("*****************Got Profile Data *********\n"+profile);
	  }

	/**
	 * Test get institute admin users.
	 *
	 * @throws Exception
	 */
	// @Ignore
	@Ignore
	public void testUserProfileEdit() throws Exception{
		String usrNum = "8008238173";
		String firstName = "manoj";
		String lastName = "R";
		String gender = "M";
		String dob = "1990-01-01";
		String emailId = "aerl@aerl.in";
		String address = "AERL";
		String city = "Kollam";
		String state = "Kerala";
		String country = "India";
		String occupation = "Soft. Engg.";
		String officeAddress = "AERL";
		String officeNum = "04762804434";
		SurakshaHelper.userProfileEdit(usrNum,firstName,lastName,gender,dob,emailId,address,city,state,country,occupation,officeAddress,officeNum);
	}
	
	/**
	 * Test get friends list
	 *
	 * @throws Exception
	 */
	@Ignore
	public void testgetFriendsList() throws Exception{
		String usrNum = "8008238173";

		System.out.println("*****************Getting friends list *********");
		ArrayList friendsList = BuddyDAO.getFriendsList(usrNum);
		System.out.println("*****************Got Friends list *********\n"+friendsList);
	  }
	
	
	/**
	 * Test add buddy list
	 *
	 * @throws Exception
	 */
	@Ignore
	public void testaddingBuddy() throws Exception{
		String usrNum ="04762804431";
		String buddyName="Sneha";
		String buddyNum ="9876543210";
		SurakshaHelper.addingBuddy(usrNum, buddyName, buddyNum);
		System.out.println("*****************Buddy list added succesfully********");
	}
	
	@Ignore
	public void testaddingloc() throws Exception{
		String usrNum ="8328588854";
		String loc="hello";
		float lat=(float) 23.50;
		float longi=(float) 23.50;
		SurakshaHelper.addlocation(usrNum,loc,lat,longi );
		System.out.println("*****************loc added succesfully********");
	}
	
	/*@Ignore
	public void testlat() throws Exception{
		String usrNum ="8328588854";
		float lat=(float) 23.50;
		SurakshaHelper.addlatitude(usrNum,lat);
		System.out.println("*****************latitude added succesfully********");
	}
	
	@Ignore
	public void testlong() throws Exception{
		String usrNum ="8328588854";
		float longi=(float) 23.50;
		SurakshaHelper.addlongitude(usrNum,longi);
		System.out.println("*****************latitude added succesfully********");
	}*/
	
	@Ignore
	public void friends_num() throws Exception{
		String usrNum ="8328588854";
		//ArrayList friendsList=SurakshaHelper.fetchFriends_num(usrNum);
		
		//System.out.println("*****************got friends loc succesfully********"+friendsList);
		
        //ArrayList friendsLoc=SurakshaHelper.fetchFriends_loc(friendsList);
		
		//System.out.println("*****************got friends loc succesfully********"+friendsLoc);
		
		ArrayList friendsLoc=SurakshaHelper.fetchFriends_time(usrNum);
		
		System.out.println("*****************got friends loc succesfully********"+friendsLoc);
	}
	
	/**
	 * Test add event location
	 *
	 * @throws Exception
	 */
	@Ignore
	public void testaddingEventLocation() throws Exception{
		String usrNum ="04762804431";
		String usrLocation ="Kollam";
		String usrAddress ="AERL";
		SurakshaHelper.addingEventLocation(usrNum,usrLocation,usrAddress);
		System.out.println("*****************Added event location *********");
	}
	
	/**
	 * Test add media
	 *
	 * @throws Exception
	 */
	@Ignore
	public void testaddingMedia() throws Exception{
		String usrNum ="9633639343";
		int notificationId=24;
		String notificationType="Image";
		String fileName ="sample";
		String filePath ="sdcard/camera/gallery";
		String fileType=".jpg";
		SurakshaHelper.addingMedia(usrNum,notificationId,notificationType, fileName, filePath, fileType);
		System.out.println("*****************Added media file *********");
	}
	
	/**
	 * Test get notification
	 *
	 * @throws Exception
	 */
	@Ignore
	public void testcheckNotification() throws Exception{
		String usrNum ="04762804431";
		SurakshaHelper.checkNotification(usrNum);
		System.out.println("*****************Added notification details *********");
	}

}


