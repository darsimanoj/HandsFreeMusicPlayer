package com.amrita.aerl.suraksha.helper;

import java.util.ArrayList;
import java.util.List;
import java.util.Arrays;
import java.lang.Math;





import org.json.JSONException;
import org.json.JSONObject;

import com.amrita.aerl.suraksha.dao.AccesspointDAO;
import com.amrita.aerl.suraksha.dao.BuddyDAO;
import com.amrita.aerl.suraksha.dao.AppRegistrationDAO;
import com.amrita.aerl.suraksha.dao.SamplepointDAO;
import com.amrita.aerl.suraksha.dao.GCMserverDAO;
import com.amrita.aerl.suraksha.dao.MediaFileDAO;
import com.amrita.aerl.suraksha.dao.NotificationDAO;
import com.amrita.aerl.suraksha.dao.NotificationRecipientsDAO;
import com.amrita.aerl.suraksha.dao.UserProfileDAO;
import com.amrita.aerl.suraksha.entities.Samplepoint;
import com.amrita.aerl.suraksha.entities.Accesspoint;
import com.amrita.aerl.suraksha.utils.HibernateUtils;


public class SurakshaHelper
{
  public static String registerUser(String usrNumber)
  {
    String result = AppRegistrationDAO.appRegistration(usrNumber);
    System.out.println("*****************Registration is done*********");
    return result;
  }
    
  public static String addingBuddy(String usrNum,String buddyName,String buddyNum)
  {
    String result = BuddyDAO.addingBuddy(usrNum,buddyName,buddyNum);
    System.out.println("*****************Contact added *********");
    return result;
  }
  
  public static String deleteBuddy(String usrNum,String buddyNum)
  {
    String result = BuddyDAO.deleteBuddy(usrNum,buddyNum);
    return result;
  }
  
  public static int addingEventLocation(String usrNum, String usrLocation,String usrAdress)
  {
    int result = NotificationDAO.addingEventLoc(usrNum,usrLocation,usrAdress);
    System.out.println("*****************Location added *********");
    return result;
  }  
  
  public static String addingMedia(String usrNum,int notificationId,String notificationType, String fileName,String filePath, String fileType)
  {
    String result = MediaFileDAO.addingMediaFile(usrNum,notificationId,notificationType,fileName,filePath,fileType);
    System.out.println("*****************Media added *********");
    return result;
  }  
  
  public static String checkNotification(String usrNum)
  {
    String result = NotificationRecipientsDAO.checkNotification(usrNum);
    System.out.println("*****************checking the NOtification *********");
    return result;
  }
  
  public static ArrayList getLatestNotifications(String usrNum)
  {
	
	ArrayList result = NotificationRecipientsDAO.getLatestNotifications(usrNum);
    System.out.println("***********Get Latest Location Notifications for User:"+usrNum+"\n result:"+result+" *********");
    return result;
  }
  
  public static ArrayList getNotificationViewedStatus(String usrNum, int notificationID)
  {
	  ArrayList result=NotificationRecipientsDAO.getNotificationViewedStatus(usrNum, notificationID);
	  return result;
  }
  
  public static String addRegId(String usrNum, String regId)
  {
	  System.out.println("*****************Reg Id adding *********");
	  String result = GCMserverDAO.addingRegId(usrNum, regId);
	  return result;
  }
  
  public static String addlocation(String usrNum, String loc, float lat, float longi)
  {
	  System.out.println("*****************loc adding *********");
	  String result = UserProfileDAO.addinglocation(usrNum, loc);
	  result = UserProfileDAO.addinglatitude(usrNum, lat);
	   result = UserProfileDAO.addinglongitude(usrNum, longi);
	  return result;
  }
  
 /* public static String addlatitude(String usrNum, float lat)
  {
	  System.out.println("*****************latitude adding *********");
	  String result = UserProfileDAO.addinglatitude(usrNum, lat);
	  return result;
  }
  
  public static String addlongitude(String usrNum, float longi)
  {
	  System.out.println("*****************longitude adding *********");
	  String result = UserProfileDAO.addinglongitude(usrNum, longi);
	  return result;
  }
*/  
  public static ArrayList<String> fetchRegIds(int usrid)
  {
	  System.out.println("*****************Reg Id fetching *********");
	  ArrayList<String> result = GCMserverDAO.getUsrRegId(usrid);
	  return result;
  }
  
  public static void userProfileEdit(String usrNum,String firstName,String lastName,String gender,String dob,String emailId,String address,String city,String state,String country,String occupation,String officeAddress,String officeNum) throws Exception
  {
	  if(firstName != null &&  firstName != "" && lastName != null && lastName != ""){
		  System.out.println("***********Adding Details to UserProfile*********");
		  UserProfileDAO.userProfileEdit(usrNum,firstName,lastName,gender,dob,emailId,address,city,state,country,occupation,officeAddress,officeNum);
	  }
	  else
	  { 
		  System.out.println("***********first name or last name  is null*********");
		  throw new Exception("first name or last name is null");
	  }
  } 
  
  public static ArrayList notifyDeatils(String usrNum)
  {
	  System.out.println("*****************Fetching Notifications *********");
	  ArrayList result = NotificationRecipientsDAO.fetchNotifyDetails(usrNum);
	  return result;
  }
  
  public static List fetchProfileDetails(String usrNum)
  {
	  System.out.println("*****************fetching Profile Data *********");
	  List result = UserProfileDAO.fetchProfileDetails(usrNum);
	  return result;
  }
  
  public static ArrayList fetchFriendsList(String usrNum)
  {
	  System.out.println("*****************Fetching friends list *********");
	  ArrayList result = BuddyDAO.getFriendsList(usrNum);
	  return result;
  }
  

  public static ArrayList   fetchFriends_num(String usrNum)
  {	  		ArrayList<String> friendsLoc = new ArrayList<String>();
	  System.out.println("*****************Fetching friends list *********");
	  ArrayList<String> result = BuddyDAO.getFriendsList(usrNum);
	  int i=0;
	  if(result.size()!=0)
		{
		  	for(i=0;i<result.size();i++){
		  		String data = new String();
		  		String[] bits = result.get(i).split(",");
		  		data = bits[2];
		  		
		  		if(bits[3].equals("Y")){
				friendsLoc.add(data);	
		  		}
		  
		  		}
		}
	  else
		{
			System.out.println("*****************No Data Found*********" );
		}
	  
	  
	  return friendsLoc;
  }
  
  public static ArrayList   fetchFriends_name(String usrNum)
  {	  		ArrayList<String> friendsLoc = new ArrayList<String>();
	  System.out.println("*****************Fetching friends list *********");
	  ArrayList<String> result = BuddyDAO.getFriendsList(usrNum);
	  int i=0;
	  if(result.size()!=0)
		{
		  	for(i=0;i<result.size();i++){
		  		String data = new String();
		  		String[] bits = result.get(i).split(",");
		  		data = bits[1];
		  		
		  		if(bits[3].equals("Y")){
				friendsLoc.add(data);	
		  		}
		  
		  		}
		}
	  else
		{
			System.out.println("*****************No Data Found*********" );
		}
	  
	  
	  return friendsLoc;
  }
  
  public static ArrayList   fetchFriends_time(String usrNum)
  {	  		ArrayList<String> friendsLoc = new ArrayList<String>();
	  System.out.println("*****************Fetching friends list *********");
	  ArrayList<String> result = BuddyDAO.getFriendsList(usrNum);
	  int i=0;
	  if(result.size()!=0)
		{
		  	for(i=0;i<result.size();i++){
		  		String data = new String();
		  		String[] bits = result.get(i).split(",");
		  		data = bits[5];
		  		
		  		if(bits[3].equals("Y")){
				friendsLoc.add(data);	
		  		}
		  
		  		}
		}
	  else
		{
			System.out.println("*****************No Data Found*********" );
		}
	  
	  
	  return friendsLoc;
  }
  
  public static ArrayList fetchFriends_loc(ArrayList<String> f_num)
  {	  		
	  System.out.println("*****************Fetching friends loc *********");
	  ArrayList<String> fLoc = new ArrayList<String>();
	  int i=0;
	  if(f_num.size()!=0)
		{
		  	for(i=0;i<f_num.size();i++){
		  		
		  		String data=new String();;
		  		data=UserProfileDAO.getting_loc(f_num.get(i));
		  		fLoc.add(data);
		  		
		  
		  		}
		}
	  else
		{
			System.out.println("*****************No Data Found*********" );
		}
	  
	  
	  return fLoc;
  }
  
  public static ArrayList Friends_loc(String usrNum)
  {	  		
	  System.out.println("*****************Fetching friends loc *********");
	 
	  ArrayList friendsList=SurakshaHelper.fetchFriends_num(usrNum);
	  ArrayList fLoc=SurakshaHelper.fetchFriends_loc(friendsList);
	  return fLoc;
  }
  public static String Fingerprint_offline(String s,double x,double y)
  {	  		
	  System.out.println("***************** Storing sample point *********");
	 
	 String result = SamplepointDAO.SamplepointAdd(s, x, y);
	 
	  return result;
  }
  public static String Fingerprint_off(String[] s){
	  
	 for(int i=0;i<s.length;i++){
		 String[] bits = (s[i]).split("=");
         double lastOne =Double.parseDouble(bits[bits.length-1]) ;
         double mid = Double.parseDouble(bits[bits.length-2]);
         String fOne = bits[bits.length-3];
         //System.out.print(fOne+mid+lastOne);
	 Fingerprint_offline(fOne,mid,lastOne);
	 }
	  
	  return null;
  } 
  public static String Fingerprint_on(String s) 
  {	  		
	  System.out.println("***************** Estimating *********");
	  
	  String result = SamplepointDAO.Fingerprint_on_K4(s);
	  //String result = SamplepointDAO.Fingerprint_online(s);
		 
	  return result;
	
	  
  }
  
  public static String accesspoint_add(String s,String t,double x,double y)
  {	  		
	  System.out.println("***************** Storing sample point *********");
	 
	 String result = AccesspointDAO.AccesspointAdd(s, t, x, y);
	 
	  return result;
	 
  }
  
}