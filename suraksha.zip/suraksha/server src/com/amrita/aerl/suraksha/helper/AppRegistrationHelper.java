package com.amrita.aerl.suraksha.helper;

import com.amrita.aerl.suraksha.dao.AppRegistrationDAO;
import com.amrita.aerl.suraksha.utils.ServerException;

public class AppRegistrationHelper 
{
	
//	 public String testFn()
//	  {
//	    String result = AppRegistrationDAO.testFN();
//	    System.out.println("*****************TesT fn in helper is invoked*********");
//	    return result;
//	  }
	
	
//	public String appRegistration()
//	{
//		 String usrPhoneNumber = "123456789";
//		 String usrName = "vinoth";
//		 String result = AppRegistrationDAO.appRegistration(usrName,usrPhoneNumber);		
//		 return result;
//		
//	}
	
	
//	  public static String appRegistration()
//			    throws ServerException
//			  {
//			    
//			    String responseMessage = null;
//			    String usrPhoneNumber = "123456789";
//			    String usrName = "vinothy";
//			    responseMessage = AppRegistrationDAO.appRegistration(usrName,usrPhoneNumber);				    
//			    System.out.println(responseMessage);
//			    return responseMessage;
//			  }
//	
	
	
	

}
