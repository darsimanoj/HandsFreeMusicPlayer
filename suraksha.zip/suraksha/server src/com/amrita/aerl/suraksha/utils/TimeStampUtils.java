package com.amrita.aerl.suraksha.utils;

import java.sql.Timestamp;
import java.util.GregorianCalendar;

public class TimeStampUtils
{
  public static Timestamp getCurrentTimestamp()
  {
    return new Timestamp(System.currentTimeMillis());
  }
  
  public static Timestamp getCurrentTimestamp(long offset)
  {
    return new Timestamp(System.currentTimeMillis() + offset);
  }
  
  public static java.sql.Date getCurrentDate()
  {
    return new java.sql.Date(System.currentTimeMillis());
  }
  
  public static java.util.Date removeTime(java.util.Date dateTime)
  {
    return removeTimeCalendar(dateTime).getTime();
  }
  
  public static GregorianCalendar removeTimeCalendar(java.util.Date dateTime)
  {
    GregorianCalendar gc = new GregorianCalendar();
    gc.setTime(dateTime);
    gc.set(12, 0);
    gc.set(11, 0);
    gc.set(13, 0);
    gc.set(14, 0);
    return gc;
  }
  
  public static java.util.Date removeDateAndMillis(java.util.Date dateTime)
  {
    GregorianCalendar gc = new GregorianCalendar();
    gc.setTime(dateTime);
    
    gc.set(5, 0);
    gc.set(1, 0);
    gc.set(2, 0);
    gc.set(14, 0);
    return gc.getTime();
  }
  
  public static java.util.Date addTimeToDate(java.util.Date date, java.util.Date time, int adjustedMinutes)
  {
    GregorianCalendar gcDate = new GregorianCalendar();
    gcDate.setTime(date);
    
    GregorianCalendar gcTime = new GregorianCalendar();
    gcTime.setTime(time);
    
    gcDate.set(12, gcTime.get(12));
    gcDate.set(11, gcTime.get(11));
    gcDate.set(13, gcTime.get(13));
    
    gcDate.add(12, adjustedMinutes);
    
    return gcDate.getTime();
  }
  
  public static java.util.Date strToDate(String strDate, String delimiter, int dateIndex, int monthIndex, int yearIndex)
  {
    GregorianCalendar gcDate = new GregorianCalendar();
    String[] splittedDate = strDate.split(delimiter);
    gcDate.set(5, Integer.parseInt(splittedDate[dateIndex]));
    
    gcDate.set(2, Integer.parseInt(splittedDate[monthIndex]) - 1);
    gcDate.set(1, Integer.parseInt(splittedDate[yearIndex]));
    return gcDate.getTime();
  }
}
