package com.amrita.aerl.suraksha.utils;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.dialect.function.StandardSQLFunction;

public class HibernateUtils {
	
	private static SessionFactory sf = null;
	static 
	{
		try 
		{
			Configuration conf = new Configuration().configure();
			conf.addSqlFunction("group_concat", new StandardSQLFunction("group_concat"));
			conf.setProperty("batch-size", "50");			
			sf = conf.buildSessionFactory();				
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		
		
		
	}

	public static Session getHibernateConnection() {
		Session con = null;
		try {
			con = sf.openSession();
		} catch (Exception se) {
			se.printStackTrace();
		}
		return con;
	}

	public static void closeConnection(Session con) {
		try {
			if (con != null) {
				con.close();
			}
		} catch (Exception ignore) {
		}
	}

}
