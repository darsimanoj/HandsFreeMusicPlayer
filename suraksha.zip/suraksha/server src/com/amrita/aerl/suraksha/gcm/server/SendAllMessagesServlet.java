package com.amrita.aerl.suraksha.gcm.server;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import java.util.logging.Logger;

import com.amrita.aerl.suraksha.dao.GCMserverDAO;
import com.amrita.aerl.suraksha.helper.SurakshaHelper;
import com.google.android.gcm.server.Message;
import com.google.android.gcm.server.MulticastResult;
import com.google.android.gcm.server.Result;
import com.google.android.gcm.server.Sender;

public class SendAllMessagesServlet {
	  private static final int MULTICAST_SIZE = 1000;
	  private static final Executor threadPool = Executors.newFixedThreadPool(5);
	  public static Sender sender ;
	  protected final Logger logger = Logger.getLogger(getClass().getName());

    public static void main(final int receiver) throws Exception {
    	
        // configure the SSLContext with a TrustManager
        /*SSLContext ctx = SSLContext.getInstance("TLS");
        ctx.init(new KeyManager[0], new TrustManager[] {
        		new DefaultTrustManager()}, new SecureRandom());
        SSLContext.setDefault(ctx);

        URL url = new URL("https://mms.nw.ru");
        HttpsURLConnection conn = (HttpsURLConnection) url.openConnection();
        conn.setHostnameVerifier(new HostnameVerifier() {
            @Override
            public boolean verify(String arg0, SSLSession arg1) {
                return true;
            }
        });
        
       /System.out.println(conn.getResponseCode());
        conn.disconnect();*/
        
        new Thread(){

            public void run(){
    
                try {
                    //Please add here your project API key: "Key for browser apps (with referers)".
                    //If you added "API key Key for server apps (with IP locking)" or "Key for Android apps (with certificates)" here
                    //then you may get error responses.
                    sender = new  Sender("AIzaSyBsRC3TRwvYlDctlJeUQUMYx-ZPFYswQsQ");
                	//sender = new  Sender("AIzaSyDg3gZhnWPdwMegrejMvQ2OdRwOQ2B1wD4");
                               
                    List<String> devices = SurakshaHelper.fetchRegIds(receiver);
                    String status;
                    if (devices.isEmpty()) {
                      status = "Message ignored as there is no device registered!";
                    } else {
                      // NOTE: check below is for demonstration purposes; a real application
                      // could always send a multicast, even for just one recipient
                      if (devices.size() == 1) {
                        // send a single message using plain post
                        String registrationId = devices.get(0);
                        Message message = new Message.Builder().build();
                        Result result = sender.send(message, registrationId, 5);
                        status = "Sent message to one device: " + result;
                      } else {
                        // send a multicast message using JSON
                        // must split in chunks of 1000 devices (GCM limit)
                        int total = devices.size();
                        List<String> partialDevices = new ArrayList<String>(total);
                        int counter = 0;
                        int tasks = 0;
                        for (String device : devices) {
                          counter++;
                          partialDevices.add(device);
                          int partialSize = partialDevices.size();
                          if (partialSize == MULTICAST_SIZE || counter == total) {
                            asyncSend(partialDevices);
                            partialDevices.clear();
                            tasks++;
                          }
                        }
                        status = "Asynchronously sending " + tasks + " multicast messages to " +
                            total + " devices";
                      }
                    }
                    
                    
                    
                    /*// use this to send message with payload data
                    Message message = new Message.Builder()
                    .collapseKey("message")
                    .timeToLive(3)
                    .delayWhileIdle(true)
                    .addData("message", "Welcome to Push Notifications") //you can get this message on client side app
                    .build(); 
 
                    //Use this code to send notification message to a single device
                    Result result = sender.send(message,
                            "APA91bH0FRLxxsEFp0cnjrQjla48TKHkhVW78uKvLGYFmE7q181AzHWH66qI9zwqj8RJmfTxgJVQYAhQF1pbfeRx53fwH4OrczfvVgJDcra-QkQ1X-qybYQXqBhFUsGbub9QUP9vvrUS",
                            1);
                    System.out.println("Message Result: "+result.toString()); //Print message result on console
                    */
                    
                    /*//Use this code to send notification message to multiple devices
                    ArrayList<String> devicesList = new ArrayList<String>();
                    //add your devices RegisterationID, one for each device               
                    devicesList.add("APA91bEbKqwTbvvRuc24vAYljcrhslOw-jXBqozgH8C2OB3H8R7U00NbIf1xp151ptweX9VkZXyHMik022cNrEETm7eM0Z2JnFksWEw1niJ2sQfU3BjQGiGMq8KsaQ7E0jpz8YKJNbzkTYotLfmertE3K7RsJ1_hAA");   
                    devicesList.add("APA91bEVcqKmPnESzgnGpEstHHymcpOwv52THv6u6u2Rl-PaMI4mU3Wkb9bZtuHp4NLs4snBl7aXXVkNn-IPEInGO2jEBnBI_oKEdrEoTo9BpY0i6a0QHeq8LDZd_XRzGRSv_R0rjzzZ1b6jXY60QqAI4P3PL79hMg");   

                    //Use this code for multicast messages   
                    MulticastResult multicastResult = sender.send(message, devicesList, 0);
                    System.out.println("Message Result: "+multicastResult.toString());//Print multicast message result on console
*/
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }.start();   
        
    }
    
    private static void asyncSend(List<String> partialDevices) {
        // make a copy
        final List<String> devices = new ArrayList<String>(partialDevices);
        threadPool.execute(new Runnable() {

          public void run() {
            Message message = new Message.Builder().build();
            MulticastResult multicastResult;
            try {
              multicastResult = sender.send(message, devices, 5);
            } catch (IOException e) {
              /*logger.log(Level.SEVERE, "Error posting messages", e);*/
              return;
            }
            List<Result> results = multicastResult.getResults();
            // analyze the results
            for (int i = 0; i < devices.size(); i++) {
              String regId = devices.get(i);
              Result result = results.get(i);
              String messageId = result.getMessageId();
              if (messageId != null) {
                /*logger.fine("Succesfully sent message to device: " + regId +
                    "; messageId = " + messageId);*/
                String canonicalRegId = result.getCanonicalRegistrationId();
                if (canonicalRegId != null) {
                  // same device has more than on registration id: update it
                  /*logger.info("canonicalRegId " + canonicalRegId);*/
                  Datastore.updateRegistration(regId, canonicalRegId);
                }
              } else {
                String error = result.getErrorCodeName();
                
                /*if (error.equals(Constants.ERROR_NOT_REGISTERED)) {
                  // application has been removed from device - unregister it
                  logger.info("Unregistered device: " + regId);
                  Datastore.unregister(regId);
                } else {
                  logger.severe("Error sending message to " + regId + ": " + error);
                }*/
                
              }
            }
          }});
      }

   /* private static class DefaultTrustManager implements X509TrustManager {

        @Override
        public void checkClientTrusted(X509Certificate[] arg0, String arg1) throws CertificateException {}

        @Override
        public void checkServerTrusted(X509Certificate[] arg0, String arg1) throws CertificateException {}

        @Override
        public X509Certificate[] getAcceptedIssuers() {
            return null;
        }
    }*/
}