package com.amrita.aerl.suraksha.gcm.server;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.amrita.aerl.suraksha.helper.SurakshaHelper;

/**
 * Servlet that registers a device, whose registration id is identified by
 * {@link #PARAMETER_REG_ID}.
 *
 * <p>
 * The client app should call this servlet everytime it receives a
 * {@code com.google.android.c2dm.intent.REGISTRATION C2DM} intent without an
 * error or {@code unregistered} extra.
 */
@SuppressWarnings("serial")
public class RegisterServlet extends BaseServlet {

  private static final String PARAMETER_REG_ID = "regId";
  private static final String PARAMETER_USR_NUM = "usrNum";

  @Override
  protected void doPost(HttpServletRequest req, HttpServletResponse resp)
      throws ServletException {
    String regId = getParameter(req, PARAMETER_REG_ID);
    String usrNum = getParameter(req, PARAMETER_USR_NUM);
    //String usrNum = "1234567890";
    String result = SurakshaHelper.addRegId(usrNum,regId);    
    //Datastore.register(regId);    
    if(result == "Added")
    {
    	setSuccess(resp);
    }
    else {
    	System.out.println("*****************GCM not added*********");
	}
    
  }

}
