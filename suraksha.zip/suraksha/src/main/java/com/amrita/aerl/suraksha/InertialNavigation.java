package com.amrita.aerl.suraksha;

import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.hardware.TriggerEvent;
import android.hardware.TriggerEventListener;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;


public class InertialNavigation extends Fragment implements SensorEventListener {
    private static final String TAG = "InertialNavigation";
    private SensorManager sensorManager;
    private Sensor sensor,sensor2;
    int mSteps=0;
    TextView tv;


    public InertialNavigation() {
        // Required empty public constructor
    }


    public static InertialNavigation newInstance(String param1, String param2) {
        InertialNavigation fragment = new InertialNavigation();
        Bundle args = new Bundle();

        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_inertial_navigation, container, false);
        sensorManager = (SensorManager) getActivity().getSystemService(Context.SENSOR_SERVICE);

        sensor = sensorManager.getDefaultSensor(Sensor.TYPE_STEP_COUNTER);
        //sensor2 = sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR);
        sensorManager.registerListener(InertialNavigation.this,sensor,SensorManager.SENSOR_DELAY_NORMAL,1000);
        tv = (TextView) v.findViewById(R.id.l);
       /* PackageManager pm = getActivity().getPackageManager();
        if(pm.hasSystemFeature("android.hardware.sensor.stepdetector")){
            Toast.makeText(getActivity(), "hello bro", Toast.LENGTH_SHORT).show();
        }*/


        return v;
    }


    @Override
    public void onSensorChanged(SensorEvent sensorEvent) {
        tv.setText(" Z "+sensorEvent.values[0]);
       /* if (sensorEvent.sensor.getType() == Sensor.TYPE_STEP_DETECTOR) {
            // A step detector event is received for each step.
            // This means we need to count steps ourselves

            mSteps += sensorEvent.values.length;
            tv.setText(mSteps);
        }*/
            //Log.d(TAG,"X: "+sensorEvent.values[0]+" Y: "+sensorEvent.values[1]+" Z "+sensorEvent.values[2]);


    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {

    }
}
