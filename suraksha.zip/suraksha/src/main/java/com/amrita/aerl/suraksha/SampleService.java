package com.amrita.aerl.suraksha;

import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.IBinder;
import android.util.Log;

/**
 * Created by gnaveen on 4/8/2016.
 */

public class SampleService extends Service {

    BroadcastReceiver mReceiver;
    @Override
    public int onStartCommand(Intent intent, int flags, int startId)
    {
        Log.e("StartServiceAtBoot", "StartAtBootService -- onStartCommand()");
        // We want this service to continue running until it is explicitly
        // stopped, so return sticky.
        return START_STICKY;
    }

    @Override
    public void onStart(Intent intent, int startId) {
        boolean screenOn = intent.getBooleanExtra("screen_state", false);
        if (!screenOn) {
           // Toast.makeText(SampleService.this, "On", Toast.LENGTH_SHORT).show();
            Log.e("screen_state", "on");
        } else {
            //Toast.makeText(SampleService.this, "Off", Toast.LENGTH_SHORT).show();
             Log.e("screen_state", "off");
        }
    }

    public void onCreate()
    {
        IntentFilter filter = new IntentFilter(Intent.ACTION_SCREEN_ON);
        filter.addAction(Intent.ACTION_SCREEN_OFF);
         mReceiver = new ScreenReceiver();
        registerReceiver(mReceiver, filter);

    }

    @Override
    public IBinder onBind(Intent intent) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public void onDestroy() {

        super.onDestroy();
        unregisterReceiver(mReceiver);
        // startService(new Intent(this, SampleService.class));

    }
}
