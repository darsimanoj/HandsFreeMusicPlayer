package com.amrita.aerl.suraksha;

import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.CameraUpdateFactory;

import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

import java.util.ArrayList;
import java.util.List;

import common.Constants;
import common.amfFunctions;
import flex.messaging.io.amf.client.AMFConnection;
import flex.messaging.io.amf.client.exceptions.ClientStatusException;
import flex.messaging.io.amf.client.exceptions.ServerStatusException;

/**
 * Created by Manoj on 12/12/2018.
 */

public class Map_Friends extends Fragment implements OnMapReadyCallback,GoogleMap.OnMarkerClickListener {
    GoogleMap gMap;
    MapView m;
    DBHelper mydb;
    amfFunctions amf;
    LatLng latlng = new LatLng(23.63936, 68.14712);
    Object responseResult;
    Object responseResult2;
    Object responseResult3;

    AMFConnection amfConnection;
    ArrayList o,k,n;
    Constants constants;
    String result = null;
    public  Map_Friends() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(final LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.activity_mapfriends, container, false);

        SupportMapFragment mapFragment = (SupportMapFragment) getChildFragmentManager().findFragmentById(R.id.map1);

        mapFragment.getMapAsync(this);
  return v;
    }

   @Override
    public void onMapReady(GoogleMap map) {
        // DO WHATEVER YOU WANT WITH GOOGLEMAP
        map.setMapType(GoogleMap.MAP_TYPE_HYBRID);
        //map.setMyLocationEnabled(true);
        //map.setTrafficEnabled(true);
        //map.setIndoorEnabled(true);
       // map.setBuildingsEnabled(true);
        //map.getUiSettings().setZoomControlsEnabled(true);
        gMap=map;
       try {
           mydb = new DBHelper(getActivity());
           final List<Database_Contact> list = mydb.get_user_phone_number();
           new Map_Friends.FetchingLocationDetails().execute("Maps", list.get(0).get_owner_phone_number());
       }
       catch (Exception e)
       {


       }
       map.setOnMarkerClickListener(this);

    }
    @Override
    public void onStop() {
        super.onStop();
    }

    @Override
    public void onPause() {
        super.onPause();
        m.onPause();
    }

    @Override
    public boolean onMarkerClick(Marker marker) {
       if(marker.isInfoWindowShown()) {
           Uri gmmIntentUri = Uri.parse("google.navigation:q=" + marker.getPosition().latitude + "," + marker.getPosition().longitude);
           Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
           mapIntent.setPackage("com.google.android.apps.maps");
           startActivity(mapIntent);
       }
       else{
           marker.showInfoWindow();
       }
        return false;
    }

    class FetchingLocationDetails extends AsyncTask<String, String,String> {
        @Override
        protected String doInBackground(String... arg0){
            amfConnection = new AMFConnection();
            try {
                amfConnection.connect(constants.server);
            } catch (ClientStatusException cse) {
                result = "No connection";
                Log.d("ClientStatusException", cse.toString());
            }
            switch (arg0[0]) {
                case "Maps":
                    try {
                        responseResult = amfConnection.call(constants.FUNCTION_CALL_floc, arg0[1]);
                        responseResult2=amfConnection.call(constants.FUNCTION_CALL_fnum,arg0[1]);
                        responseResult3=amfConnection.call(constants.FUNCTION_CALL_ftime,arg0[1]);

                     //   String[] bits = (arg0[2]).split(":");
                     //   String lastOne = bits[bits.length-1];
                         o= (ArrayList) responseResult;
                        k=(ArrayList) responseResult2;
                        n= (ArrayList) responseResult3;
                        Log.e("Result of map details ", responseResult.toString());
                    } catch (ClientStatusException cse) {
                        result = "No connection";
                        Log.d("ClientStatusException", cse.toString());
                    } catch (ServerStatusException sse) {
                        result = "Server Down";
                        Log.d("ServerStatus:", sse.toString());
                    }
                    break;
                default: Log.d("Case Failure"," Returned from Switch default");
                    break;
            }
            amfConnection.close();
            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
           //
            LatLngBounds.Builder builder = new LatLngBounds.Builder();
            int i=0;
            for(i=0;i<o.size();i++){
                String[] bits;

                if(o.get(i).equals("0.0:0.0")) {

                }
                else{

                    bits = ((String) o.get(i)).split(":");
                    String lastOne = bits[bits.length - 1];
                    double latitude = Double.parseDouble(bits[0]);
                    double longitude = Double.parseDouble(lastOne);
                    latlng = new LatLng(latitude, longitude);


                        builder.include(latlng);


                   Marker l= gMap.addMarker(new MarkerOptions().position(latlng).title((String) k.get(i)+(String) n.get(i) ).snippet("click direction btn to reach him"));
                   //l.showInfoWindow();
                }
            }
            LatLngBounds bounds = builder.build();
            int padding = 0; // offset from edges of the map in pixels
            CameraUpdate cu = CameraUpdateFactory.newLatLngBounds(bounds, padding);
            gMap.moveCamera(cu);
            gMap.animateCamera(cu);
          //  CameraPosition cPos = new CameraPosition.Builder().target(latlng).zoom(12).build();
          // gMap.animateCamera(CameraUpdateFactory.newCameraPosition(cPos));
        }
    }


}