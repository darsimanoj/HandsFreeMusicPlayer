package com.amrita.aerl.suraksha.Notification_Details;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.ThumbnailUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.TextView;

import com.amrita.aerl.suraksha.Database_Contact;
import com.amrita.aerl.suraksha.R;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by rvinoth on 5/24/2015.
 */
public class CustomDeliveredListAdapter extends ArrayAdapter<Database_Contact> implements Filterable {

    private List<String> allDataListName;
    private List<String> allDataListDate;
    private List<String> allDataListTime;
    private Activity context;
    private LayoutInflater inflater;
    public CustomDeliveredListAdapter(Activity context, List<String> deliveredName,List<String> deliveredDate,List<String> deliveredTime) {
        super(context, R.layout.activity_deliveredlist);
        this.context = context;
        this.allDataListName = new ArrayList<String>();
        allDataListName.addAll(deliveredName);
        this.allDataListDate = new ArrayList<String>();
        allDataListDate.addAll(deliveredDate);
        this.allDataListTime= new ArrayList<String>();
        allDataListTime.addAll(deliveredTime);
        inflater = context.getLayoutInflater();
    }
    static class ViewHolder {
        protected TextView txtSenderName;
        protected TextView txtDate;
        protected TextView txtTime;
    }

    @Override
    public int getCount() {
        return allDataListDate.size();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view = null;
        ViewHolder viewHolder = null;

        if (convertView == null) {
            view = inflater.inflate(R.layout.activity_deliveredlist, null);
            viewHolder = new ViewHolder();
            viewHolder.txtSenderName = (TextView) view.findViewById(R.id.deliveredName);
            viewHolder.txtDate = (TextView) view.findViewById(R.id.deliveredDate);
            viewHolder.txtTime = (TextView) view.findViewById(R.id.deliveredTime);
            view.setTag(viewHolder);
        }
        else {
            view = convertView;
            viewHolder = ((ViewHolder) view.getTag());
        }

        viewHolder.txtSenderName.setText(allDataListName.get(position));
        viewHolder.txtDate.setText(allDataListDate.get(position));
        viewHolder.txtTime.setText(allDataListTime.get(position));
        return view;
    }
}
