package com.amrita.aerl.suraksha.Notification_Details;

import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.amrita.aerl.suraksha.AndroidTabLayoutActivity;
import com.amrita.aerl.suraksha.ConnectionDetector;
import com.amrita.aerl.suraksha.CustomListAdapter;
import com.amrita.aerl.suraksha.DBHelper;
import com.amrita.aerl.suraksha.Database_Contact;
import com.amrita.aerl.suraksha.FileUtils;
import com.amrita.aerl.suraksha.R;
import com.amrita.aerl.suraksha.RowItem;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import common.Constants;
import flex.messaging.io.amf.client.AMFConnection;
import flex.messaging.io.amf.client.exceptions.ClientStatusException;
import flex.messaging.io.amf.client.exceptions.ServerStatusException;

public class Notifications extends Fragment {
    CustomListAdapter customListAdapter;
    List<Database_Contact> dataList;
    Database_Contact contact;
    AMFConnection amfConnection;
    Constants constants;
    ListView listAllTitles;
    List<Database_Contact> dbuser;
    ArrayList<Object> Notifylist  = new ArrayList<>();
    String usrNum,
            downloadImages = "No",
            result_fetchmapdetails = "Yes",
            result_fetchimagedetails = "Yes",
            notify_Id,map_status,friends;
    String SenderName_,address_,mapcordinates_,imageurls_,videourls_,date_,time_;
    String image_total_url,video_total_url;
    View v;
    ProgressDialog progressDialog;
    DBHelper mydb;
    ArrayList<String> image_url = new ArrayList<String>();
    ArrayList<String> download_url = new ArrayList<String>();
    ArrayList<String> video_url = new ArrayList<String>();
    String[] stringArray,FilePathStrings;
    File file;
    public  File[] listFile;
    public String[] separated,separated_video;
    int i = 0,passedSenconds;
    Timer timer;
    TimerTask timerTask;
    String date = null, time= null;
    Boolean isInternetPresent = false;
    ConnectionDetector cd;
    int count,k = 0;
    ProgressBar pb;
    Dialog dialog;
    int video_size = 0;
    int downloadedSize = 0;
    int totalSize = 0;
    TextView cur_val;
    int videocount = 0;


    String notifyid;
    String notifyServerid;
    String friends_notify ;
    String mapstatus;



    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        v = inflater.inflate(R.layout.activity_notification, container, false);
        // Inflate the layout for this fragment
        Toast.makeText(getActivity(),R.string.check_internet,Toast.LENGTH_SHORT).show();
        listAllTitles = (ListView)v.findViewById(R.id.notifyList);
        mydb = new DBHelper(getActivity());
        cd = new ConnectionDetector(getActivity());
        isInternetPresent = cd.isConnectingToInternet();
        if (isInternetPresent){
            dbuser = mydb.getAllDatabase_Users();
            usrNum = dbuser.get(0).get_owner_phone_number();
            new fetchDetails().execute(usrNum);
            reScheduleTimer();
        }
        else
        {
            Toast.makeText(getActivity(),R.string.check_internet,Toast.LENGTH_SHORT).show();
        }
        List<Database_Contact> list = mydb.get_user_phone_number();
        Log.e("Notification Log ",list.get(0).get_owner_phone_number());
        usrNum = list.get(0).get_owner_phone_number().toString();

        dataList = new ArrayList<Database_Contact>();
        dataList = mydb.getNotifyList("1");

        customListAdapter = new CustomListAdapter(getActivity(), dataList);
        listAllTitles.setAdapter(customListAdapter);
        listAllTitles.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                int size = dataList.size();
                SenderName_ = dataList.get(position).getSenderName();
                address_ = dataList.get(position).getAddress();
                mapcordinates_ = dataList.get(position).getMap_coordinates();
                imageurls_ = dataList.get(position).getImageUrls();
                videourls_ = dataList.get(position).getVideoUrls();
                date_ = dataList.get(position).getDate();
                time_ = dataList.get(position).getTime();
                notify_Id = String.valueOf(dataList.get(position).getNotifylist_id());
                map_status = dataList.get(position).getNotifylist_map_status();
                friends = dataList.get(position).getReceiverNum();

                notifyid = String.valueOf(dataList.get(size-(position+1)).getNotifylist_id());
                notifyServerid = String.valueOf(dataList.get(size-(position+1)).getNotifylist_server_id());
                friends_notify = String.valueOf(dataList.get(size-(position+1)).getReceiverName());
                mapstatus = String.valueOf(dataList.get(size-(position+1)).getNotifylist_map_status());

                image_total_url = imageurls_.toString();
                String url  = image_total_url.replace("[","");
                url = url.replace("]","");
                image_total_url = url.replace(" ","");
                video_total_url = videourls_.toString();
                String videourl  = video_total_url.replace("[","");
                videourl = videourl.replace("]","");
                video_total_url = videourl.replace(" ","");

                image_url = new ArrayList<String>();
                if (!image_total_url.equals("No Image")){
                    separated = image_total_url.split(",");
                    int i  = separated.length;
                    file = new File(Environment.getExternalStorageDirectory()
                            .getPath() + "/Suraksha/Received/");
                    if (file.isDirectory()) {
                        listFile = file.listFiles();
                        FilePathStrings = new String[listFile.length];
                    }
                    for(int j=0 ; j<i ; j++){
                        File imagefile = new File(file.getAbsolutePath() + "/" + date_ + "_" + time_ + "/Images/Thumbnail/" + separated[j]);
                        String str = imagefile.getAbsolutePath().toString();
                        if (!imagefile.exists()) {
                            image_url.add(separated[j]);
                        }
                    }
                }

                if (!video_total_url.equals("No Video")){
                    separated_video = video_total_url.split(",");

                    int i  = separated_video.length;
                    file = new File(Environment.getExternalStorageDirectory()
                            .getPath() + "/Suraksha/Received/");
                    if (file.isDirectory()) {
                        listFile = file.listFiles();
                        FilePathStrings = new String[listFile.length];
                    }
                    for(int j=0 ; j<i ; j++){
                        File videofile = new File(file.getAbsolutePath() + "/" + date_ + "_" + time_ + "/Videos/" + separated_video[j]);
                        if (!videofile.exists()) {
                            video_url.add(separated_video[j]);
                            download_url.add(separated_video[j]);
                        }
                        else{
                        }
                    }
                }
                if (video_url.size()!= 0)
                {
                    progressDialog = new ProgressDialog(getActivity());
                    progressDialog.setTitle(getString(R.string.in_progress));
                    progressDialog.setMessage(getString(R.string.download_notify_video));
                    progressDialog.setCancelable(false);
                    progressDialog.show();
                    video_size = video_url.size();
                    downloadVideo();
                }
                else if (image_url.size() != 0)
                {
                    progressDialog = new ProgressDialog(getActivity());
                    progressDialog.setTitle(getString(R.string.in_progress));
                    progressDialog.setMessage(getString(R.string.download_notify_image));
                    progressDialog.setCancelable(false);
                    progressDialog.show();
                    stringArray = image_url.toArray(new String[0]);
                    GetXMLTask task = new GetXMLTask(getActivity());
                    task.execute(stringArray);
                }
                else{


                    Intent intent = new Intent(getActivity().getApplicationContext(), AndroidTabLayoutActivity.class);
                    intent.putExtra("NotifyId", notifyid);
                    intent.putExtra("SenderName", SenderName_);
                    intent.putExtra("address", address_);
                    intent.putExtra("date", date_);
                    intent.putExtra("time", time_);
                    intent.putExtra("Status", "1");
                    intent.putExtra("MapCoordinates", mapcordinates_);
                    intent.putExtra("imageurl", imageurls_);
                    intent.putExtra("videourl", videourls_);
                    intent.putExtra("notifyServerid", notifyServerid);
                    intent.putExtra("Friends",friends_notify);
                    intent.putExtra("MapStatus", mapstatus);
                    startActivity(intent);
                }
            }
        });
        return v;
    }

    public void reScheduleTimer(){
        timer = new Timer();
        timerTask = new myTimerTask();
        timer.schedule(timerTask, 0, 5000);
    }

    private class myTimerTask extends TimerTask {
        @Override
        public void run() {
            // TODO Auto-generated method stub
            passedSenconds++;
            updateLabel.sendEmptyMessage(0);
        }
    }

    private Handler updateLabel = new Handler(){
        @Override
        public void handleMessage(Message msg) {
            // TODO Auto-generated method stub
            //super.handleMessage(msg);
            int seconds = passedSenconds % 60;
            int minutes = (passedSenconds / 60) % 60;
            int hours = (passedSenconds / 3600);
            Log.e("Notification Timer " , result_fetchmapdetails + " : "+result_fetchimagedetails +" : "+ downloadImages);
            if (result_fetchmapdetails.equals("Yes") ){
                if (result_fetchimagedetails.equals("Yes") || count == 20){
                    timer.cancel();
                    dataList = mydb.getNotifyList("1");
                    customListAdapter.notifyDataSetChanged();
                    listAllTitles.invalidateViews();
                    listAllTitles.refreshDrawableState();
                }
            }
            else if (count == 50){
                timer.cancel();
            }
            else{
                count++;
            }
        }
    };

    public class fetchDetails extends AsyncTask<String, String, String> {
        @Override
        protected String doInBackground(String... arg0){
            String result = null;
            amfConnection = new AMFConnection();

            try {
                amfConnection.connect(constants.server);
            } catch (ClientStatusException cse) {
                result = "No connection";
                Log.d("ClientStatusException", cse.toString());
            }
            try {
                Object responseResult = (ArrayList<Object>) amfConnection.call(constants.FUNCTION_CALL_ND,usrNum);
                Notifylist = (ArrayList<Object>) responseResult;
                result = responseResult.toString();
                Log.e("Result of notify details " ,responseResult.toString());
            }
            catch (ClientStatusException cse) {
                result = "No connection";
                Log.d("ClientStatusException",cse.toString());
            }
            catch (ServerStatusException sse) {
                result = "Server Down";
                Log.d("ServerStatus:",sse.toString());
            }
            amfConnection.close();
            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            if (s.equals("Server Down")){
                Toast.makeText(getActivity(), "Server Down", Toast.LENGTH_SHORT).show();
            }
            else if (!s.equals("[]")){
                result_fetchmapdetails = "Yes";
                result_fetchimagedetails = "Yes";
                for (int i = 0;i<Notifylist.size();i++){
                    ArrayList<String> detailsList = (ArrayList<String>) Notifylist.get(i);
                    ArrayList<String> imagesList = (ArrayList<String>) Notifylist.get(i+1);
                    ArrayList<String> videosList = (ArrayList<String>) Notifylist.get(i+2);

                    if (!imagesList.equals("No Image Notification")){
                        String split_date_time = imagesList.get(0).toString();
                        separated = split_date_time.split("_");
                        date = separated[0].trim();
                        time = separated[1].trim();
                        String am_pm = separated[2].trim();
                        time = time+"_"+am_pm;
                    }
                    Integer a;
                    String str = null;
                    a = Integer.parseInt(String.valueOf(detailsList.get(0)));
                    str = String.valueOf(a);
                    mydb = new DBHelper(getActivity());
                    dbuser = mydb.getAllDatabase_Users();
                    contact = new Database_Contact();
                    contact.setNotifylist_server_id(str);
                    contact.setSenderName(detailsList.get(4));
                    contact.setReceiverName(detailsList.get(6));
                    contact.setReceiverNum("");
                    contact.setAddress(detailsList.get(2));
                    contact.setDate(date);
                    contact.setTime(time);
                    contact.setMap_coordinates(detailsList.get(1));
                    if (imagesList.get(0).equals("No Image Notification")){
                        contact.setImageUrls("No Image");
                    }
                    else{
                        contact.setImageUrls(imagesList.toString());
                    }
                    contact.setImageUrls(imagesList.toString());
                    if (videosList.get(0).equals("No Video Notification")){
                        contact.setVideoUrls("No Video");
                    }
                    else{
                        contact.setVideoUrls(videosList.toString());
                    }
                    contact.setNotifylist_status("1");
                    contact.setNotifylist_map_status("1");
                    contact.setNotifylist_sent_status("1");
                    mydb.addList(contact);
                    i= i+2;
                }
                mydb  = new DBHelper(getActivity());
                dataList = mydb.getNotifyList("1");
                Runnable run = new Runnable(){
                    public void run(){
                        Fragment frg = null;
                        frg = getActivity().getSupportFragmentManager().findFragmentByTag("Notifications");
                        final FragmentTransaction ft = getActivity().getSupportFragmentManager().beginTransaction();
                        ft.detach(frg);
                        ft.attach(frg);
                        ft.commit();
                    }
                };
                getActivity().runOnUiThread(run);
            }
            else {
                int no = 9;
            }
        }
    }

    private class GetXMLTask extends AsyncTask<String, Integer, List<RowItem>> {
        private Activity context;
        List<RowItem> rowItems;
        int noOfURLs;
        public GetXMLTask(Activity context) {
            this.context = context;
        }

        @Override
        protected List<RowItem> doInBackground(String... urls) {
            noOfURLs = urls.length;
            rowItems = new ArrayList<RowItem>();
            Bitmap map = null;
            for (String url : urls) {
                map = downloadImage(url);
                rowItems.add(new RowItem(map));
            }
            return rowItems;
        }

        private Bitmap downloadImage(String urlString) {
            int count = 0;
            Bitmap bitmap = null;

            URL url;
            InputStream inputStream = null;
            BufferedOutputStream outputStream = null;
            try {
                urlString = Constants.SNAPSHOT_LOCATION + urlString;
                url = new URL(urlString);
                String url_String= String.valueOf(url);
                separated = url_String.split("/Snapshots/");
                URLConnection connection = url.openConnection();
                int lenghtOfFile = connection.getContentLength();

                inputStream = new BufferedInputStream(url.openStream());
                ByteArrayOutputStream dataStream = new ByteArrayOutputStream();

                outputStream = new BufferedOutputStream(dataStream);

                byte data[] = new byte[1024];
                long total = 0;

                while ((count = inputStream.read(data)) != -1) {
                    total += count;
                /*publishing progress update on UI thread.
                Invokes onProgressUpdate()*/
                    publishProgress((int)((total*100)/lenghtOfFile));
                    outputStream.write(data, 0, count);
                }
                outputStream.close();

                BitmapFactory.Options bmOptions = new BitmapFactory.Options();
                bmOptions.inSampleSize = 1;

                byte[] bytes = dataStream.toByteArray();
                bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.length,bmOptions);

                OutputStream outStream = null;

                File mediaStorageDir = new File(Environment.getExternalStorageDirectory(), "Suraksha/Received/"+date_+"_"+time_+"/Images");
                if (!mediaStorageDir.exists()) {
                    if (!mediaStorageDir.mkdirs()) {
                        Log.d("Suraksha", "failed to create directory");
                    }
                }

                File mediaStorageDirThumbnail = new File(Environment.getExternalStorageDirectory(), "Suraksha/Received/"+date_+"_"+time_+"/Images/Thumbnail/");
                if (!mediaStorageDirThumbnail.exists()) {
                    if (!mediaStorageDirThumbnail.mkdirs()) {
                        Log.d("Suraksha", "failed to create directory");
                    }
                }

                String filename = separated[1];
                File file = new File(mediaStorageDir,filename);
                if (file.createNewFile()){
                    file.createNewFile();
                }
                if (!file.exists()) {
                    if (!file.mkdirs()) {
                        Log.e("Suraksha", "failed to create directory");
                    }
                }

                try {
                    outStream = new FileOutputStream(file);
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 90,outStream);
                    outStream.flush();
                    outStream.close();
                }catch (FileNotFoundException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }

                Bitmap b= BitmapFactory.decodeFile(file.getAbsolutePath());
                Bitmap out = Bitmap.createScaledBitmap(b, 100, 100, false);

                File thumbfile = new File(mediaStorageDirThumbnail, filename);
                FileOutputStream fOut;
                try {
                    fOut = new FileOutputStream(thumbfile);
                    out.compress(Bitmap.CompressFormat.PNG, 40, fOut);
                    fOut.flush();
                    fOut.close();
                    b.recycle();
                    out.recycle();
                } catch (Exception e) {}
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                FileUtils.close(inputStream);
                FileUtils.close(outputStream);
            }
            return bitmap;
        }

        protected void onProgressUpdate(Integer... progress) {
            progressDialog.setProgress(progress[0]);
            if(rowItems != null) {
            }
        }

        @Override
        protected void onPostExecute(List<RowItem> rowItems) {
            progressDialog.dismiss();
            timer.cancel();
            Intent intent = new Intent(getActivity().getApplicationContext(), AndroidTabLayoutActivity.class);
            intent.putExtra("Id", notify_Id);
            intent.putExtra("SenderName", SenderName_);
            intent.putExtra("address", address_);
            intent.putExtra("date", date_);
            intent.putExtra("time", time_);
            intent.putExtra("Status", "1");
            intent.putExtra("MapCoordinates", mapcordinates_);
            intent.putExtra("imageurl", image_total_url);
            intent.putExtra("Friends", friends);
            intent.putExtra("MapStatus", map_status);
            startActivity(intent);
        }
    }


    class DownloadVideoFile extends AsyncTask<String, String, String> {
        @Override
        protected String doInBackground(String... arg0) {
            amfConnection = new AMFConnection();
            try {
                amfConnection.connect(Constants.server);
            } catch (ClientStatusException cse) {
                Log.d("ClientStatusException", cse.toString());
            }
            try {
                video_url.remove(0);
                URL url = new URL(Constants.VIDEO_LOCATION + arg0[0]);
                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod("GET");
                urlConnection.setDoOutput(true);
                //connect
                urlConnection.connect();

                //set the path where we want to save the file
                // File SDCardRoot = Environment.getExternalStorageDirectory();
                File RootFile = new File(Environment.getExternalStorageDirectory(), "Suraksha/Received/" + date_ + "_" + time_ + "/Videos/");
                if (!RootFile.exists()) {
                    if (!RootFile.mkdirs()) {
                        Log.d("Suraksha", "failed to create directory");
                    }
                }
                RootFile.mkdir();
                File file = new File(RootFile, arg0[0]);

                FileOutputStream fileOutput = new FileOutputStream(file);
                InputStream inputStream = urlConnection.getInputStream();
                totalSize = urlConnection.getContentLength();
                //create a buffer...
                byte[] buffer = new byte[1024];
                int bufferLength = 0;
                while ((bufferLength = inputStream.read(buffer)) > 0) {
                    fileOutput.write(buffer, 0, bufferLength);
                    downloadedSize += bufferLength;
                    // update the progressbar //
                }
                //close the output stream when complete //
                fileOutput.close();

            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (ProtocolException e) {
                e.printStackTrace();
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(String s) {
            videocount = videocount+1;
            downloadVideo();
            super.onPostExecute(s);
        }
    }

    private void downloadVideo() {
        if (video_url.size()<video_size){
            video_size = video_size+1;
            new DownloadVideoFile().execute(video_url.get(videocount));
        }
        else if(image_url.size()>0){
            progressDialog = new ProgressDialog(getActivity());
            progressDialog.setTitle(getString(R.string.in_progress));
            progressDialog.setMessage(getString(R.string.download_notify_image));
            progressDialog.setCancelable(false);
            progressDialog.show();
            stringArray = image_url.toArray(new String[0]);
            GetXMLTask task = new GetXMLTask(getActivity());
            task.execute(stringArray);
        }
        else{
            Intent intent = new Intent(getActivity().getApplicationContext(), AndroidTabLayoutActivity.class);
            intent.putExtra("NotifyId", notifyid);
            intent.putExtra("SenderName", SenderName_);
            intent.putExtra("address", address_);
            intent.putExtra("date", date_);
            intent.putExtra("time", time_);
            intent.putExtra("Status", "1");
            intent.putExtra("MapCoordinates", mapcordinates_);
            intent.putExtra("imageurl", imageurls_);
            intent.putExtra("videourl", videourls_);
            intent.putExtra("notifyServerid", notifyServerid);
            intent.putExtra("Friends",friends_notify);
            intent.putExtra("MapStatus", mapstatus);
            startActivity(intent);
        }
    }
}