package com.amrita.aerl.suraksha;

/**
 * Created by Manoj on 5/24/2019.
 */

public interface StepListener {

    public void step(long timeNs);

}

