package com.amrita.aerl.suraksha.Notification_Details;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.os.AsyncTask;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.amrita.aerl.suraksha.DBHelper;
import com.amrita.aerl.suraksha.Database_Contact;
import com.amrita.aerl.suraksha.R;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import common.Constants;
import flex.messaging.io.amf.client.AMFConnection;
import flex.messaging.io.amf.client.exceptions.ClientStatusException;
import flex.messaging.io.amf.client.exceptions.ServerStatusException;

public class Customlist_notifySent extends ArrayAdapter<Database_Contact> implements Filterable {

    private List<Database_Contact> allDataList;
    private List<Database_Contact> filteredDataList;
    private Activity context;
    private LayoutInflater inflater;
    private NotifyFilter filter;
    String usrNum;
    public AMFConnection amfConnection;
    Database_Contact contact = new Database_Contact();


    public Customlist_notifySent(Activity context, List<Database_Contact> list,String usrNum) {
        super(context, R.layout.item, list);
        this.context = context;
        this.allDataList = new ArrayList<Database_Contact>();
        allDataList.addAll(list);
        this.usrNum = usrNum;
        this.filteredDataList = new ArrayList<Database_Contact>();
        filteredDataList.addAll(allDataList);
        Collections.sort(filteredDataList, new Comparator<Database_Contact>() {
            @Override
            public int compare(Database_Contact lhs, Database_Contact rhs) {
                if (lhs.getNotifylist_id() == rhs.getNotifylist_id())
                {
                    return 0;
                }
                else if (rhs.getNotifylist_id() < lhs.getNotifylist_id())
                {
                    return -1;
                }
                return 1;
            }
        });
        inflater = context.getLayoutInflater();
        getFilter();
    }

    @Override
    public Filter getFilter() {
        if (filter == null) {
            filter = new NotifyFilter();
        }
        return filter;
    }

    static class ViewHolder {
        protected TextView txtSenderName;
        protected TextView txtAddress;
        protected TextView txtDate;
        protected TextView txtTime;
        protected ImageView imgId;
        protected ImageView imgStatus;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view = null;
        contact = new Database_Contact();
        contact = filteredDataList.get(position);
        ViewHolder viewHolder = null;

        if (convertView == null) {
            view = inflater.inflate(R.layout.item, null);
            viewHolder = new ViewHolder();
            viewHolder.txtSenderName = (TextView) view.findViewById(R.id.txtListItemTitle);
            viewHolder.txtAddress = (TextView) view.findViewById(R.id.txtListItemAddress);
            viewHolder.txtDate = (TextView) view.findViewById(R.id.txtListItemDate);
            viewHolder.txtTime = (TextView) view.findViewById(R.id.txtListItemTime);
            viewHolder.imgId = (ImageView) view.findViewById(R.id.imgListItem);
            viewHolder.imgStatus = (ImageView) view.findViewById(R.id.imgStatus);
            view.setTag(viewHolder);
        }
        else {
            view = convertView;
            viewHolder = ((ViewHolder) view.getTag());
        }
        viewHolder.txtSenderName.setText(contact.getReceiverName());
        viewHolder.txtAddress.setText(contact.getAddress());
        viewHolder.txtDate.setText(contact.getDate());
        viewHolder.txtTime.setText(contact.getTime());
        viewHolder.imgId.setImageResource(R.drawable.imageicon);
        if (contact.getNotifylist_sent_status().equals("1") && contact.getNotifylist_map_status().equals("1")){
            viewHolder.imgStatus.setImageResource(R.drawable.com_facebook_button_like_icon_selected);
        }
        return view;
    }



    private class NotifyFilter extends Filter {
        @Override
        protected FilterResults performFiltering(CharSequence constraint) {
            constraint = constraint.toString().toUpperCase();
            FilterResults results = new FilterResults();
            if (constraint != null && constraint.toString().length() > 0) {
                ArrayList<Database_Contact> filteredItems = new ArrayList<Database_Contact>();
                ArrayList<Database_Contact> sortedItems = new ArrayList<Database_Contact>();

                for (int i=0; i < allDataList.size(); i++ ) {
                    Database_Contact contact = allDataList.get(i);
                    if(contact.getSenderName().startsWith(constraint.toString())){
                        filteredItems.add(contact);
                    }
                }
                for (int i=0; i < allDataList.size(); i++ ) {
                    Database_Contact contact = allDataList.get(i);
                    if (contact.getSenderName().contains(constraint) && !contact.getSenderName().startsWith(constraint.toString())) {
                        filteredItems.add(contact);
                    }
                }
                results.count = filteredItems.size();
                results.values = filteredItems;
            }
            else {
                synchronized (this) {
                    results.count = allDataList.size();
                    Log.d("Count","Data items: "+results.count);
                    results.values = allDataList;
                }
            }
            return results;
        }

        @Override
        protected void publishResults(CharSequence constraint, FilterResults results) {
            filteredDataList = (ArrayList<Database_Contact>) results.values;
            /*Collections.sort(filteredDataList, new Comparator<Database_Contact>() {
                @Override
                public int compare(Database_Contact lhs, Database_Contact rhs) {
                    Log.e("List Sorting 8", String.valueOf(lhs.getNotifylist_id()) + ":"+ String.valueOf(rhs.getNotifylist_id()));
                    if (lhs.getNotifylist_id() == rhs.getNotifylist_id())
                    {
                        return 0;
                    }
                    else if (lhs.getNotifylist_id() < rhs.getNotifylist_id())
                    {
                        return -1;
                    }
                    return 1;
                    *//*return lhs.getNotifylist_id().compareTo(rhs.getNotifylist_id());
                    return Integer.valueOf((int) lhs.getNotifylist_id()).compareTo(Integer.valueOf(String.valueOf(rhs.getNotifylist_id())));*//*
                }
            });*/
            notifyDataSetChanged();
            clear();
            for (int i=0; i < filteredDataList.size(); i++) {
                add(filteredDataList.get(i));
            }
            notifyDataSetInvalidated();
        }
    }
}
