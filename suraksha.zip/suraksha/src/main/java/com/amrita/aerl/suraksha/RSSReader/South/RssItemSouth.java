package com.amrita.aerl.suraksha.RSSReader.South;

/**
 * A representation of an rss item from the list.
 * 
 * @author Veaceslav Grec
 * 
 */
public class RssItemSouth {

	private final String title;
	private final String link;

	public RssItemSouth(String title, String link) {
		this.title = title;
		this.link = link;
	}

	public String getTitle() {
		return title;
	}

	public String getLink() {
		return link;
	}
}
