package com.amrita.aerl.suraksha.Notification_Details;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Filterable;
import android.widget.TextView;

import com.amrita.aerl.suraksha.Database_Contact;
import com.amrita.aerl.suraksha.R;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by rvinoth on 5/24/2015.
 */
public class CustomSentListAdapter extends ArrayAdapter<Database_Contact>{

    private List<String> allDataListName;
    private List<String> allDataListDate;
    private List<String> allDataListTime;
    private Activity context;
    private LayoutInflater inflater;
    public CustomSentListAdapter(Activity context, List<String> sentName,List<String> sentDate,List<String> sentTime) {
        super(context, R.layout.activity_sentlist);
        this.context = context;
        this.allDataListName = new ArrayList<String>();
        this.allDataListDate = new ArrayList<String>();
        this.allDataListTime = new ArrayList<String>();
        allDataListName.addAll(sentName);
        allDataListDate.addAll(sentDate);
        allDataListTime.addAll(sentTime);

    }
    static class ViewHolder {
        protected TextView txtSenderName;
        protected TextView txtDate;
        protected TextView txtTime;
    }

    @Override
    public int getCount() {
        return allDataListDate.size();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view = null;
        ViewHolder viewHolder = null;
        inflater = (LayoutInflater) context.getSystemService(Activity.LAYOUT_INFLATER_SERVICE);
        if (convertView == null) {
            view = inflater.inflate(R.layout.activity_sentlist, null);
            viewHolder = new ViewHolder();
            viewHolder.txtSenderName = (TextView) view.findViewById(R.id.sentName);
            viewHolder.txtDate = (TextView) view.findViewById(R.id.sentDate);
            viewHolder.txtTime = (TextView) view.findViewById(R.id.sentTime);
            view.setTag(viewHolder);
        }
        else {
            view = convertView;
            viewHolder = ((ViewHolder) view.getTag());
        }
        viewHolder.txtSenderName.setText(allDataListName.get(position));
        viewHolder.txtDate.setText(allDataListDate.get(position));
        viewHolder.txtTime.setText(allDataListTime.get(position));
        return view;
    }
}
