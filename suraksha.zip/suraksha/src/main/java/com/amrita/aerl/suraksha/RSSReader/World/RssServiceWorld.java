package com.amrita.aerl.suraksha.RSSReader.World;

import android.app.IntentService;
import android.content.Intent;
import android.support.v4.content.LocalBroadcastManager;
import android.util.Log;

import org.xmlpull.v1.XmlPullParserException;

import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;
import java.net.URL;
import java.util.List;

import common.Constants;

public class RssServiceWorld extends IntentService {

    public static final String ITEMS = "items";
    public static final String ACTION_RSS_PARSED = "com.amrita.aerl.suraksha.RSSreader.World.ACTION_RSS_PARSED";

    public RssServiceWorld() {
        super("RssServiceWorld");
    }
    @Override
    public void onCreate() {
        super.onCreate();
    }

    @Override
    protected void onHandleIntent(Intent intent) {
        String user = intent.getStringExtra("RSS");
        Log.d(Constants.TAG, "Service started");
        List<RssItemWorld> rssItems = null;
        try {
            PcWorldRssParserWorld parser = new PcWorldRssParserWorld();
            rssItems = parser.parse(getInputStream(user));
        } catch (XmlPullParserException | IOException e) {
            Log.w(e.getMessage(), e);
        }

        // Send result
        Intent resultIntent = new Intent(ACTION_RSS_PARSED);
        resultIntent.putExtra(ITEMS, (Serializable) rssItems);
        LocalBroadcastManager.getInstance(this).sendBroadcast(resultIntent);
    }

    public InputStream getInputStream(String link) {
        try {
            URL url = new URL(link);
            return url.openConnection().getInputStream();
        } catch (IOException e) {
            Log.w(Constants.TAG, "Exception while retrieving the input stream", e);
            return null;
        }
    }
}
