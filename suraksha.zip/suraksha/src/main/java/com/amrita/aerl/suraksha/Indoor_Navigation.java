package com.amrita.aerl.suraksha;

import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.LocationManager;
import android.net.Uri;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiManager;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.content.ContextCompat;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.facebook.FacebookSdk;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.GroundOverlay;
import com.google.android.gms.maps.model.GroundOverlayOptions;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;

import android.Manifest;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import common.Constants;
import common.amfFunctions;
import flex.messaging.io.amf.client.AMFConnection;
import flex.messaging.io.amf.client.exceptions.ClientStatusException;
import flex.messaging.io.amf.client.exceptions.ServerStatusException;

import static android.content.Context.SENSOR_SERVICE;
import static com.facebook.FacebookSdk.getApplicationContext;


public class Indoor_Navigation extends Fragment implements OnMapReadyCallback,StepListener,SensorEventListener {
    private TextView textView;
    private StepDetector simpleStepDetector;
    private SensorManager sensorManager;
    private Sensor accel,rot;
    private static final String TEXT_NUM_STEPS = "Number of Steps: ";
    SeekBar seekBar;
    private int numSteps;
    TextView TvSteps;
    LatLng sydney;
    Button BtnStart,BtnStop;
    CheckBox checkBox;
    float latest_rad;
    double step_length = 0.4;
    float width_plan = 3;
    float height_plan = 4;
    double nw_lat = -33.932024639240986;
    double nw_long = 151.0000141337514;
   // String ne = "-33.93168665140048,151.09276961535215";
    double ne_lat = -33.93247278401292;
    double ne_long = 151.04665908962488;

    public static final int PERMISSIONS_REQUEST_CODE_ACCESS_COARSE_LOCATION = 99;
    private final List<BitmapDescriptor> mImages = new ArrayList<BitmapDescriptor>();
    Button track_me_btn;
    Button locate_me_btn;

    private GoogleMap mMap;
    private GroundOverlay mGroundOverlay;
    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;
    Context c = getActivity();
    private WifiManager wifiManager;
    LocationManager lm;
    private List<ScanResult> results;
    boolean gps_enabled = false;
    boolean network_enabled = false;
    double old_x=-33.99893647432988,old_y=151.02304458618164,new_x,new_y;
    amfFunctions amf;
    String result;
    Object responseResult;
    Constants constants;
    AMFConnection amfConnection;
    LatLng l;
    double latitude;
    double longitude;
    double scale_x;
    double scale_y;
    TextView t;
    public Indoor_Navigation() {
        // Required empty public constructor
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_indoor__navigation, container, false);
        sydney = new LatLng(-34, 151);
        double diff1 = Math.pow(nw_lat-ne_lat,2);
        double diff2 = Math.pow(nw_long-ne_long,2);
        scale_x =  Math.sqrt(diff1+diff2);
        diff1 = Math.pow(Double.parseDouble(String.valueOf(sydney.latitude))- nw_lat,2);
        diff2 = Math.pow(Double.parseDouble(String.valueOf(sydney.longitude)) - nw_long,2);
        scale_y = Math.sqrt(diff1+diff2);
        scale_x=scale_x/width_plan;
        scale_y=scale_y/height_plan;
        //StepDetector sens = new StepDetector();
        //sens.STEP_THRESHOLD = ;
        locate_me_btn=(Button) v.findViewById(R.id.loc);
        track_me_btn=(Button) v.findViewById(R.id.trac);
        checkBox = (CheckBox) v.findViewById(R.id.checkBox);
        t =(TextView) v.findViewById(R.id.seekbarprogress);
        seekBar = (SeekBar) v.findViewById(R.id.seekBar3);
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            int pval = 0;
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress,
                                          boolean fromUser) {
                //Toast.makeText(getApplicationContext(),"seekbar progress: "+progress, Toast.LENGTH_SHORT).show();

                pval=progress;

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                //Toast.makeText(getApplicationContext(),"seekbar touch started!", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                //Toast.makeText(getApplicationContext(),"seekbar touch stopped!", Toast.LENGTH_SHORT).show();
                t.setText(pval + "/" + seekBar.getMax());
                if(checkBox.isChecked()) {
                    StepDetector.STEP_THRESHOLD = Float.parseFloat(String.valueOf(pval));
                }

            }
        });
        wifiManager = (WifiManager)
                getActivity().getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        SupportMapFragment smf = (SupportMapFragment) getChildFragmentManager().findFragmentById(R.id.map);
        smf.getMapAsync(this);
        lm = (LocationManager)getActivity().getSystemService(Context.LOCATION_SERVICE);
        sensorManager = (SensorManager) getActivity().getSystemService(SENSOR_SERVICE);
        accel = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        rot = sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR);
        simpleStepDetector = new StepDetector();
        simpleStepDetector.registerListener(this);

        TvSteps = (TextView) v.findViewById(R.id.tv_steps);
        BtnStart = (Button) v.findViewById(R.id.btn_start);
        BtnStop = (Button) v.findViewById(R.id.btn_stop);



        BtnStart.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {

                numSteps = 0;
                sensorManager.registerListener(Indoor_Navigation.this, accel, SensorManager.SENSOR_DELAY_FASTEST);
                sensorManager.registerListener(Indoor_Navigation.this, rot, SensorManager.SENSOR_DELAY_NORMAL);

            }
        });


        BtnStop.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View arg0) {

                sensorManager.unregisterListener(Indoor_Navigation.this);

            }
        });


        locate_me_btn.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View vi)
            {


                try {
                    gps_enabled = lm.isProviderEnabled(LocationManager.GPS_PROVIDER);
                } catch(Exception ex) {}

                try {
                    network_enabled = lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
                } catch(Exception ex) {}

                if(!gps_enabled && !network_enabled ) {
                    Toast.makeText(getActivity(), "please turn on.. location services", Toast.LENGTH_SHORT).show();

                    if (!wifiManager.isWifiEnabled()) {
                        Toast.makeText(getActivity(), "WiFi is disabled ... We need to enable it", Toast.LENGTH_LONG).show();
                        wifiManager.setWifiEnabled(true);
                    }


                }
                else{
                    if (!wifiManager.isWifiEnabled()) {
                        Toast.makeText(getActivity(), "WiFi is disabled ... We need to enable it", Toast.LENGTH_LONG).show();
                        wifiManager.setWifiEnabled(true);
                    }
                        if(mMap != null){
                            scanWifi();
                        }
                        else{
                            Toast.makeText(c, "Map not loaded", Toast.LENGTH_SHORT).show();
                        }
                }
            }
        });

track_me_btn.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
        Intent i = new Intent(getContext(),indoor2.class);
        startActivity(i);

    }
});

        return v;

    }

    BroadcastReceiver wifiReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            results = wifiManager.getScanResults();
            getActivity().unregisterReceiver(this);

            Collections.sort(results,new Comparator<ScanResult>(){
                public int compare(ScanResult o1, ScanResult o2){
                    return o1.level - o2.level;
                }
            });
            List<ScanResult> top3 = new ArrayList<ScanResult>(results.subList(results.size() -3, results.size()));
            // Toast.makeText(context, " "+top3.size()+" ", Toast.LENGTH_SHORT).show();
            for (ScanResult scanResult : top3) {
                // arrayList.add(scanResult.SSID + " - " + scanResult.capabilities);
                //adapter.notifyDataSetChanged();

                // Toast.makeText(context, " "+scanResult.level+" ", Toast.LENGTH_SHORT).show();
            }
            //Toast.makeText(this, "success"+results.size(), Toast.LENGTH_SHORT).show();
            JSONObject person = new  JSONObject ();
            try {
                person.put(top3.get(0).BSSID,top3.get(0).level );
                person.put(top3.get(1).BSSID,top3.get(1).level);
                person.put(top3.get(2).BSSID,top3.get(2).level);


            } catch (JSONException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            // System.out.println();
            Toast.makeText(context, person.toString(), Toast.LENGTH_SHORT).show();
            new FetchingLocationDetails().execute(person.toString());
        }


    };


    private void scanWifi() {

        getActivity().registerReceiver(wifiReceiver, new IntentFilter(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION));
        wifiManager.startScan();
        Toast.makeText(getActivity(), "Scanning WiFi ...", Toast.LENGTH_SHORT).show();
    }


    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        googleMap.setMapType(GoogleMap.MAP_TYPE_NONE);
        // Add a marker in Sydney and move the camera

       // mMap.addMarker(new MarkerOptions().position(sydney).title("Marker in Sydney"));
        mImages.clear();
        mImages.add(BitmapDescriptorFactory.fromResource(R.drawable.fin));
        mGroundOverlay = googleMap.addGroundOverlay(new GroundOverlayOptions()
                .image(mImages.get(0)).anchor(0, 1)
                .position(sydney, 8600f, 7577f)
                .bearing(0));
        /*googleMap.addPolyline(new PolylineOptions()
                .add(
                        new LatLng(-35.016, 143.321),
                        new LatLng(-34.747, 145.592)));
        googleMap.addPolyline(new PolylineOptions()
                .add(
                        new LatLng(-32.306, 149.248),
                        new LatLng(-32.491, 147.309)));*/
        LatLng l =new LatLng(old_x,old_y);
        MarkerOptions markerOptions = new MarkerOptions();

        // Setting the position for the marker
        markerOptions.position(l);

        // Setting the title for the marker.
        // This will be displayed on taping the marker
        markerOptions.title(l.latitude + " : " + l.longitude);
        mMap.addMarker(markerOptions);
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(sydney, 11));
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
            simpleStepDetector.updateAccel(
                    event.timestamp, event.values[0], event.values[1], event.values[2]);
        }
        else if(event.sensor.getType() == Sensor.TYPE_ROTATION_VECTOR){
            float[] rotationMatrix = new float[16];
            SensorManager.getRotationMatrixFromVector(
                    rotationMatrix, event.values);
            /*float[] remappedRotationMatrix = new float[16];
            SensorManager.remapCoordinateSystem(rotationMatrix,
                    SensorManager.AXIS_X,
                    SensorManager.AXIS_Z,
                    remappedRotationMatrix);*/

// Convert to orientations
            float[] orientations = new float[3];
            SensorManager.getOrientation(rotationMatrix, orientations);
            latest_rad = orientations[0];
            for(int i = 0; i < 3; i++) {
                orientations[i] = (float)(Math.toDegrees(orientations[i]));
            }
            latest_rad = (float) Math.toRadians(90 - orientations[0]);

            //TvSteps.setText("Angle"+ (int) orientations[0]);
            //TvSteps.setText("Angle"+Math.toDegrees(latest_rad));
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {

    }

    @Override
    public void step(long timeNs) {
        numSteps++;
        if(!checkBox.isChecked()){
        new_x = old_x + step_length * (Math.sin(latest_rad) * scale_x );
        new_y = old_y + step_length * (Math.cos(latest_rad) * scale_y);
            LatLng l =new LatLng(new_x,new_y);
            MarkerOptions markerOptions = new MarkerOptions();

            // Setting the position for the marker
            markerOptions.position(l);

            // Setting the title for the marker.
            // This will be displayed on taping the marker
            markerOptions.title(l.latitude + " : " + l.longitude);
            mMap.addMarker(markerOptions);
            mMap.addPolyline(new PolylineOptions()
                    .add(
                            new LatLng(old_x, old_y),
                            new LatLng(new_x, new_y)));
        old_x = new_x;
        old_y = new_y;
        }

       // Toast.makeText(getActivity(), " "+Math.toDegrees(latest_rad), Toast.LENGTH_SHORT).show();
        TvSteps.setText(TEXT_NUM_STEPS +": "+ numSteps +", "+"Angle: "+Math.toDegrees(latest_rad));
    }

    class FetchingLocationDetails extends AsyncTask<String, String,String> {
        @Override
        protected String doInBackground(String... arg0){
            amfConnection = new AMFConnection();
            try {
                amfConnection.connect(constants.server);
            } catch (ClientStatusException cse) {
                result = "No connection";
                Log.d("ClientStatusException", cse.toString());
            }

                    try {
                        responseResult = amfConnection.call(constants.FUNCTION_CALL_Fon, arg0[0]);

                        result = (String) responseResult;
                        String[] latlong = result.split(",");
                         latitude = Double.parseDouble(latlong[0]);
                        longitude = Double.parseDouble(latlong[1]);

                        Log.e("Result of map details ", responseResult.toString());
                    } catch (ClientStatusException cse) {
                        result = "No connection";
                        Log.d("ClientStatusException", cse.toString());
                    } catch (ServerStatusException sse) {
                        result = "Server Down";
                        Log.d("ServerStatus:", sse.toString());
                    }

            amfConnection.close();
            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);

            l = new LatLng(latitude,longitude);
            CameraUpdate location = CameraUpdateFactory.newLatLngZoom(
                    l, 15);
            MarkerOptions markerOptions = new MarkerOptions();

            // Setting the position for the marker
            markerOptions.position(l);

            // Setting the title for the marker.
            // This will be displayed on taping the marker
            markerOptions.title(l.latitude + " : " + l.longitude);
            mMap.addMarker(markerOptions);
            mMap.animateCamera(location);


        }
    }
}
