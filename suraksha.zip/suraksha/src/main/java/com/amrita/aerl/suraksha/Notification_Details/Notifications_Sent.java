package com.amrita.aerl.suraksha.Notification_Details;

import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.provider.ContactsContract;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import com.amrita.aerl.suraksha.AndroidTabLayoutActivity;
import com.amrita.aerl.suraksha.ConnectionDetector;
import com.amrita.aerl.suraksha.CustomListAdapter;
import com.amrita.aerl.suraksha.DBHelper;
import com.amrita.aerl.suraksha.Database_Contact;
import com.amrita.aerl.suraksha.FileUtils;
import com.amrita.aerl.suraksha.R;
import com.amrita.aerl.suraksha.RowItem;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import common.Constants;
import flex.messaging.io.amf.client.AMFConnection;
import flex.messaging.io.amf.client.exceptions.ClientStatusException;
import flex.messaging.io.amf.client.exceptions.ServerStatusException;

/**
 * Created by rknikhil on 4/29/2016.
 */
public class Notifications_Sent extends Fragment {
    Customlist_notifySent customListAdapter;
    List<Database_Contact> dataList;
    ListView listAllTitles;
    String usrNum,SenderName_,address_,mapcordinates_,imageurls_,videourls_,date_,time_,type_;
    DBHelper mydb;
    public String[] separated;
    ArrayList<Database_Contact> Image_Status = new ArrayList<Database_Contact>();
    View v;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        v = inflater.inflate(R.layout.activity_notification_sent, container, false);
        // Inflate the layout for this fragment
        listAllTitles = (ListView)v.findViewById(R.id.notifyListSent);
        mydb = new DBHelper(getActivity());

        List<Database_Contact> list = mydb.get_user_phone_number();
        Log.e("Notification Log ",list.get(0).get_owner_phone_number());
        usrNum = list.get(0).get_owner_phone_number().toString();

        dataList = new ArrayList<Database_Contact>();
        dataList = mydb.getNotifyList("0");
        for (int k=0;k<dataList.size();k++){
            if (dataList.get(k).getNotifylist_sent_status().equals("0")){
                String sample = dataList.get(k).getImageUrls();
                String fileName = sample;
                String helloWorld = fileName;
                fileName = helloWorld.replace("[","");
                helloWorld =fileName;
                fileName = helloWorld.replace("]","");
                helloWorld =fileName;
                fileName = helloWorld.replace(" ","");
                separated = fileName.split(",");
                int i  = separated.length;
                int count = 0;
                for(int j=0 ; j<i ; j++){
                    File file = new File(Environment.getExternalStorageDirectory()
                            + File.separator + "Suraksha/Sent/");
                    String path = file+"/"+separated[j];
                    Image_Status = mydb.getImageUpload_Status(path);
                    if (Image_Status.size() > 0){
                        if (Image_Status.get(0).getImage_status().equals("0")){
                            count++;
                        }
                    }
                    if ((i-1) == j){
                        if (count == 0){
                            mydb.setNotifySentStatus(dataList.get(k).getNotifylist_id(),"1");
                        }
                        else {
                            count = 0;
                        }
                    }
                }
            }
        }
        mydb = new DBHelper(getActivity());
        dataList = mydb.getNotifyList("0");
        customListAdapter = new Customlist_notifySent(getActivity(), dataList,usrNum);
        listAllTitles.setAdapter(customListAdapter);
        listAllTitles.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                int size = dataList.size();
                mydb = new DBHelper(getActivity());
                List<Database_Contact> users = mydb.getAllDatabase_Users();
                SenderName_ = users.get(0).get_owner_name();
                address_ = dataList.get(size-(position+1)).getAddress();
                mapcordinates_ = dataList.get(size-(position+1)).getMap_coordinates();
                imageurls_ = dataList.get(size-(position+1)).getImageUrls();
                videourls_ = dataList.get(size-(position+1)).getVideoUrls();
                date_ = dataList.get(size-(position+1)).getDate();
                time_ = dataList.get(size-(position+1)).getTime();

                Intent intent = new Intent(getActivity().getApplicationContext(), AndroidTabLayoutActivity.class);
                String notifyid = String.valueOf(dataList.get(size-(position+1)).getNotifylist_id());
                intent.putExtra("NotifyId", notifyid);
                intent.putExtra("SenderName", SenderName_);
                intent.putExtra("address", address_);
                intent.putExtra("date", date_);
                intent.putExtra("time", time_);
                intent.putExtra("Status", "0");
                intent.putExtra("MapCoordinates", mapcordinates_);
                intent.putExtra("imageurl", imageurls_);
                intent.putExtra("videourl", videourls_);
                intent.putExtra("Friends",dataList.get(size-(position+1)).getReceiverNum());
                intent.putExtra("MapStatus", dataList.get(size-(position+1)).getNotifylist_map_status());
                startActivity(intent);
            }
        });
        return v;
    }
}
