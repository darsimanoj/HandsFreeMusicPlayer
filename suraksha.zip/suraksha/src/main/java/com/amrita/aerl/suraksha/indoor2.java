package com.amrita.aerl.suraksha;

import android.Manifest;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.location.LocationManager;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiManager;
import android.os.AsyncTask;
import android.os.Build;
import android.provider.Settings;
import android.support.annotation.DrawableRes;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentActivity;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v4.graphics.drawable.DrawableCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.ContextThemeWrapper;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.GroundOverlay;
import com.google.android.gms.maps.model.GroundOverlayOptions;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.GoogleMap.OnMapClickListener;
import com.google.android.gms.maps.GoogleMap.OnMarkerClickListener;


import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import common.Constants;
import common.amfFunctions;
import flex.messaging.io.amf.client.AMFConnection;
import flex.messaging.io.amf.client.exceptions.ClientStatusException;
import flex.messaging.io.amf.client.exceptions.ServerStatusException;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import static com.amrita.aerl.suraksha.Indoor_Navigation.PERMISSIONS_REQUEST_CODE_ACCESS_COARSE_LOCATION;

public class indoor2 extends AppCompatActivity implements OnMapReadyCallback, OnMapClickListener ,OnMarkerClickListener {
    private GroundOverlay mGroundOverlay;
    private GoogleMap mMap;
    private static final String RC_LOCATION = "1";

    private List<ScanResult> results;
    private final List<BitmapDescriptor> mImages = new ArrayList<BitmapDescriptor>();
    AMFConnection amfConnection;
    String result;
    Marker mPositionMarker;
    Constants constants;
    Context context = this;
    LocationManager lm;
    ProgressDialog progressDialog;
    public static final int MY_PERMISSIONS_REQUEST_LOCATION = 99;
    Object responseResult;
    private WifiManager wifiManager;
    int i=0;
    ArrayList<Sample_Point> list_to_DB = new ArrayList<Sample_Point>();
    ArrayList<String> String_to_DB = new ArrayList<String>();
    boolean gps_enabled = false;
    boolean network_enabled = false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_indoor2);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
       // wifiManager = (WifiManager) indoor2.this.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        lm = (LocationManager)context.getSystemService(Context.LOCATION_SERVICE);
        try {
            gps_enabled = lm.isProviderEnabled(LocationManager.GPS_PROVIDER);
        } catch(Exception ex) {}

        try {
            network_enabled = lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
        } catch(Exception ex) {}

        if(!gps_enabled && !network_enabled) {
            // notify user
            new AlertDialog.Builder(context)
                    .setMessage("gps_network_not_enabled")
                    .setPositiveButton("ok", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface paramDialogInterface, int paramInt) {
                            context.startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS));

                        }
                    })
                    .setNegativeButton("Cancel",null)
                    .show();

        }


    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        googleMap.setMapType(GoogleMap.MAP_TYPE_NONE);
        // Add a marker in Sydney and move the camera
        LatLng sydney = new LatLng(-34, 151);
       // mMap.addMarker(new MarkerOptions().position(sydney).title("Marker in Sydney"));
        mImages.clear();
        mImages.add(BitmapDescriptorFactory.fromResource(R.drawable.fin));
        mGroundOverlay = googleMap.addGroundOverlay(new GroundOverlayOptions()
                .image(mImages.get(0)).anchor(0, 1)
                .position(sydney, 8600f, 7577f)
                .bearing(0));

        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(sydney, 11));
        mMap.setOnMapClickListener(this);
        mMap.setOnMarkerClickListener(this);

       // wifiManager = (WifiManager) this.getApplicationContext().getSystemService(Context.WIFI_SERVICE);

    }

    @Override
    public void onMapClick(LatLng latLng) {
       /* mMap.setOnMapClickListener(null);
        mMap.setOnMarkerClickListener(null);*/

        try {
            gps_enabled = lm.isProviderEnabled(LocationManager.GPS_PROVIDER);
        } catch(Exception ex) {}

        try {
            network_enabled = lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
        } catch(Exception ex) {}
        if(!gps_enabled && !network_enabled) {

            Toast.makeText(this, "please turn on.. location services", Toast.LENGTH_SHORT).show();

        }
        else {
            mMap.addMarker(new MarkerOptions().icon(getBitmapFromVectorDrawable(this, R.drawable.manoj))
                    .anchor(0.5f, 0.5f).position(latLng).title(Integer.toString(i)));
            i++;

            Wifi_Scan(latLng);
            progressDialog = new ProgressDialog(this);
            progressDialog.setTitle("");
            progressDialog.setMessage("Loading");
            progressDialog.setCancelable(false);
            progressDialog.show();
           /* String json = getWiFi_json();
            double x = latLng.latitude;
            double y = latLng.longitude;
            Sample_Point s = new Sample_Point(json, x, y);
            list_to_DB.add(s);
            String_to_DB.add(json + "=" + x + "=" + y);*/
        }

    }
    @Override
    public boolean onMarkerClick(final Marker marker) {
        LayoutInflater li = LayoutInflater.from(this);
        View promptsView = li.inflate(R.layout.promptse, null);
        TextView textView = (TextView) promptsView.findViewById(R.id.textView1);
        LatLng position = marker.getPosition();
        textView.setText("remove marker at"+position);
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(new ContextThemeWrapper(this, R.style.myDialog));

        // set prompts.xml to alertdialog builder
        alertDialogBuilder.setView(promptsView);

        // set dialog message
        alertDialogBuilder
                .setCancelable(true)
                .setPositiveButton("OK",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog,int id) {
                                // get user input and set it to result
                                // edit text
                                //result.setText(userInput.getText());
                                LatLng position = marker.getPosition();
                                for(int  i=0;i<list_to_DB.size();i++){
                                    if(list_to_DB.get(i).x == position.latitude && list_to_DB.get(i).y == position.longitude){
                                        //int index = list_to_DB.indexOf();
                                        list_to_DB.remove(i);
                                        String_to_DB.remove(i);
                                    }
                                    //something here
                                }
                                marker.remove();

                            }
                        })
                .setNegativeButton("Cancel",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog,int id) {
                                dialog.cancel();
                            }
                        });

        // create alert dialog
        AlertDialog alertDialog = alertDialogBuilder.create();

        // show it
        alertDialog.show();

return  true;
    }



    public void Wifi_Scan(final LatLng latLng){
        wifiManager = (WifiManager)
                context.getSystemService(Context.WIFI_SERVICE);
        if (!wifiManager.isWifiEnabled()) {
            Toast.makeText(this, "WiFi is disabled ... We need to enable it", Toast.LENGTH_LONG).show();
            wifiManager.setWifiEnabled(true);
        }
        BroadcastReceiver wifiScanReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context c, Intent intent) {
                boolean success = intent.getBooleanExtra(
                        WifiManager.EXTRA_RESULTS_UPDATED, false);
                if (success) {
                    List<Integer> Strength;
                    List<ScanResult> results = wifiManager.getScanResults();

                    Collections.sort(results,new Comparator<ScanResult>(){
                        public int compare(ScanResult o1, ScanResult o2){
                            return o1.level - o2.level;
                        }
                    });
                    List<ScanResult> top3 = new ArrayList<ScanResult>(results.subList(results.size() -3, results.size()));
                   // Toast.makeText(context, " "+top3.size()+" ", Toast.LENGTH_SHORT).show();
                    for (ScanResult scanResult : top3) {
                        // arrayList.add(scanResult.SSID + " - " + scanResult.capabilities);
                        //adapter.notifyDataSetChanged();

                       // Toast.makeText(context, " "+scanResult.level+" ", Toast.LENGTH_SHORT).show();
                    }
                    //Toast.makeText(this, "success"+results.size(), Toast.LENGTH_SHORT).show();
                    JSONObject person = new  JSONObject ();
                    try {
                        person.put(top3.get(0).BSSID,top3.get(0).level );
                        person.put(top3.get(1).BSSID,top3.get(1).level);
                        person.put(top3.get(2).BSSID,top3.get(2).level);


                    } catch (JSONException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                   // System.out.println();
                    Toast.makeText(context, person.toString(), Toast.LENGTH_SHORT).show();
                    String json = person.toString();
                    double x = latLng.latitude;
                    double y = latLng.longitude;
                    Sample_Point s = new Sample_Point(json, x, y);
                    list_to_DB.add(s);
                    String_to_DB.add(json + "=" + x + "=" + y);
                    /*mMap.setOnMapClickListener((OnMapClickListener) context);
                    mMap.setOnMarkerClickListener((OnMarkerClickListener) context);*/
                    progressDialog.dismiss();

                } else {
                    // scan failure handling
                   // List<ScanResult> results = wifiManager.getScanResults();
                    Toast.makeText(context, "failed", Toast.LENGTH_SHORT).show();
                    progressDialog.dismiss();
                }
                context.unregisterReceiver(this);

            }
        };

        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION);
        context.registerReceiver(wifiScanReceiver, intentFilter);
        String location = android.Manifest.permission.ACCESS_COARSE_LOCATION;
        if (ActivityCompat.checkSelfPermission(this, location) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,new String[] {Manifest.permission.ACCESS_COARSE_LOCATION }, Integer.parseInt(RC_LOCATION));
        } else {
            boolean success = wifiManager.startScan();
            if (!success) {
                // scan failure handling
                //List<ScanResult> results = wifiManager.getScanResults();
                Toast.makeText(this, "failed", Toast.LENGTH_SHORT).show();
            }
        }


        return;
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        if (requestCode == Integer.parseInt(RC_LOCATION)) {
            if (results[0] == PackageManager.PERMISSION_GRANTED) {
                boolean success=wifiManager.startScan();
                if (!success) {
                    // scan failure handling
                    //List<ScanResult> results = wifiManager.getScanResults();
                    Toast.makeText(this, "failed", Toast.LENGTH_SHORT).show();
                }
            } else {
                // user rejected permission request
            }
        } else {
            super.onRequestPermissionsResult(requestCode, permissions, results);
        }
    }


    public void send_to_DB(View v){
        String[] s = new String[String_to_DB.size()];
       s = String_to_DB.toArray(s);
       // String[] s = (String[]) String_to_DB.toArray();
        new SendTrainData().execute(s);
    }
    public static BitmapDescriptor getBitmapFromVectorDrawable(Context context, int drawableId) {
        Drawable drawable = ContextCompat.getDrawable(context, drawableId);
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) {
            drawable = (DrawableCompat.wrap(drawable)).mutate();
        }

        Bitmap bitmap = Bitmap.createBitmap(drawable.getIntrinsicWidth(),
                drawable.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        drawable.setBounds(0, 0, canvas.getWidth(), canvas.getHeight());
        drawable.draw(canvas);

        return BitmapDescriptorFactory.fromBitmap(bitmap);
    }
   /* private void scanSuccess() {

    }

    private void scanFailure() {
        // handle failure: new scan did NOT succeed
        // consider using old scan results: these are the OLD results!

    }*/

    /*@Override
    public int compare(ScanResult scanResult, ScanResult t1) {
        int startComparison = compare(scanResult.level, t1.level);
        return startComparison != 0 ? startComparison
                : compare(scanResult.level, t1.level);
    }

    // I don't know why this isn't in Long...
    private static int compare(int a, int b) {
        return a < b ? -1
                : a > b ? 1
                : 0;
    }*/


    class SendTrainData extends AsyncTask<String[],String,String> {

        @Override
        protected String doInBackground(String[]... strings) {
            amfConnection = new AMFConnection();
            try {
                amfConnection.connect(constants.server);
            } catch (ClientStatusException cse) {
                result = "No connection";
                Log.d("ClientStatusException", cse.toString());
            }

            try {
               // Toast.makeText(context, strings[0][0], Toast.LENGTH_SHORT).show();
                responseResult = amfConnection.call(constants.FUNCTION_CALL_Foff, strings);
                result = "Success";
                //  o= (ArrayList) responseResult;

               // Log.e("Result of map details ", responseResult.toString());
            } catch (ClientStatusException cse) {
                result = "No connection";
                Log.d("ClientStatusException", cse.toString());
            } catch (ServerStatusException sse) {
                result = "Server Down";
                Log.d("ServerStatus:", sse.toString());
            }

            amfConnection.close();
            return result;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            Toast.makeText(indoor2.this, result, Toast.LENGTH_SHORT).show();
        }
    }

}
