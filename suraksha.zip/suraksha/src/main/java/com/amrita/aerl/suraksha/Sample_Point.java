package com.amrita.aerl.suraksha;

/**
 * Created by Manoj on 5/13/2019.
 */

public class Sample_Point  {
    String json;
    double x;
    double y;
    public  Sample_Point(String s,double a,double b){
        this.json=s;
        this.x=a;
        this.y=b;
    }
}
