package com.amrita.aerl.suraksha;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

public class mapview extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    GoogleMap gMap;
    Intent in;
    String[] country={"1hr before","5hr before","12hr before"};
    LatLng latlng = new LatLng(23.63936, 68.14712);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.map4);
        getSupportActionBar().setTitle("Suraksha");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        Spinner spin = (Spinner) findViewById(R.id.spin);
        spin.setOnItemSelectedListener(this);
        TextView t =(TextView) findViewById(R.id.ee) ;
        TextView t1=(TextView) findViewById(R.id.tv) ;
        t1.setText(getIntent().getExtras().getString("name")+"'s Current Location");
        //Creating the ArrayAdapter instance having the country list
        ArrayAdapter<String> aa = new ArrayAdapter<String>(this,R.layout.spin_item_hrs,country);
        //Setting the ArrayAdapter data on the Spinner

        spin.setAdapter(aa);
        mapFragment.getMapAsync(new OnMapReadyCallback() {
            @Override
            public void onMapReady(GoogleMap googleMap) {
                gMap = googleMap;
            }
        });

    }
    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
        gMap.addMarker(new MarkerOptions().position(latlng).title("Test title").snippet("test snippet"));
        CameraPosition cPos = new CameraPosition.Builder().target(latlng).zoom(12).build();
        gMap.animateCamera(CameraUpdateFactory.newCameraPosition(cPos));
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }



}
