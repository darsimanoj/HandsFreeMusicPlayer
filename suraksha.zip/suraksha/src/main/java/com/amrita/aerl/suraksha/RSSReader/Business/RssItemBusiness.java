package com.amrita.aerl.suraksha.RSSReader.Business;

/**
 * A representation of an rss item from the list.
 * 
 * @author Veaceslav Grec
 * 
 */
public class RssItemBusiness {

	private final String title;
	private final String link;

	public RssItemBusiness(String title, String link) {
		this.title = title;
		this.link = link;
	}

	public String getTitle() {
		return title;
	}

	public String getLink() {
		return link;
	}
}
