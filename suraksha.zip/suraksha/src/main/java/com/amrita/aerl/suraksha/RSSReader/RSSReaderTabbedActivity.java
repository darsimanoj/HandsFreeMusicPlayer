package com.amrita.aerl.suraksha.RSSReader;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.TabLayout;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.amrita.aerl.suraksha.R;
import com.amrita.aerl.suraksha.RSSReader.Auto.RssFragmentAuto;
import com.amrita.aerl.suraksha.RSSReader.Business.RssFragmentBusiness;
import com.amrita.aerl.suraksha.RSSReader.Health.RssFragmentHealth;
import com.amrita.aerl.suraksha.RSSReader.India.RssFragmentIndia;
import com.amrita.aerl.suraksha.RSSReader.IndianAbroad.RssFragmentIndiaAbroad;
import com.amrita.aerl.suraksha.RSSReader.Latest.RssFragmentLatest;
import com.amrita.aerl.suraksha.RSSReader.South.RssFragmentSouth;
import com.amrita.aerl.suraksha.RSSReader.Sports.RssFragmentSports;
import com.amrita.aerl.suraksha.RSSReader.Tech.RssFragmentTech;
import com.amrita.aerl.suraksha.RSSReader.TopStories.RssFragment;
import com.amrita.aerl.suraksha.RSSReader.Trending.RssFragmentTrending;
import com.amrita.aerl.suraksha.RSSReader.World.RssFragmentWorld;

import java.util.ArrayList;
import java.util.List;

import common.Constants;

public class RSSReaderTabbedActivity extends Fragment {
    Constants constants;
    public static TabLayout tabLayout;
    public static ViewPager viewPager;
    public static int int_items = 2;
    ViewPagerAdapter adapter;
    MyAdapter mMyAdapter;
    ArrayList<Fragment> fr_list;


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View x =  inflater.inflate(R.layout.activity_tabbedactivity,container,false);
        viewPager = (ViewPager) x.findViewById(R.id.viewpager);
        //setupViewPager(viewPager);

        fr_list = new ArrayList<Fragment>();
        fr_list.add(new RssFragment());
        fr_list.add(new RssFragmentLatest());
        fr_list.add(new RssFragmentTrending());
        fr_list.add(new RssFragmentIndia());
        fr_list.add(new RssFragmentWorld());
        fr_list.add(new RssFragmentBusiness());
        fr_list.add(new RssFragmentSports());
        fr_list.add(new RssFragmentTech());
        fr_list.add(new RssFragmentAuto());
        fr_list.add(new RssFragmentSouth());
        fr_list.add(new RssFragmentIndiaAbroad());
        fr_list.add(new RssFragmentHealth());
        mMyAdapter = new MyAdapter(getChildFragmentManager(),fr_list);
        viewPager.setAdapter(mMyAdapter);

        tabLayout = (TabLayout) x.findViewById(R.id.tabs);
        tabLayout.post(new Runnable() {
            @Override
            public void run() {
                tabLayout.setupWithViewPager(viewPager);
            }
        });

        viewPager.setOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                /*switch (position){
                    case 0 : ((RssFragment)adapter.getItem(position)).refresh();
                    case 1 : ((RssFragmentLatest)mMyAdapter.fr_list.get(position)).refresh();
                }
                ((RssFragment) mMyAdapter.fr_list.get(0)).refresh();
                Log.e("onTabSelected", String.valueOf(position));*/
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });
        return x;
    }


    private void setupViewPager(ViewPager viewPager) {

    }

    class ViewPagerAdapter extends FragmentPagerAdapter {
        private final List<Fragment> mFragmentList = new ArrayList<>();
        private final List<String> mFragmentTitleList = new ArrayList<>();

        public ViewPagerAdapter(FragmentManager manager) {
            super(manager);
        }

        @Override
        public Fragment getItem(int position) {
            return mFragmentList.get(position);
        }

        @Override
        public int getCount() {
            return mFragmentList.size();
        }

        public void addFrag(Fragment fragment, String title) {
            mFragmentList.add(fragment);
            mFragmentTitleList.add(title);
        }

        @Override
        public CharSequence getPageTitle(int position) {
            return mFragmentTitleList.get(position);
        }
    }

    class MyAdapter extends FragmentStatePagerAdapter {
        private final ArrayList<Fragment> fr_list;
        int mNumOfTabs;
        public MyAdapter(FragmentManager fm,ArrayList<Fragment> fr_list) {
            super(fm);
            this.fr_list=fr_list;
            //this.mNumOfTabs = NumOfTabs;
        }
        /**
         * Return fragment with respect to Position .
         */
        @Override
        public Fragment getItem(int position)
        {
            /*switch (position){
                case 0 :
                    return new RssFragment();
                case 1 :
                    return new RssFragmentLatest();
                default:
                    return null;
            }*/
            return fr_list.get(position);
        }
        @Override
        public int getCount() {
            //return int_items;
            return fr_list.size();
        }
        /**
         * This method returns the title of the tab according to the position.
         */
        @Override
        public CharSequence getPageTitle(int position) {
            switch (position){
                case 0 :
                    return "Top Stories";
                case 1 :
                    return "Latest";
                case 2 :
                    return "Trending";
                case 3 :
                    return "India";
                case 4 :
                    return "World";
                case 5 :
                    return "Business";
                case 6 :
                    return "Sports";
                case 7 :
                    return "Tech";
                case 8 :
                    return "Auto";
                case 9 :
                    return "South";
                case 10 :
                    return "Indians Abroad";
                case 11 :
                    return "Health";
            }
            return null;
        }
    }
}

