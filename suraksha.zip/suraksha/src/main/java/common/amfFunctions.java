package common;

import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.EditText;

import com.amrita.aerl.suraksha.HomeFragment;
import com.amrita.aerl.suraksha.NavigationDrawer;
import com.amrita.aerl.suraksha.ReceiverSide;

import java.util.ArrayList;

import flex.messaging.io.amf.client.AMFConnection;
import flex.messaging.io.amf.client.exceptions.ClientStatusException;
import flex.messaging.io.amf.client.exceptions.ServerStatusException;

/**
 * Created by rvinoth on 10/24/2015.
 */
public class amfFunctions extends AsyncTask<String,String,String>
{
    AMFConnection amfConnection;
    Constants constants;
    String result = null;
    public String[] separated;
    Object responseResult;

    @Override
    protected String doInBackground(String... arg0)
    {
        amfConnection = new AMFConnection();
        try {
            amfConnection.connect(constants.server);
        } catch (ClientStatusException cse) {
            Log.d("ClientStatusException", cse.toString());
        }

        switch (arg0[0])
        {
            case "signUp":
                try {
                    responseResult = amfConnection.call(constants.FUNCTION_CALL_AC,arg0[1]);
                    result= responseResult.toString();
                    Log.d("MessageFrom Server", responseResult.toString());
                }
                catch (ClientStatusException cse)
                {
                    Log.d("ClientStatusException",cse.toString());
                }
                catch (ServerStatusException sse)
                {
                    Log.d("ServerStatus",sse.toString());
                }
                break;
            case "Delete":
                try {
                    responseResult = amfConnection.call(constants.FUNCTION_CALL_DC,arg0[1],arg0[2]);
                    result= responseResult.toString();
                    Log.d("MessageFrom Server", responseResult.toString());
                }
                catch (ClientStatusException cse)
                {
                    Log.d("ClientStatusException",cse.toString());
                }
                catch (ServerStatusException sse)
                {
                    Log.d("ServerStatus",sse.toString());
                }
                break;
            case "Contact":
                try {
                    responseResult = amfConnection.call(constants.FUNCTION_CALL_BA,arg0[1],arg0[2],arg0[3]);
                    result= responseResult.toString();
                    Log.d("MessageFrom Server", responseResult.toString());
                }
                catch (ClientStatusException cse)
                {
                    Log.d("ClientStatusException",cse.toString());
                }
                catch (ServerStatusException sse)
                {
                    Log.d("ServerStatus",sse.toString());
                }
                break;
            case "Maps":
                try {
                    responseResult = amfConnection.call(constants.FUNCTION_CALL_MA,arg0[1],arg0[2],arg0[3]);
                    result= responseResult.toString();
                    Log.e("MessageFrom Server Maps", responseResult.toString());
                }
                catch (ClientStatusException cse)
                {
                    result  = "No internet";
                    Log.d("ClientStatusException",cse.toString());
                }
                catch (ServerStatusException sse)
                {
                    result  = "Server Down";
                    Log.d("ServerStatus",sse.toString());
                }
                break;
            case "Upload":
                try {
                    responseResult = amfConnection.call(constants.FUNCTION_CALL_UI, arg0[1], arg0[2], arg0[3], arg0[4], arg0[5], arg0[6]);
                    result= responseResult.toString();
                    Log.d("MessageFrom Server", responseResult.toString());
                }
                catch (ClientStatusException cse)
                {
                    Log.d("ClientStatusException",cse.toString());
                }
                catch (ServerStatusException sse)
                {
                    Log.d("ServerStatus",sse.toString());
                }
                break;
            case "Profile":
                try {
                    responseResult = amfConnection.call(constants.FUNCTION_CALL_PU,
                            arg0[1],
                            arg0[2],
                            arg0[3],
                            arg0[4],
                            arg0[5],
                            arg0[6],
                            arg0[7],
                            arg0[8],
                            arg0[9],
                            arg0[10],
                            arg0[11],
                            arg0[12],
                            arg0[13]);
                }
                catch (ClientStatusException cse)
                {
                    Log.d("ClientStatusException",cse.toString());
                }
                catch (ServerStatusException sse)
                {
                    Log.d("ServerStatus",sse.toString());
                }
                break;

            case "ProfileFetch":
                try {
                    responseResult = amfConnection.call(constants.FUNCTION_CALL_FPD,arg0[1],arg0[2],arg0[3],arg0[4],arg0[5]
                            ,arg0[6],arg0[7],arg0[8],arg0[9],arg0[10],arg0[11]);
                    Log.d("MessageFrom Server", responseResult.toString());
                }
                catch (ClientStatusException cse)
                {
                    Log.d("ClientStatusException",cse.toString());
                }
                catch (ServerStatusException sse)
                {
                    Log.d("ServerStatus",sse.toString());
                }
                break;
            default: Log.d("Case Failure"," Returned from Switch default");
                break;

        }
        amfConnection.close();
        return result;
    }

    @Override
    protected void onPostExecute(String s) {
        super.onPostExecute(s);

    }
}
