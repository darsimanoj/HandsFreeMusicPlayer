package common;

/**
 * Created by rknikhil on 9/15/2015.
 */
public class Constants
{
    public static final String protocol = "http";
//	public static final String tomcatServerIP = "122.15.144.131";
    //public static final String tomcatServerIP = "192.168.137.1";//10.3.3.8
    public static final String tomcatServerIP = "192.168.43.216";//10.3.3.8
    public static final String gcmServerIP = "122.15.144.131";
//    public static final String apacheServerIP = "122.15.144.131";
    public static final String apacheServerIP = "10.111.2.181";//10.3.3.8

	public static final String tomcatPort = "8080";
	
    public static final String server = protocol +"://"+ tomcatServerIP +":"+ tomcatPort +"/suraksha/messagebroker/amf";
    public static final String server_Snapshot = protocol +"://"+ apacheServerIP +"/suraksha/uploadSnapshots.php";
    public static final String server_Video = protocol +"://"+ apacheServerIP +"/suraksha/uploadCapturedVideos.php";
    public static final String SNAPSHOT_LOCATION = protocol +"://"+ apacheServerIP +"/suraksha/uploads/Snapshots/";
    public static final String VIDEO_LOCATION = protocol +"://"+ apacheServerIP +"/suraksha/uploads/CapturedVideos/";


    //Functional mapping to the Server Side functional API
    public static final String FUNCTION_CALL_AC = "SurakshaHelper.registerUser";
    public static final String FUNCTION_CALL_DC = "SurakshaHelper.deleteBuddy";
    public static final String FUNCTION_CALL_BA = "SurakshaHelper.addingBuddy";
    public static final String FUNCTION_CALL_MA = "SurakshaHelper.addingEventLocation";
    public static final String FUNCTION_CALL_UI = "SurakshaHelper.addingMedia";
    public static final String FUNCTION_CALL_GF = "SurakshaHelper.getLatestLocationNotifications";
    public static final String FUNCTION_CALL_MN = "SurakshaHelper.getLatestPhotoNotifications";
    public static final String FUNCTION_CALL_PU = "SurakshaHelper.userProfileEdit";
    public static final String FUNCTION_CALL_FL = "SurakshaHelper.fetchFriendsList";
    public static final String FUNCTION_CALL_ND = "SurakshaHelper.getLatestNotifications";
    public static final String FUNCTION_CALL_FPD = "SurakshaHelper.fetchProfileDetails";
    public static final String FUNCTION_CALL_NF = "SurakshaHelper.checkNotification";
    public static final String FUNCTION_CALL_NVS = "SurakshaHelper.getNotificationViewedStatus";
    public static final String FUNCTION_CALL_LOC = "SurakshaHelper.addlocation";
    public static final String FUNCTION_CALL_LAT = "SurakshaHelper.addlatitude";
    public static final String FUNCTION_CALL_LONG = "SurakshaHelper.addlongitude";
    public static final String FUNCTION_CALL_floc = "SurakshaHelper.Friends_loc";
    public static final String FUNCTION_CALL_fnum = "SurakshaHelper.fetchFriends_name";
    public static final String FUNCTION_CALL_ftime = "SurakshaHelper.fetchFriends_time";
    public static final String FUNCTION_CALL_Foff = "SurakshaHelper.Fingerprint_off";
    public static final String FUNCTION_CALL_Fon = "SurakshaHelper.Fingerprint_on";
    public static final String TAG = "Rss App";


    public static String RSS_LINK = "http://feeds.feedburner.com/ndtvnews-top-stories";
    public static String login = null;
    public static String profpicURI = null;
    public static String fragment = "No";
    public static String facebok_user_id = null;
}
